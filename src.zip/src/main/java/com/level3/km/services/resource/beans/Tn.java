package com.level3.km.services.resource.beans;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name = "tn")
@XmlAccessorType(XmlAccessType.FIELD)
public class Tn {
    @Field("billAccountName")
    private String billAccountName;

    @Field("billAccountNumber")
    private String billAccountNumber;

    @Field("sourceBillAccountName")
    private String sourceBillAccountName;

    @Field("sourceBillAccountNumber")
    private String sourceBillAccountNumber;

    @Field("customerName")
    private String customerName;

    @Field("customerNumber")
    private String customerNumber;

    @Field("dwCreateDate")
    private Date dwCreateDate;

    @Field("dwDeletedIndicator")
    private String dwDeleteIndicator;

    @Field("dwLastModifyDate")
    private Date dwLastModifyDate;

    @Field("dwSourceSystemCode")
    private String dwSourceSystemCode;

    @Field("productCode")
    private String productCode;

    @Field("productName")
    private String productName;

    @Field("serviceComponentCode")
    private String serviceComponentCode;

    @Field("serviceComponentId")
    private String serviceComponentId;

    @Field("serviceComponentName")
    private String serviceComponentName;

    @Field("serviceId")
    private String serviceId;

    @Field("sourceCreateDate")
    private Date sourceCreateDate;

    @Field("sourceLastModifyDate")
    private Date sourceLastModifyDate;

    @Field("sourceLastModifyUserId")
    private String sourceLastModifyUserId;

    @Field("statusCode")
    private String statusCode;

    @Field("statusDescription")
    private String statusDescription;

    @Field("statusDate")
    private Date statusDate;

    @Deprecated
    @Field("tnCountryCode")
    private String tnCountryCode;

    @Field("tnCountryDialCode")
    private String tnCountryDialCode;

    @Field("tnLookupKeyId")
    private String tnLookupKeyId;

    @Field("tnLookupSearchKey")
    private String tnLookupSearchKey;

    @Field("tnNumber")
    private String tnNumber;

    @Field("typeCode")
    private String typeCode;

    @Field("typeDescription")
    private String typeDescription;

    @Field("serviceClassLevelType")
    private String serviceClassLevelType;

    @Field("tnLookupDiscriminatorType")
    private String tnLookupDiscriminatorType;

    @Field("routePlans")
    private List<String> routePlans;

    @Field("featurePacks")
    private List<String> featurePacks;

    @Field("e911OptionType")
    private String e911OptionType;

    @Field("subAccountIndicator")
    private Boolean subAccountIndicator;

    @Deprecated
    @Field("line1Address")
    private String line1Address;

    @Deprecated
    @Field("cityName")
    private String cityName;

    @Deprecated
    @Field("stateCode")
    private String stateCode;

    @Deprecated
    @Field("postalCode")
    private String postalCode;

    @Deprecated
    @Field("postalShortCode")
    private String postalShortCode;

    @Deprecated
    @Field("countryName")
    private String countryName;

    @Field("glProfitCenterCode")
    private String glProfitCenterCode;

    @Field("voiceLocationServiceComponentId")
    private String voiceLocationServiceComponentId;

    @Deprecated
    @Field("fullAddress")
    private String fullAddress;

    @Deprecated
    @Field("fullAddressComponents")
    private String fullAddressComponents;

    @Field("serviceLine1Address")
    private String serviceLine1Address;

    @Field("serviceCityName")
    private String serviceCityName;

    @Field("serviceStateCode")
    private String serviceStateCode;

    @Field("servicePostalCode")
    private String servicePostalCode;

    @Field("servicePostalShortCode")
    private String servicePostalShortCode;

    @Field("serviceCountryName")
    private String serviceCountryName;

    @Field("serviceFullAddress")
    private String serviceFullAddress;

    @Field("serviceFullAddressComponents")
    private String serviceFullAddressComponents;

    @Field("subscriberLine1Address")
    private String subscriberLine1Address;

    @Field("subscriberCityName")
    private String subscriberCityName;

    @Field("subscriberStateCode")
    private String subscriberStateCode;

    @Field("subscriberPostalCode")
    private String subscriberPostalCode;

    @Field("subscriberPostalShortCode")
    private String subscriberPostalShortCode;

    @Field("subscriberCountryName")
    private String subscriberCountryName;

    @Field("subscriberFullAddress")
    private String subscriberFullAddress;

    @Field("subscriberFullAddressComponents")
    private String subscriberFullAddressComponents;

    public String getBillAccountName() {
	return billAccountName;
    }

    public void setBillAccountName(String billAccountName) {
	this.billAccountName = billAccountName;
    }

    public String getBillAccountNumber() {
	return billAccountNumber;
    }

    public void setBillAccountNumber(String billAccountNumber) {
	this.billAccountNumber = billAccountNumber;
    }

    public String getSourceBillAccountName() {
	return sourceBillAccountName;
    }

    public void setSourceBillAccountName(String sourceBillAccountName) {
	this.sourceBillAccountName = sourceBillAccountName;
    }

    public String getSourceBillAccountNumber() {
	return sourceBillAccountNumber;
    }

    public void setSourceBillAccountNumber(String sourceBillAccountNumber) {
	this.sourceBillAccountNumber = sourceBillAccountNumber;
    }

    public String getCustomerName() {
	return customerName;
    }

    public void setCustomerName(String customerName) {
	this.customerName = customerName;
    }

    public String getCustomerNumber() {
	return customerNumber;
    }

    public void setCustomerNumber(String customerNumber) {
	this.customerNumber = customerNumber;
    }

    public Date getDwCreateDate() {
	return dwCreateDate;
    }

    public void setDwCreateDate(Date dwCreateDate) {
	this.dwCreateDate = dwCreateDate;
    }

    public String getDwDeleteIndicator() {
	return dwDeleteIndicator;
    }

    public void setDwDeleteIndicator(String dwDeleteIndicator) {
	this.dwDeleteIndicator = dwDeleteIndicator;
    }

    public Date getDwLastModifyDate() {
	return dwLastModifyDate;
    }

    public void setDwLastModifyDate(Date dwLastModifyDate) {
	this.dwLastModifyDate = dwLastModifyDate;
    }

    public String getDwSourceSystemCode() {
	return dwSourceSystemCode;
    }

    public void setDwSourceSystemCode(String dw_source_system_cd) {
	this.dwSourceSystemCode = dw_source_system_cd;
    }

    public String getProductCode() {
	return productCode;
    }

    public void setProductCode(String product_cd) {
	this.productCode = product_cd;
    }

    public String getProductName() {
	return productName;
    }

    public void setProductName(String product_name) {
	this.productName = product_name;
    }

    public String getServiceComponentCode() {
	return serviceComponentCode;
    }

    public void setServiceComponentCode(String serv_compnt_cd) {
	this.serviceComponentCode = serv_compnt_cd;
    }

    public String getServiceComponentId() {
	return serviceComponentId;
    }

    public void setServiceComponentId(String serv_compnt_id) {
	this.serviceComponentId = serv_compnt_id;
    }

    public String getServiceComponentName() {
	return serviceComponentName;
    }

    public void setServiceComponentName(String serv_compnt_name) {
	this.serviceComponentName = serv_compnt_name;
    }

    public String getServiceId() {
	return serviceId;
    }

    public void setServiceId(String service_id) {
	this.serviceId = service_id;
    }

    public Date getSourceCreateDate() {
	return sourceCreateDate;
    }

    public void setSourceCreateDate(Date source_create_dt) {
	this.sourceCreateDate = source_create_dt;
    }

    public Date getSourceLastModifyDate() {
	return sourceLastModifyDate;
    }

    public void setSourceLastModifyDate(Date source_last_modify_dt) {
	this.sourceLastModifyDate = source_last_modify_dt;
    }

    public String getSourceLastModifyUserId() {
	return sourceLastModifyUserId;
    }

    public void setSourceLastModifyUserId(String source_last_modify_user_id) {
	this.sourceLastModifyUserId = source_last_modify_user_id;
    }

    public String getStatusCode() {
	return statusCode;
    }

    public void setStatusCode(String status_cd) {
	this.statusCode = status_cd;
    }

    public String getStatusDescription() {
	return statusDescription;
    }

    public void setStatusDescription(String status_desc) {
	this.statusDescription = status_desc;
    }

    public Date getStatusDate() {
	return statusDate;
    }

    public void setStatusDate(Date status_dt) {
	this.statusDate = status_dt;
    }

    public String getTnCountryCode() {
	return tnCountryCode;
    }

    public void setTnCountryCode(String tn_country_cd) {
	this.tnCountryCode = tn_country_cd;
    }

    public String getTnCountryDialCode() {
	return tnCountryDialCode;
    }

    public void setTnCountryDialCode(String tnCountryDialCode) {
	this.tnCountryDialCode = tnCountryDialCode;
    }

    public String getTnLookupKeyId() {
	return tnLookupKeyId;
    }

    public void setTnLookupKeyId(String tn_lookup_key_id) {
	this.tnLookupKeyId = tn_lookup_key_id;
    }

    public String getTnLookupSearchKey() {
	return tnLookupSearchKey;
    }

    public void setTnLookupSearchKey(String tn_lookup_search_key) {
	this.tnLookupSearchKey = tn_lookup_search_key;
    }

    public String getTnNumber() {
	return tnNumber;
    }

    public void setTnNumber(String tn_nbr) {
	this.tnNumber = tn_nbr;
    }

    public String getTypeCode() {
	return typeCode;
    }

    public void setTypeCode(String type_cd) {
	this.typeCode = type_cd;
    }

    public String getTypeDescription() {
	return typeDescription;
    }

    public void setTypeDescription(String type_desc) {
	this.typeDescription = type_desc;
    }

    public String getServiceClassLevelType() {
	return serviceClassLevelType;
    }

    public void setServiceClassLevelType(String service_class_level_typ) {
	this.serviceClassLevelType = service_class_level_typ;
    }

    public String getTnLookupDiscriminatorType() {
	return tnLookupDiscriminatorType;
    }

    public void setTnLookupDiscriminatorType(String tn_lookup_discrim_typ) {
	this.tnLookupDiscriminatorType = tn_lookup_discrim_typ;
    }

    public List<String> getRoutePlans() {
	return routePlans;
    }

    public void setRoutePlans(List<String> routePlans) {
	this.routePlans = routePlans;
    }

    public List<String> getFeaturePacks() {
	return featurePacks;
    }

    public void setFeaturePacks(List<String> featurePacks) {
	this.featurePacks = featurePacks;
    }

    public String getE911OptionType() {
	return e911OptionType;
    }

    public void setE911OptionType(String e911OptionType) {
	this.e911OptionType = e911OptionType;
    }

    public Boolean getSubAccountIndicator() {
	return subAccountIndicator;
    }

    public void setSubAccountIndicator(Boolean subAccountIndicator) {
	this.subAccountIndicator = subAccountIndicator;
    }

    public String getLine1Address() {
	return line1Address;
    }

    public void setLine1Address(String line1Address) {
	this.line1Address = line1Address;
    }

    public String getCityName() {
	return cityName;
    }

    public void setCityName(String cityName) {
	this.cityName = cityName;
    }

    public String getStateCode() {
	return stateCode;
    }

    public void setStateCode(String stateCode) {
	this.stateCode = stateCode;
    }

    public String getPostalCode() {
	return postalCode;
    }

    public void setPostalCode(String postalCode) {
	this.postalCode = postalCode;
    }

    public String getPostalShortCode() {
	return postalShortCode;
    }

    public void setPostalShortCode(String postalShortCode) {
	this.postalShortCode = postalShortCode;
    }

    public String getCountryName() {
	return countryName;
    }

    public void setCountryName(String countryName) {
	this.countryName = countryName;
    }

    public String getGlProfitCenterCode() {
	return glProfitCenterCode;
    }

    public void setGlProfitCenterCode(String glProfitCenterCode) {
	this.glProfitCenterCode = glProfitCenterCode;
    }

    public String getVoiceLocationServiceComponentId()
    {
        return voiceLocationServiceComponentId;
    }

    public void setVoiceLocationServiceComponentId(
            String voiceLocationServiceComponentId)
    {
        this.voiceLocationServiceComponentId = voiceLocationServiceComponentId;
    }

    public String getFullAddress() {
		return fullAddress;
	}

	public void setFullAddress(String fullAddress) {
		this.fullAddress = fullAddress;
	}

	public String getFullAddressComponents() {
		return fullAddressComponents;
	}

	public void setFullAddressComponents(String fullAddressComponents) {
		this.fullAddressComponents = fullAddressComponents;
	}

	public String getServiceLine1Address() {
		return serviceLine1Address;
	}

	public void setServiceLine1Address(String serviceLine1Address) {
		this.serviceLine1Address = serviceLine1Address;
	}

	public String getServiceCityName() {
		return serviceCityName;
	}

	public void setServiceCityName(String serviceCityName) {
		this.serviceCityName = serviceCityName;
	}

	public String getServiceStateCode() {
		return serviceStateCode;
	}

	public void setServiceStateCode(String serviceStateCode) {
		this.serviceStateCode = serviceStateCode;
	}

	public String getServicePostalCode() {
		return servicePostalCode;
	}

	public void setServicePostalCode(String servicePostalCode) {
		this.servicePostalCode = servicePostalCode;
	}

	public String getServicePostalShortCode() {
		return servicePostalShortCode;
	}

	public void setServicePostalShortCode(String servicePostalShortCode) {
		this.servicePostalShortCode = servicePostalShortCode;
	}

	public String getServiceCountryName() {
		return serviceCountryName;
	}

	public void setServiceCountryName(String serviceCountryName) {
		this.serviceCountryName = serviceCountryName;
	}

	public String getServiceFullAddress() {
		return serviceFullAddress;
	}

	public void setServiceFullAddress(String serviceFullAddress) {
		this.serviceFullAddress = serviceFullAddress;
	}

	public String getServiceFullAddressComponents() {
		return serviceFullAddressComponents;
	}

	public void setServiceFullAddressComponents(String serviceFullAddressComponents) {
		this.serviceFullAddressComponents = serviceFullAddressComponents;
	}

	public String getSubscriberLine1Address() {
		return subscriberLine1Address;
	}

	public void setSubscriberLine1Address(String subscriberLine1Address) {
		this.subscriberLine1Address = subscriberLine1Address;
	}

	public String getSubscriberCityName() {
		return subscriberCityName;
	}

	public void setSubscriberCityName(String subscriberCityName) {
		this.subscriberCityName = subscriberCityName;
	}

	public String getSubscriberStateCode() {
		return subscriberStateCode;
	}

	public void setSubscriberStateCode(String subscriberStateCode) {
		this.subscriberStateCode = subscriberStateCode;
	}

	public String getSubscriberPostalCode() {
		return subscriberPostalCode;
	}

	public void setSubscriberPostalCode(String subscriberPostalCode) {
		this.subscriberPostalCode = subscriberPostalCode;
	}

	public String getSubscriberPostalShortCode() {
		return subscriberPostalShortCode;
	}

	public void setSubscriberPostalShortCode(String subscriberPostalShortCode) {
		this.subscriberPostalShortCode = subscriberPostalShortCode;
	}

	public String getSubscriberCountryName() {
		return subscriberCountryName;
	}

	public void setSubscriberCountryName(String subscriberCountryName) {
		this.subscriberCountryName = subscriberCountryName;
	}

	public String getSubscriberFullAddress() {
		return subscriberFullAddress;
	}

	public void setSubscriberFullAddress(String subscriberFullAddress) {
		this.subscriberFullAddress = subscriberFullAddress;
	}

	public String getSubscriberFullAddressComponents() {
		return subscriberFullAddressComponents;
	}

	public void setSubscriberFullAddressComponents(String subscriberFullAddressComponents) {
		this.subscriberFullAddressComponents = subscriberFullAddressComponents;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Tn [billAccountName=");
		builder.append(billAccountName);
		builder.append(", billAccountNumber=");
		builder.append(billAccountNumber);
		builder.append(", sourceBillAccountName=");
		builder.append(sourceBillAccountName);
		builder.append(", sourceBillAccountNumber=");
		builder.append(sourceBillAccountNumber);
		builder.append(", customerName=");
		builder.append(customerName);
		builder.append(", customerNumber=");
		builder.append(customerNumber);
		builder.append(", dwCreateDate=");
		builder.append(dwCreateDate);
		builder.append(", dwDeleteIndicator=");
		builder.append(dwDeleteIndicator);
		builder.append(", dwLastModifyDate=");
		builder.append(dwLastModifyDate);
		builder.append(", dwSourceSystemCode=");
		builder.append(dwSourceSystemCode);
		builder.append(", productCode=");
		builder.append(productCode);
		builder.append(", productName=");
		builder.append(productName);
		builder.append(", serviceComponentCode=");
		builder.append(serviceComponentCode);
		builder.append(", serviceComponentId=");
		builder.append(serviceComponentId);
		builder.append(", serviceComponentName=");
		builder.append(serviceComponentName);
		builder.append(", serviceId=");
		builder.append(serviceId);
		builder.append(", sourceCreateDate=");
		builder.append(sourceCreateDate);
		builder.append(", sourceLastModifyDate=");
		builder.append(sourceLastModifyDate);
		builder.append(", sourceLastModifyUserId=");
		builder.append(sourceLastModifyUserId);
		builder.append(", statusCode=");
		builder.append(statusCode);
		builder.append(", statusDescription=");
		builder.append(statusDescription);
		builder.append(", statusDate=");
		builder.append(statusDate);
		builder.append(", tnCountryCode=");
		builder.append(tnCountryCode);
		builder.append(", tnCountryDialCode=");
		builder.append(tnCountryDialCode);
		builder.append(", tnLookupKeyId=");
		builder.append(tnLookupKeyId);
		builder.append(", tnLookupSearchKey=");
		builder.append(tnLookupSearchKey);
		builder.append(", tnNumber=");
		builder.append(tnNumber);
		builder.append(", typeCode=");
		builder.append(typeCode);
		builder.append(", typeDescription=");
		builder.append(typeDescription);
		builder.append(", serviceClassLevelType=");
		builder.append(serviceClassLevelType);
		builder.append(", tnLookupDiscriminatorType=");
		builder.append(tnLookupDiscriminatorType);
		builder.append(", routePlans=");
		builder.append(routePlans);
		builder.append(", featurePacks=");
		builder.append(featurePacks);
		builder.append(", e911OptionType=");
		builder.append(e911OptionType);
		builder.append(", subAccountIndicator=");
		builder.append(subAccountIndicator);
		builder.append(", line1Address=");
		builder.append(line1Address);
		builder.append(", cityName=");
		builder.append(cityName);
		builder.append(", stateCode=");
		builder.append(stateCode);
		builder.append(", postalCode=");
		builder.append(postalCode);
		builder.append(", postalShortCode=");
		builder.append(postalShortCode);
		builder.append(", countryName=");
		builder.append(countryName);
		builder.append(", glProfitCenterCode=");
		builder.append(glProfitCenterCode);
		builder.append(", voiceLocationServiceComponentId=");
		builder.append(voiceLocationServiceComponentId);
		builder.append(", fullAddress=");
		builder.append(fullAddress);
		builder.append(", serviceLine1Address=");
		builder.append(serviceLine1Address);
		builder.append(", serviceCityName=");
		builder.append(serviceCityName);
		builder.append(", serviceStateCode=");
		builder.append(serviceStateCode);
		builder.append(", servicePostalCode=");
		builder.append(servicePostalCode);
		builder.append(", servicePostalShortCode=");
		builder.append(servicePostalShortCode);
		builder.append(", serviceCountryName=");
		builder.append(serviceCountryName);
		builder.append(", serviceFullAddress=");
		builder.append(serviceFullAddress);
		builder.append(", subscriberLine1Address=");
		builder.append(subscriberLine1Address);
		builder.append(", subscriberCityName=");
		builder.append(subscriberCityName);
		builder.append(", subscriberStateCode=");
		builder.append(subscriberStateCode);
		builder.append(", subscriberPostalCode=");
		builder.append(subscriberPostalCode);
		builder.append(", subscriberPostalShortCode=");
		builder.append(subscriberPostalShortCode);
		builder.append(", subscriberCountryName=");
		builder.append(subscriberCountryName);
		builder.append(", subscriberFullAddress=");
		builder.append(subscriberFullAddress);
		builder.append("]");
		return builder.toString();
	}

}
