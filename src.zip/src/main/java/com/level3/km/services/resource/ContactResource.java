package com.level3.km.services.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import com.ecyrd.speed4j.StopWatch;
import com.level3.km.services.properties.PropertyManager;
import com.level3.km.services.resource.beans.Contact;
import com.level3.km.services.resource.beans.Level3Response;

@Path("/Search/contact")
public class ContactResource extends AbstractBaseResource
{
    /**
     * Searches for Contact data as specified by the query.
     * Search results will be limited to 500 rows. Any valid Solr query can be passed as an argument for search.
     * e.g. "q=customerNumber:020516175" will translate into "select?q=customerNumber:020516175"
     * 
     * @param uriInfo URI information of the current request
     * @param acceptHeader determines the Accept Header requested by the client
     * @return result of query execution on Solr in XML or JSON format. Result will be a representation
     * of {@link com.level3.km.services.resource.beans.Contact Contact} POJO
     */
    @GET
    @com.webcohesion.enunciate.metadata.rs.TypeHint(Contact.class)
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response search()
    {
        StopWatch stopWatch = speed4jStopWatchFactory.getStopWatch();
        
        try
        {
            return super.doQuery(Contact.class);
        }
        finally
        {
            stopWatch.stop(uriInfo.getPath() + "-" + request.getMethod(), uriInfo.getQueryParameters().toString());
        }
    }
    
    /**
     * Searches for Contact data as specified by the query.
     * Search results will be limited to 500 rows. Any valid Solr query can be passed as an argument for search.
     * e.g. "q=customerNumber:020516175" will translate into "select?q=customerNumber:020516175"
     * 
     * @param uriInfo URI information of the current request
     * @param acceptHeader determines the Accept Header requested by the client
     * @return result of query execution on Solr in XML or JSON format. Result will be native SOLR 
     * response.
     */
    @GET
    @Path("raw")
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response searchRaw()
    {
        StopWatch stopWatch = speed4jStopWatchFactory.getStopWatch();
        
        try
        {
            return super.doQuery();
        }
        finally
        {
            stopWatch.stop(uriInfo.getPath() + "-" + request.getMethod(), uriInfo.getQueryParameters().toString());
        }
    }
    
    /**
     * Searches for Contact data as specified by the query.
     * Search results will be limited to 500 rows. Any valid Solr query can be passed as an argument for search.
     * e.g. "q=customerNumber:020516175" 
     * 
     * @param params MultivaluedMap representing the body of this POST call 
     * @param acceptHeader determines the Accept Header requested by the client
     * @param Content-Type header determines the content-type for the body of this POST call,
     *        it should be set to "application/x-www-form-urlencoded" 
     * @return result of query execution on Solr in XML or JSON format. Result will be a representation
     * of {@link com.level3.km.services.resource.beans.Contact Contact} POJO
     */
    @POST
    @com.webcohesion.enunciate.metadata.rs.TypeHint(Contact.class)
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response search(MultivaluedMap<String, String> params)
    {
        StopWatch stopWatch = speed4jStopWatchFactory.getStopWatch();
        
        try
        {
            return super.doQuery(params, Contact.class);
        }
        finally
        {
            stopWatch.stop(uriInfo.getPath() + "-" + request.getMethod(), params.toString());
        }
    }
    
    /**
     * Searches for Contact data as specified by the query.
     * Search results will be limited to 500 rows. Any valid Solr query can be passed as an argument for search.
     * e.g. "q=customerNumber:020516175" 
     * 
     * @param params MultivaluedMap representing the body of this POST call 
     * @param acceptHeader determines the Accept Header requested by the client
     * @param Content-Type header determines the content-type for the body of this POST call,
     *        it should be set to "application/x-www-form-urlencoded" 
     * @return result of query execution on Solr in XML or JSON format. Result will be native SOLR 
     * response.
     */
    @POST
    @Path("raw")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response searchRaw(MultivaluedMap<String, String> params)
    {
        StopWatch stopWatch = speed4jStopWatchFactory.getStopWatch();
        
        try
        {
            return super.doQuery(params);
        }
        finally
        {
            stopWatch.stop(uriInfo.getPath() + "-" + request.getMethod(), params.toString());
        }
    }
    
    @SuppressWarnings("unchecked")
    protected <T> Level3Response<?> getLevel3Response(List<T> resultList, long numFound, long start)
    {
        Level3Response<Contact> level3Response = 
                new Level3Response<Contact>(
                        (List<Contact>)resultList,
                        numFound,
                        start);
        
        return level3Response;
    }
    
    protected String getSolrUrl()
    {
        return PropertyManager.instance().getProperty(PropertyManager.CONTACT_SOLR_URL_STR);
    }
}
