package com.level3.km.services.exception;

public enum ErrorCodeMapping
{
    // Exceptions per Level 3 wiki, Error_Standard page
    InvalidURI(400, 400001, "Invalid URI", "Resource could not be determined from URI" ),
    
    InvalidQueryString(400, 400002, "Invalid Query String", ""),
    
    MissingData(400, 400003, "Missing Data", "" ),
    
    InvalidData(400, 400004, "Invalid Data", ""),
    
    DataDependencyNotMet(400, 400005, "Data dependencies not met", ""),
    
    BusinessValidationsNotMet(400, 400006, "Business validations not met", ""),
    
    UserAuthenticationFailed(403, 403001, "User Authentication failed", "User could not be authenticated and is not authorized."),
    
    TokenValidationFailed(403, 403002, "Token validation failed", null),
    
    ApplicationKeyValidationFailed(403, 403003, "Application key validation failed", null),
    
    DigestValidationFailed(403, 403004, "Digest validation failed", null),
    
    NotAuthorizedForMethod(403, 403005, "Not authorized for method", null),
    
    TokenExpired(403, 403006, "Token Expired", null),
    
    ResourceNotFound(404, 404001, "Request resource not found", "The server has not found anything matching the Request-URI."),
    
    MethodNotAllowed(405, 405001, "Method not allowed for resource", "The method specified is not allowed for the resource identified by the Request-URI."),
    
    NotAcceptable(406, 406001, "Not Acceptable", "The resource identified by the request is only capable of generating response entities which have content characteristics not acceptable according to the accept headers sent in the request."),
    
    ConflictingUpdate(409, 409001, "Resource could not be updated due to conflicting update", "The request could not be completed due to a conflict with the current state of the resource."),
    
    MediaTypeNotSupported(415, 415001, "Media Type is not supported", "Supported media types are application/xml or application/json"),
    
    InternalServerError(500, 500001, "Internal Server Error", ""),

    ServiceUnavailable(503, 503001, "Service Unavailable", "The server is currently unable to handle the request, please try again later."),
    
    MediationTimeout(504, 504001, "Mediation timeout", "The server did not receive a timely response from the upstream server it needed to access in attempting to complete the request."),
    
    ProviderTimeout(504, 504002, "Provider timeout", null),
    
    // Application specific exceptions
    ServiceLookupIndexUnknown(500, 500002, "Unknown exception", null),
    
    UnsupportedQueryConversion(500, 500003, "Results could not be mapped to a bean, try running the query against native response e.g. <resource>/raw", null),
    
    DeepPagingUnavailable(500, 500004, "Too many results requested, please filter the query", ""),
    
    UnknownException(500, 599999, "Unknown Exception", "Unknown error thrown from application.");
    
    private final int errorCode;
    private final int httpStatusCode;
    private final String errorMessage;
    private final String errorDetail;
    
    ErrorCodeMapping(int httpStatusCode, int errorCode, String errorMessage, String detail)
    {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.httpStatusCode = httpStatusCode;
        this.errorDetail = detail;
    }
    
    public int getErrorCode()
    {
        return errorCode;
    }
    
    public String getErrorMessage()
    {
        return errorMessage;
    }

    public int getHttpStatusCode()
    {
        return httpStatusCode;
    }

    public String getErrorDetail()
    {
        return errorDetail;
    }
}
