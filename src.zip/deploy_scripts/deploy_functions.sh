#!/bin/bash
################################################################################
#                                                                              #
# This script contains reusable functions for deploying applications to        #
#  WebLogic application servers.                                               #
#                                                                              #
# Arguments:                                                                   #
#                                                                              #
# Author: Ken Rumer - 9/21/2010                                                #
#                                                                              #
################################################################################

  undeploy_module () {
    ADMIN_URL=$1
    USER_NAME=$2
    PASSWD=$3
    SERVICE_MODULE=$4

    OUTPUT=`java -cp $WLST_CP weblogic.Deployer -adminurl ${ADMIN_URL} -user ${USER_NAME} -password ${PASSWD} -name ${SERVICE_MODULE} -undeploy`
    if [ $? -ne 0 ]; then
      echo "WARNING: failed to undeploy $SERVICE_MODULE..."
      echo "$OUTPUT"
    fi

  }

  deploy_module () {
    ADMIN_URL=$1
    USER_NAME=$2
    PASSWD=$3
    DIST_DIR=$4
    DOMAIN_HOME=$5
    SERVICE_MODULE=$6
    TARGETS=$7
    SERVICE_FILE=$8 #OPTIONAL

    if [ -z "$SERVICE_FILE" ]; then
      SERVICE_FILE=`ls -1 ${DIST_DIR}/ | grep ${SERVICE_MODULE}.*ar`
    fi
    rm -f ${DOMAIN_HOME}/applications/${SERVICE_FILE}
    cp ${DIST_DIR}/${SERVICE_FILE} ${DOMAIN_HOME}/applications/
    OUTPUT=`java -cp $WLST_CP weblogic.Deployer -timeout 900 -adminurl ${ADMIN_URL} -user ${USER_NAME} -password ${PASSWD} -name ${SERVICE_MODULE} -targets "${TARGETS}" -stage -deploy "${DOMAIN_HOME}/applications/${SERVICE_FILE}"`
    if [ $? -ne 0 ]; then
      echo "Failed to deploy $SERVICE_MODULE..."
      echo "$OUTPUT"
      exit 1
    fi
  }

  deploy_external_module () {
    HOST=$1
    DOMAIN_HOME=$2
    SERVICE_MODULE=$3
    SERVICE_FILE=$4 #OPTIONAL

    if [ -z SERVICE_FILE ]; then
      SERVICE_FILE=`ls -1 ${DIST_DIR}/ | grep ${SERVICE_MODULE}.*ar`
    fi

    ssh $HOST "rm ${DOMAIN_HOME}/applications/${SERVICE_FILE}"
    scp ${DIST_DIR}/${SERVICE_FILE} $HOST:${DOMAIN_HOME}/applications/
    ssh $HOST "${BEA_HOME}/bin/envctl restart"
  }

  stop_module () {
    ADMIN_URL=$1
    USER_NAME=$2
    PASSWD=$3
    SERVICE_MODULE=$4

    OUTPUT=`java -cp $WLST_CP weblogic.Deployer -adminurl ${ADMIN_URL} -user ${USER_NAME} -password ${PASSWD} -name ${SERVICE_MODULE} -stop`
    if [ $? -ne 0 ]; then
      echo "WARNING: Failed to stop $SERVICE_MODULE..."
      echo "$OUTPUT"
    fi
  }

  start_module () {
    ADMIN_URL=$1
    USER_NAME=$2
    PASSWD=$3
    SERVICE_MODULE=$4

    OUTPUT=`java -cp $WLST_CP weblogic.Deployer -adminurl ${ADMIN_URL} -user ${USER_NAME} -password ${PASSWD} -name ${SERVICE_MODULE} -start`
    if [ $? -ne 0 ]; then
      echo "Failed to start $SERVICE_MODULE..."
      echo "$OUTPUT"
      exit 1
    fi
  }

  # Replaces instances of $1 with $2
  # i.e. cat <file> | replace @@env@@ $environment
  replace () {
    SEARCH=$1
    REPLACE=$2

    while read data; do
      echo "$data" | sed "s/$SEARCH/$REPLACE/g"
    done
  }

  filter_files () {
    ENVIRONMENT=$1
    PASSWD=$2
    PANDA_DIR=$3
    BUILD_FILE=$4
    TARGET=$5
    EXT_PROPERTIES=$6 #OPTIONAL

    PROPERTIES="\
 -Denvironment=${ENVIRONMENT}\
 -Dpasswd=${PASSWD}\
 -Dpanda_dir=${PANDA_DIR}\
 -Duser_name=${USER_NAME}\
 -Dwls_user=${WLS_USER}\
 -Dpasswd=${PASSWD}\
 -Dwls_pw=${WLS_PW}\
 -Ddomain_name=${DOMAIN_NAME}\
 -Ddomain_home=${DOMAIN_HOME}\
 -Dserver_name=${SERVER_NAME}\
 -Dadmin_server=${ADMIN_SERVER}\
 -Dadmin_port=${ADMIN_PORT}\
 -Dnumber_of_nodes=${NUMBER_OF_NODES}\
 -Dnode_names=${NODE_NAMES}\
 -Dnode_urls=${NODE_URLS}\
 -Djava_home=${JAVA_HOME}\
 -Djava_vendor=${JAVA_VENDOR}\
 -Ddomain_home=${DOMAIN_HOME}\
 -Dlog_dir=${LOG_DIR}\
 -Dwls_redirect_log=${WLS_REDIRECT_LOG}\
 -Dwls_stdout_log=${WLS_STDOUT_LOG}\
 -Dwls_stderr_log=${WLS_STDERR_LOG}\
 -Dpid_file=${PID_FILE}\
 -Dlog4j_config_file=${LOG4J_CONFIG_FILE}\
 -Dstop_script=${STOP_SCRIPT}\
 -Dstart_script=${START_SCRIPT}\
 -Dext_pre_classpath=${EXT_PRE_CLASSPATH}\
 -Dext_post_classpath=${EXT_POST_CLASSPATH}\
 -Dbea_home=${BEA_HOME}\
 -Dwl_home=${WL_HOME}\
 -Dwls_home=${WLS_HOME}\
 -Dld_library_path=${LD_LIBRARY_PATH}\
 -Dpath=${PATH}"

    if [ -n "${EXT_PROPERTIES}" ]; then
      PROPERTIES="${PROPERTIES} ${EXT_PROPERTIES}"
    fi
	echo "filter_files PROPERTIES is ${PROPERTIES}"

    CLASSPATH=${ANT_CP};${ANT_HOME}/bin/ant -buildfile $BUILD_FILE $PROPERTIES $TARGET 2>&1 | tee ./ant.log
    result=`tail ./ant.log  | grep BUILD | cut -f2 -d" "`
    if [ "$result" != "SUCCESSFUL" ]; then
      echo "Ant target ${TARGET} failed...."
      exit 1
    fi
    rm ./ant.log

  }

  copy_local_files () {
    ENVIRONMENT=$1
    PASSWD=$2
    PANDA_DIR=$3
    SOURCE_FILE="$4"
    DEST_FILE=$5
    BUILD_FILE=$6 #OPTIONAL
    TARGET=$7 #OPTIONAL

    cd ${PANDA_DIR}
    if echo ${DEST_FILE} | grep /$ 1>/dev/null 2>&1; then
      dest_dir=${DEST_FILE}
    else
      dest_dir=`dirname ${DEST_FILE}`
    fi
    mkdir -p ${dest_dir} 2>/dev/null
    cp -r ./${SOURCE_FILE} ${DEST_FILE}
    if [ -n "${BUILD_FILE}" ]; then
      filter_files $ENVIRONMENT $PASSWD $PANDA_DIR $BUILD_FILE $TARGET
    fi
  }

  setup_remote_files () {
    ENVIRONMENT=$1
    PASSWD=$2
    PANDA_DIR=$3
    SOURCE_FILE="$4"
    HOST=$5
    NODE_NAME=$6
    DEST_FILE=$7
    BUILD_FILE=$8 #OPTIONAL
    TARGET=$9 #OPTIONAL

    mkdir -p ./remote_files/${HOST} 2>/dev/null
    if echo ${DEST_FILE} | grep /$ 1>/dev/null 2>&1; then
      dest_dir=${DEST_FILE}
    else
      dest_dir=`dirname ${DEST_FILE}`
    fi
    mkdir -p ./remote_files/${HOST}${dest_dir} 2>/dev/null
    cp -r ./${SOURCE_FILE} ./remote_files/${HOST}${DEST_FILE}
    if [ -n "${BUILD_FILE}" ]; then
      filter_files $ENVIRONMENT $PASSWD $PANDA_DIR $BUILD_FILE $TARGET "-Dhost=$HOST -Dnode_name=$NODE_NAME"
    fi
  }

  copy_remote_files () {
    PANDA_DIR=$1
    HOST=$2

    scp -r ./remote_files/${HOST}/* ${HOST}:/ 1>/dev/null 2>&1
  }

  extract_jar () {
    PANDA_DIR=$1
    JAR_FILE=$2
    EXTRACT_DIR=$3

    cd ${PANDA_DIR}
    mkdir -p ${EXTRACT_DIR}
    cd ${EXTRACT_DIR}
    ${JAVA_HOME}/bin/jar xf ${JAR_FILE}
    cd ${PANDA_DIR}
  }

  create_jar () {
    PANDA_DIR=$1
    JAR_FILE=$2
    CREATE_DIR=$3

    jar_dir=`dirname ${JAR_FILE}`
    jar_file_name=`basename ${JAR_FILE}`

    cd ${PANDA_DIR}
    mkdir -p ${PANDA_DIR}/${jar_dir}
    cd ${PANDA_DIR}/${jar_dir}
    ${JAVA_HOME}/bin/jar cf ${jar_file_name} -C ${PANDA_DIR}/${CREATE_DIR} .
    cd ${PANDA_DIR}
  }
