package com.level3.km.services.resource.beans;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name = "billrevenuemetrics")
@XmlAccessorType(XmlAccessType.FIELD)
public class BillRevenueMetrics {
	@Field("id")
	private String id;
	@Field("billingLine1Address")
	private String billingLine1Address;
	@Field("billingLine2Address")
	private String billingLine2Address;
	@Field("billingCityName")
	private String billingCityName;
	@Field("billingStateCode")
	private String billingStateCode;
	@Field("billingPostalCode")
	private String billingPostalCode;
	@Field("billingCountryName")
	private String billingCountryName;
	@Field("sourceSystemName")
	private String sourceSystemName;
	@Field("customerNumber")
	private String customerNumber;
	@Field("customerName")
	private String customerName;
	@Field("employeeUserName")
	private String employeeUserName;
	@Field("glCustomerSegmentCode")
	private String glCustomerSegmentCode;
	@Field("salesRepId")
	private String salesRepId;
	@Field("salesRepName")
	private String salesRepName;
	@Field("prevYearToDateMrc")
	private String prevYearToDateMrc;
	@Field("threeMonthAvgMrc")
	private String threeMonthAvgMrc;
	@Field("currentMrc")
	private String currentMrc;
	@Field("yearToDateMrc")
	private String yearToDateMrc;
	@Field("yearToDateNrc")
	private String yearToDateNrc;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBillingLine1Address() {
		return billingLine1Address;
	}

	public void setBillingLine1Address(String billingLine1Address) {
		this.billingLine1Address = billingLine1Address;
	}

	public String getBillingLine2Address() {
		return billingLine2Address;
	}

	public void setBillingLine2Address(String billingLine2Address) {
		this.billingLine2Address = billingLine2Address;
	}

	public String getBillingCityName() {
		return billingCityName;
	}

	public void setBillingCityName(String billingCityName) {
		this.billingCityName = billingCityName;
	}

	public String getBillingStateCode() {
		return billingStateCode;
	}

	public void setBillingStateCode(String billingStateCode) {
		this.billingStateCode = billingStateCode;
	}

	public String getBillingPostalCode() {
		return billingPostalCode;
	}

	public void setBillingPostalCode(String billingPostalCode) {
		this.billingPostalCode = billingPostalCode;
	}

	public String getBillingCountryName() {
		return billingCountryName;
	}

	public void setBillingCountryName(String billingCountryName) {
		this.billingCountryName = billingCountryName;
	}

	public String getSourceSystemName() {
		return sourceSystemName;
	}

	public void setSourceSystemName(String sourceSystemName) {
		this.sourceSystemName = sourceSystemName;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmployeeUserName() {
		return employeeUserName;
	}

	public void setEmployeeUserName(String employeeUserName) {
		this.employeeUserName = employeeUserName;
	}

	public String getGlCustomerSegmentCode() {
		return glCustomerSegmentCode;
	}

	public void setGlCustomerSegmentCode(String glCustomerSegmentCode) {
		this.glCustomerSegmentCode = glCustomerSegmentCode;
	}

	public String getSalesRepId() {
		return salesRepId;
	}

	public void setSalesRepId(String salesRepId) {
		this.salesRepId = salesRepId;
	}

	public String getSalesRepName() {
		return salesRepName;
	}

	public void setSalesRepName(String salesRepName) {
		this.salesRepName = salesRepName;
	}

	public String getPrevYearToDateMrc() {
		return prevYearToDateMrc;
	}

	public void setPrevYearToDateMrc(String prevYearToDateMrc) {
		this.prevYearToDateMrc = prevYearToDateMrc;
	}

	public String getThreeMonthAvgMrc() {
		return threeMonthAvgMrc;
	}

	public void setThreeMonthAvgMrc(String threeMonthAvgMrc) {
		this.threeMonthAvgMrc = threeMonthAvgMrc;
	}

	public String getCurrentMrc() {
		return currentMrc;
	}

	public void setCurrentMrc(String currentMrc) {
		this.currentMrc = currentMrc;
	}

	public String getYearToDateMrc() {
		return yearToDateMrc;
	}

	public void setYearToDateMrc(String yearToDateMrc) {
		this.yearToDateMrc = yearToDateMrc;
	}

	public String getYearToDateNrc() {
		return yearToDateNrc;
	}

	public void setYearToDateNrc(String yearToDateNrc) {
		this.yearToDateNrc = yearToDateNrc;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BillRevenueMetrics [id=");
		builder.append(id);
		builder.append(", billingLine1Address=");
		builder.append(billingLine1Address);
		builder.append(", billingLine2Address=");
		builder.append(billingLine2Address);
		builder.append(", billingCityName=");
		builder.append(billingCityName);
		builder.append(", billingStateCode=");
		builder.append(billingStateCode);
		builder.append(", billingPostalCode=");
		builder.append(billingPostalCode);
		builder.append(", billingCountryName=");
		builder.append(billingCountryName);
		builder.append(", sourceSystemName=");
		builder.append(sourceSystemName);
		builder.append(", customerNumber=");
		builder.append(customerNumber);
		builder.append(", customerName=");
		builder.append(customerName);
		builder.append(", employeeUserName=");
		builder.append(employeeUserName);
		builder.append(", glCustomerSegmentCode=");
		builder.append(glCustomerSegmentCode);
		builder.append(", salesRepId=");
		builder.append(salesRepId);
		builder.append(", salesRepName=");
		builder.append(salesRepName);
		builder.append(", prevYearToDateMrc=");
		builder.append(prevYearToDateMrc);
		builder.append(", threeMonthAvgMrc=");
		builder.append(threeMonthAvgMrc);
		builder.append(", currentMrc=");
		builder.append(currentMrc);
		builder.append(", yearToDateMrc=");
		builder.append(yearToDateMrc);
		builder.append(", yearToDateNrc=");
		builder.append(yearToDateNrc);
		builder.append("]");
		return builder.toString();
	}
}