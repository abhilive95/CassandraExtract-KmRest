package com.level3.km.services.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.level3.km.services.properties.PropertyManager;
import com.level3.km.services.resource.beans.Level3Response;
import com.level3.km.services.resource.beans.TaskOrderLookup;

/**
 * This service is not being used hence all @Path have been commented out.
 * @author agarwal.nitin
 *
 */
//@Path("/TaskOrderLookup")
public class TaskOrderLookupResource extends AbstractBaseResource
{
    /**
     * Searches for Task Order lookup data as specified by the query. Search results will be limited to 500 rows.
     * Any valid Solr query can be passed as an argument for search.
     * e.g. "q=customerOrderNumber:ORDER0212180" will translate into "select?q=customerOrderNumber:ORDER0212180"
     * 
     * @param uriInfo URI information of the current request
     * @param acceptHeader determines the Accept Header requested by the client
     * @return result of query execution on Solr in XML or JSON format. Result will be a representation
     * of TaskOrderLookup POJO.
     */
    @GET
//    @Path("search")
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response search()
    {
        return super.doQuery(TaskOrderLookup.class);
    }
    
    /**
     * Searches for Task Order lookup data as specified by the query. Search results will be limited to 500 rows.
     * Any valid Solr query can be passed as an argument for search.
     * e.g. "q=customerOrderNumber:ORDER0212180" will translate into "select?q=customerOrderNumber:ORDER0212180"
     * 
     * @param uriInfo URI information of the current request
     * @param acceptHeader determines the Accept Header requested by the client
     * @return result of query execution on Solr in XML or JSON format. Result will be native SOLR response.
     */
    @GET
//    @Path("search/raw")
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response searchRaw()
    {
        return super.doQuery();
    }
    
    /*
    @SuppressWarnings("unchecked")
    protected <T> GenericEntity<?> getTypedGenericEntity(List<T> resultList)
    {
        GenericEntity<List<TaskOrderLookup>> genericEntity = 
                new GenericEntity<List<TaskOrderLookup>>((List<TaskOrderLookup>)resultList) {};
        
        return genericEntity;
    }
    */
    
    @SuppressWarnings("unchecked")
    protected <T> Level3Response<?> getLevel3Response(List<T> resultList, long numFound, long start)
    {
        Level3Response<TaskOrderLookup> level3Response = 
                new Level3Response<TaskOrderLookup>(
                        (List<TaskOrderLookup>)resultList,
                        numFound,
                        start);
        
        return level3Response;
    }
    
    protected String getSolrUrl()
    {
        return PropertyManager.instance().getProperty(PropertyManager.TASKORDER_SOLR_URL_STR);
    }
}
