#!/bin/bash
##########################################################################
# This Script runs all commands as the unix user specified in the        #
# deploydriver.properties file                                           #
#                                                                        #
#                                                                        #
# Created by: Greg Wobermin 4/20/2011                                    #
#                                                                        #
#########################################################################

echo "INFO: Now entering \"${PWD}/deploy.sh\" script"

ENVTYPE=$1
IDCTYPE=$(echo $1|awk -F"_" '{print $2}')
ENVIRONMENT=$(echo $1|awk -F"_" '{print $1}')
PASSWD=$2
DEPLOY_PROPERTIES=$3
PANDA_DIR=$4
EXTRAPARAMS=$5

# Source properties files
. ${DEPLOY_PROPERTIES}

#DNSROOT=$(echo `hostname`|awk -F"0" '{print $1}')


# change RESTART var to upper case if applicable
RESTART=`echo ${RESTART} | tr "[a-z]" "[A-Z]"`

if [ $IDCTYPE == "idc" ];
then
   offset=${idc_offset}
   NUM_NODES=${IDC_NUM_NODES}
else
   offset=${adc_offset}
   NUM_NODES=${ADC_NUM_NODES}
fi

# Deploy the wars and copy the properties files
for (( n = ${offset}; n < $((offset+NUM_NODES)); n++ )); do
  if [ "${n}" -lt "10" ]; then
    NODE=0${n}
  else
    NODE=${n}
  fi
  
  # Deploy War Files
  for WAR in ${WARS}; do
    echo "INFO: Removing old deployments"
    DEPLOY=`echo ${WAR} | sed -e 's/.war//g'`
    echo "Issuing a command to remove \"${WAR}\" from \"${DNSROOT}${NODE}-${ENVIRONMENT}\" "
    echo "Command: rm -rf ${APPCONTAINER}/webapps/${DEPLOY}*"
    if ! ssh ${DNSROOT}${NODE}-${ENVIRONMENT} rm -rf ${APPCONTAINER}/webapps/${DEPLOY} 1>>/tmp/pandaErr.log 2>&1 ; then
      echo "WARN: Was not able to remove \"${WAR}\" from \"${DNSROOT}${NODE}-${ENVIRONMENT}\" check /tmp/pandaErr.log for more info"
    fi
  
    echo "INFO: Deploying ${WAR} to ${DNSROOT}${NODE}-${ENVIRONMENT}"
    if ! scp ${PANDA_DIR}/dist/${WAR} ${DNSROOT}${NODE}-${ENVIRONMENT}:${APPCONTAINER}/webapps 1>>/tmp/pandaErr.log 2>&1 ; then
      echo "ERROR: Was not able to deploy \"${WAR}\" to \"${DNSROOT}${NODE}-${ENVIRONMENT}\" check /tmp/pandaErr.log for more info"
      exit 1
    fi
  done

  # Deploy L3APPS files
  for FILE in ${FILES}; do
    echo "INFO: Copying ${FILE} to L3APPS directory on ${DNSROOT}${NODE}-${ENVIRONMENT}"
    if ! scp ${PANDA_DIR}/env_config/${EXTRAPARAMS}_${FILE} ${DNSROOT}${NODE}-${ENVIRONMENT}:${APPCONTAINER}/L3APPS/${FILE}  1>>/tmp/pandaErr.log 2>&1 ; then
      echo "WARN: Was not able to copy \"${FILE}\" to \"${DNSROOT}${NODE}-${ENVIRONMENT}\", check /tmp/pandaErr.log for more info"
    fi
  done

  # Restart Server
  if [ ${RESTART} == "TRUE" ]; then
    echo "INFO: RESTARTING Tomcat running on ${DNSROOT}${NODE}-${ENVIRONMENT} ${APPCONTAINER}"
    sleep 30
    ssh ${DNSROOT}${NODE}-${ENVIRONMENT} ". /app/.profile; cd ${APPCONTAINER} && ./stop_tomcat" 1>>/tmp/pandaErr.log 2>&1 &
    sleep 60
    ssh ${DNSROOT}${NODE}-${ENVIRONMENT} ". /app/.profile; cd ${APPCONTAINER} && ./start_tomcat" 1>>/tmp/pandaErr.log 2>&1 &
    echo "INFO: RESTART complete for tomcat running on ${DNSROOT}${NODE}-${ENVIRONMENT} ${APPCONTAINER}"
  fi
done

echo "INFO: Now leaving \"${PWD}/deploy.sh\" script"

