/***************   HOW TO PERFORM A MAVEN SNAPSHOT RELEASE *******************/
1. Please make sure you have setting.xml that points to Nexus repo at http://nexus01.i3.level3.com
   $ mvn -s resources/maven/settings.xml help:effective-settings
   
2. Pre deploy activities
	a. Check that there are no uncommitted changes in the source
	b. Run the project tests to confirm everything is in working order
	c. Tag the code in GIT with a version name
	   $ git tag -a km-rest-1.1-SNAPSHOT -m 'snapshot build km-rest-1.1-SNAPSHOT'
	   
3. To perform a snap shot release build, following command needs to be executed
   $ mvn -s resources/maven/settings.xml clean deploy
   
   This will build the project and deploy the artifacts to the snapshot repository as defined in pom.xml
   
4. Post deploy activites
	a. Bump the version in pom.xml to a new value y-SNAPSHOT
	b. Commit the modified pom.xml
	
	
Similar process can be used to do actual release builds as well, just strip '-SNAPSHOT' for project.version in
pom and repeat steps 2 through 4. Builds will get deployed to release repository as defined in pom.xml.

/***************   HOW TO PERFORM A MAVEN RELEASE *******************/
1. Please make sure you have setting.xml that points to Nexus repo at http://nexus01.i3.level3.com

2. To perform a release build, following command needs to be executed
   $ mvn -s ../settings.xml -Dusername=<svn username> -Dpassword=<svn password> release:clean release:prepare release:perform
   
3. release:prepare goal will do the following activities

	â€¢	Prompt user for release version info (name, number, next x-SNAPSHOT)
	â€¢	Check that there are no uncommitted changes in the source
	â€¢	Check that there are no SNAPSHOT dependencies
	â€¢	Change the version in the POMs from x-SNAPSHOT to a new version
	â€¢	Transform the SCM information in the POM to include the final destination of the tag
	â€¢	Run the project tests against the modified POMs to confirm everything is in working order
	â€¢	Commit the modified POMs
	â€¢	Tag the code in the SCM with a version name
	â€¢	Bump the version in the POMs to a new value y-SNAPSHOT
	â€¢	Commit the modified POMs
	
4. release:perform goal will do the following activities

	â€¢	Checks out release tag based on <scm> URL
	â€¢	Builds release tag
	â€¢	Deploys release binaries to remote repository (e.g. runs pre-defined Maven release goals: deploy and site-deploy)


/***************   ENVIRONMENT RELATED properties *******************/
1. Update ResourceLocator.properties for each new resource (SOLR index) and for an environment (DEV, ENV1,
   ENV2 and PROD).

2. Ensure that an EnvironmentSelector.properties is placed in the classpath ($CATALINA_HOME/lib) where the REST 
   services is deployed. This will ensure that the REST services will be mapped to the correct instance of SOLR index.


/***************   Install ojdbc6.jar into local maven repository *******************/
Execute the following command from the directory where you have ojdbc6.jar

$ mvn install:install-file -DgroupId=com.oracle -DartifactId=ojdbc6 -Dversion=11.2.0.3 -Dpackaging=jar -Dfile=ojdbc6.jar -DgeneratePom=true

In your pom.xml, now you should be able to reference the jar using the following dependency declaration

        <dependency>
		    <groupId>com.oracle</groupId>
		    <artifactId>ojdbc6</artifactId>
		    <version>11.2.0.3</version>
		</dependency>

/***************  Request to deploy REST services using PANDA *******************/
If you wish to request deploy of REST service to TEST/PROD then please raise a 3Help tkt to env support team 
for TEST/PROD env.

For PROD deploys you will also need to create an AECCR ticket as well, and make sure AECCR ticket references 
the deploy ticket.
Please contact the following DL's prior to release to coordinate the deployment and get the person assigned 
to do the deployment.
dl-ENV ASG Support <dl-ENV_ASG_Support@Level3.com>; DL-TSG Environment Support <DL-TSG_Environment_Support@Level3.com>

/***************  Request to deploy changes to SOLR index *******************/
If you wish to request changes to SOLR index then please raise a 3Help tkt to env support team for TEST env.

For PROD deploys you will need to fill out an AECCR ticket. 
Please contact the following DL's prior to release to coordinate the deployment and get the person assigned 
to do the deployment.
dl-ENV ASG Support <dl-ENV_ASG_Support@Level3.com>; DL-TSG Environment Support <DL-TSG_Environment_Support@Level3.com>

Please specify the text as follows, this is just a sample, please add additional steps as needed

"Please contact Jonathan Roof for any questions.
SOLR index name: tgcallvol
ENV - IDCPROD and ADCPROD
I need db-data-config.xml updated for tgcallvol index in IDCPROD and ADCPROD.
db-data-config.xml is on m14-13:/app/tmp/prdidc/tgcallvol 
Please 
   copy this file to kmdsidc04-prod:/app/tgcallvol/solr_indexes/tgcallvol/conf
   Run zk_upconfig.sh under /app/tgcallvol
   
   Please copy this file to kmdsadc04-prod:/app/tgcallvol/solr_indexes/tgcallvol/conf
   Run zk_upconfig.sh under /app/tgcallvol" 

/***************** Running TESTS against external container *****************/
To run these tests against an external deployment, e.g. Tomcat deployed in DEV, TEST or PROD, please pass the following VM arguments to your test.
 -Djersey.test.containerFactory=com.sun.jersey.test.framework.spi.container.external.ExternalTestContainerFactory
 -Djersey.test.port=<port>
 -Djersey.test.host=<host name>
  
If you wish to see more detailed logging from Jersey, please pass the following argument
  -DenableLogging

To run tests using maven, please do a maven build, following that issue

$ mvn test -Dtest=<Test class name>

OR to run all the tests

$ mvn test


/***************** encoded user name password for config *****************/
Username and password are encoded using RFC2045-MIME variant of Base64. 
To get the encoded string username and password are cmbined into a single string seperated by : and 
then you can go online and look for convertors that can take the <username>:<password> string 
and convert it to RFC2045-MIME variant of Base64.
The authorization header then looks like

Authorization: Basic <encoded string>
