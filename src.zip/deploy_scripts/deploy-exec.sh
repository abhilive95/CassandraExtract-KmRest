#!/bin/sh

java -Xms256m -Xmx512m -XX:MaxPermSize=256m -XX:+CMSClassUnloadingEnabled -XX:+UseConcMarkSweepGC -jar ws-exec.war

