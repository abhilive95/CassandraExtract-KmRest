package com.level3.km.services.resource.beans;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name="contact")
@XmlAccessorType(XmlAccessType.FIELD)
public class Contact
{
    @Field("id")
    private String id;
    @Field("type")
    private String type;
    @Field("sourceContactStatusCode")
    private String sourceContactStatusCode;
    @Field("firstName")
    private String firstName;
    @Field("lastName")
    private String lastName;
    @Field("cityName")
    private String cityName;
    @Field("countryName")
    private String countryName;
    @Field("emailAddress")
    private String emailAddress;
    @Field("faxNumber")
    private String faxNumber;
    @Field("line1Address")
    private String line1Address;
    @Field("line2Address")
    private String line2Address;
    @Field("pagerNumber")
    private String pagerNumber;
    @Field("postalCode")
    private String postalCode;
    @Field("phoneNumber")
    private String phoneNumber;
    @Field("secondaryPhoneNumber")
    private String secondaryPhoneNumber;
    @Field("stateCode")
    private String stateCode;
    @Field("timezoneCode")
    private String timezoneCode;
    @Field("dwLastModifyDate")
    private Date dwLastModifyDate;
    @Field("dwSourceSystemCode")
    private String dwSourceSystemCode;
    @Field("contactRoleContextType")
    private String contactRoleContextType;
    @Field("roleName")
    private String roleName;
    @Field("customerName")
    private String customerName;
    @Field("customerNumber")
    private String customerNumber;
    @Field("customerOrderNumber")
    private String customerOrderNumber;
    @Field("customerOrderVersionNumber")
    private String customerOrderVersionNumber;
    @Field("serviceOrderNumber")
    private String serviceOrderNumber;
    @Field("serviceOrderVersionNumber")
    private String serviceOrderVersionNumber;
    @Field("contactDiscriminatorType")
    private String contactDiscriminatorType;
    @Field("employeeNumber")
    private String employeeNumber;
    @Field("employeeUserName")
    private String employeeUserName;
    public String getId()
    {
        return id;
    }
    public void setId(String id)
    {
        this.id = id;
    }
    public String getType()
    {
        return type;
    }
    public void setType(String type)
    {
        this.type = type;
    }
    public String getSourceContactStatusCode()
    {
        return sourceContactStatusCode;
    }
    public void setSourceContactStatusCode(String sourceContactStatusCode)
    {
        this.sourceContactStatusCode = sourceContactStatusCode;
    }
    public String getFirstName()
    {
        return firstName;
    }
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }
    public String getLastName()
    {
        return lastName;
    }
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
    public String getCityName()
    {
        return cityName;
    }
    public void setCityName(String cityName)
    {
        this.cityName = cityName;
    }
    public String getCountryName()
    {
        return countryName;
    }
    public void setCountryName(String countryName)
    {
        this.countryName = countryName;
    }
    public String getEmailAddress()
    {
        return emailAddress;
    }
    public void setEmailAddress(String emailAddress)
    {
        this.emailAddress = emailAddress;
    }
    public String getFaxNumber()
    {
        return faxNumber;
    }
    public void setFaxNumber(String faxNumber)
    {
        this.faxNumber = faxNumber;
    }
    public String getLine1Address()
    {
        return line1Address;
    }
    public void setLine1Address(String line1Address)
    {
        this.line1Address = line1Address;
    }
    public String getLine2Address()
    {
        return line2Address;
    }
    public void setLine2Address(String line2Address)
    {
        this.line2Address = line2Address;
    }
    public String getPagerNumber()
    {
        return pagerNumber;
    }
    public void setPagerNumber(String pagerNumber)
    {
        this.pagerNumber = pagerNumber;
    }
    public String getPostalCode()
    {
        return postalCode;
    }
    public void setPostalCode(String postalCode)
    {
        this.postalCode = postalCode;
    }
    public String getPhoneNumber()
    {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }
    public String getSecondaryPhoneNumber()
    {
        return secondaryPhoneNumber;
    }
    public void setSecondaryPhoneNumber(String secondaryPhoneNumber)
    {
        this.secondaryPhoneNumber = secondaryPhoneNumber;
    }
    public String getStateCode()
    {
        return stateCode;
    }
    public void setStateCode(String stateCode)
    {
        this.stateCode = stateCode;
    }
    public String getTimezoneCode()
    {
        return timezoneCode;
    }
    public void setTimezoneCode(String timezoneCode)
    {
        this.timezoneCode = timezoneCode;
    }
    public Date getDwLastModifyDate()
    {
        return dwLastModifyDate;
    }
    public void setDwLastModifyDate(Date dwLastModifyDate)
    {
        this.dwLastModifyDate = dwLastModifyDate;
    }
    public String getDwSourceSystemCode()
    {
        return dwSourceSystemCode;
    }
    public void setDwSourceSystemCode(String dwSourceSystemCode)
    {
        this.dwSourceSystemCode = dwSourceSystemCode;
    }
    public String getContactRoleContextType()
    {
        return contactRoleContextType;
    }
    public void setContactRoleContextType(String contactRoleContextType)
    {
        this.contactRoleContextType = contactRoleContextType;
    }
    public String getRoleName()
    {
        return roleName;
    }
    public void setRoleName(String roleName)
    {
        this.roleName = roleName;
    }
    public String getCustomerName()
    {
        return customerName;
    }
    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }
    public String getCustomerNumber()
    {
        return customerNumber;
    }
    public void setCustomerNumber(String customerNumber)
    {
        this.customerNumber = customerNumber;
    }
    public String getCustomerOrderNumber()
    {
        return customerOrderNumber;
    }
    public void setCustomerOrderNumber(String customerOrderNumber)
    {
        this.customerOrderNumber = customerOrderNumber;
    }
    public String getCustomerOrderVersionNumber()
    {
        return customerOrderVersionNumber;
    }
    public void setCustomerOrderVersionNumber(String customerOrderVersionNumber)
    {
        this.customerOrderVersionNumber = customerOrderVersionNumber;
    }
    public String getServiceOrderNumber()
    {
        return serviceOrderNumber;
    }
    public void setServiceOrderNumber(String serviceOrderNumber)
    {
        this.serviceOrderNumber = serviceOrderNumber;
    }
    public String getServiceOrderVersionNumber()
    {
        return serviceOrderVersionNumber;
    }
    public void setServiceOrderVersionNumber(String serviceOrderVersionNumber)
    {
        this.serviceOrderVersionNumber = serviceOrderVersionNumber;
    }
    public String getContactDiscriminatorType()
    {
        return contactDiscriminatorType;
    }
    public void setContactDiscriminatorType(String contactDiscriminatorType)
    {
        this.contactDiscriminatorType = contactDiscriminatorType;
    }
    public String getEmployeeNumber()
    {
        return employeeNumber;
    }
    public void setEmployeeNumber(String employeeNumber)
    {
        this.employeeNumber = employeeNumber;
    }
    public String getEmployeeUserName()
    {
        return employeeUserName;
    }
    public void setEmployeeUserName(String employeeUserName)
    {
        this.employeeUserName = employeeUserName;
    }
    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("Contact [id=");
        builder.append(id);
        builder.append(", type=");
        builder.append(type);
        builder.append(", sourceContactStatusCode=");
        builder.append(sourceContactStatusCode);
        builder.append(", firstName=");
        builder.append(firstName);
        builder.append(", lastName=");
        builder.append(lastName);
        builder.append(", cityName=");
        builder.append(cityName);
        builder.append(", countryName=");
        builder.append(countryName);
        builder.append(", emailAddress=");
        builder.append(emailAddress);
        builder.append(", faxNumber=");
        builder.append(faxNumber);
        builder.append(", line1Address=");
        builder.append(line1Address);
        builder.append(", line2Address=");
        builder.append(line2Address);
        builder.append(", pagerNumber=");
        builder.append(pagerNumber);
        builder.append(", postalCode=");
        builder.append(postalCode);
        builder.append(", phoneNumber=");
        builder.append(phoneNumber);
        builder.append(", secondaryPhoneNumber=");
        builder.append(secondaryPhoneNumber);
        builder.append(", stateCode=");
        builder.append(stateCode);
        builder.append(", timezoneCode=");
        builder.append(timezoneCode);
        builder.append(", dwLastModifyDate=");
        builder.append(dwLastModifyDate);
        builder.append(", dwSourceSystemCode=");
        builder.append(dwSourceSystemCode);
        builder.append(", contactRoleContextType=");
        builder.append(contactRoleContextType);
        builder.append(", roleName=");
        builder.append(roleName);
        builder.append(", customerName=");
        builder.append(customerName);
        builder.append(", customerNumber=");
        builder.append(customerNumber);
        builder.append(", customerOrderNumber=");
        builder.append(customerOrderNumber);
        builder.append(", customerOrderVersionNumber=");
        builder.append(customerOrderVersionNumber);
        builder.append(", serviceOrderNumber=");
        builder.append(serviceOrderNumber);
        builder.append(", serviceOrderVersionNumber=");
        builder.append(serviceOrderVersionNumber);
        builder.append(", contactDiscriminatorType=");
        builder.append(contactDiscriminatorType);
        builder.append(", employeeNumber=");
        builder.append(employeeNumber);
        builder.append(", employeeUserName=");
        builder.append(employeeUserName);
        builder.append("]");
        return builder.toString();
    }
}