package com.level3.km.services.resource.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="level3Response")
@XmlAccessorType(XmlAccessType.FIELD)
public class ConfigResponse implements Serializable
{
    private static final long serialVersionUID = 3837629459394615565L;
    
	@XmlElement(name="property")
    private List<ConfigProperty> propertyList = null;
    
    public ConfigResponse()
    {
        this.propertyList = new ArrayList<ConfigProperty>();
    }
    
    public List<ConfigProperty> getPropertyList()
    {
        return propertyList;
    }

    public void addProperty(ConfigProperty configProperty)
    {
        this.propertyList.add(configProperty);
    }
    
    public void setPropertyList(List<ConfigProperty> propertyList)
    {
        this.propertyList = propertyList;
    }

    public static class ConfigProperty implements Serializable
    {
        private static final long serialVersionUID = -3033323594823683083L;
        
        private String name = null;
        private String value = null;
        
        public ConfigProperty()
        {
            
        }
        public ConfigProperty(String name, String value)
        {
            this.name = name;
            this.value = value;
        }
        
        public String getName()
        {
            return name;
        }
        public void setName(String name)
        {
            this.name = name;
        }
        public String getValue()
        {
            return value;
        }
        public void setValue(String value)
        {
            this.value = value;
        }
        
    }
}
