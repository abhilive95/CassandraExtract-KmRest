#! /bin/bash

usage()
{
cat << EOF
   usage: $0 options
   This script invokes dataimport handler on a Solr index

   OPTIONS:
   -h	Show this message
   -s host	Server where index is hosted
   -p port	Port on which index is hosted
   -i index	Name of the index
   -c true|false	Clean flag - true or false
EOF
}

HOST=
PORT=
INDEX_NAME=
CLEAN=

while getopts :s::p::i::c:h option
do
   case "${option}" in
      h) usage
         exit 1
         ;;
      s) HOST=${OPTARG};;
      p) PORT=${OPTARG};;
      i) INDEX_NAME=${OPTARG};;
      c) CLEAN=${OPTARG};;
      \?) echo "Invalid option: -$OPTARG" 
          usage
          exit 1
          ;;
      :) echo "Option -$OPTARG requires an argument."
         usage
         exit 1
         ;;
   esac
done

if [[ -z ${HOST} ]] || [[ -z ${PORT} ]] || [[ -z ${INDEX_NAME} ]] || [[ -z ${CLEAN} ]]
then
   usage
   exit 1
fi

if [[ ${CLEAN} != "true" ]] && [[ ${CLEAN} != "false" ]]
then
   echo "option c needs true or false as argument."
   exit 1
fi

URL="http://${HOST}:${PORT}/solr/${INDEX_NAME}/dataimport?command=full-import&clean=${CLEAN}"

echo "`date` :command to update ${INDEX_NAME} issued"

curl -G ${URL}
