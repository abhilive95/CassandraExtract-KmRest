#!/bin/bash

INDEX=$1

echo "Inside index_dir_check.sh"

DIRS=`ls /app/solr_indexes | grep $INDEX`

echo $DIRS
if [ -z "$DIRS" ] 
then
    echo "Index $INDEX not on server $HOSTNAME"
else
    echo "INFO: RESTARTING Jetty instances running on $HOSTNAME for index ${INDEX}/"
    for dir in ${DIRS}; do
      echo "Stopping $dir on $HOSTNAME"
        /app/solr_indexes/$dir/stop_solr
      echo "Jetty stopped....Sleeping for 30 seconds..."
        sleep 30
      echo "Starting Jetty for $dir"
        /app/solr_indexes/$dir/start_solr
      echo "Jetty started for index $dir"
    done 
fi
rm /app/index_dir_check.sh
