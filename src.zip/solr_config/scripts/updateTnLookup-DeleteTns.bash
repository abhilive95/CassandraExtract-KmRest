#! /bin/bash

LOG_FILE="./updateTnLookup-DeleteTns.log"
REMOTE_DATA_DIR="/prd1/app/informatica/infa_shared/TgtFiles/cdw_ods_tn"
FILE_PATTERN_STR="*.out"
LOCAL_DATA_DIR="/app/km_scripts/data"

DELETE_URL_PREFIX="http://localhost:8081/solr/tnlookup/update?stream.body=<delete><query>tnLookupKeyId:"
DELETE_URL_SUFFIX="</query></delete>&commitWithin=10000"
#COMMIT_URL="http://localhost:8080/tnlookupcore/tnlookupcore/update?commit=true"

function logMessage
{
   echo "`date` : $1"
}

function deleteDocument
{
   DELETE_URL="${DELETE_URL_PREFIX}\"${1}\"${DELETE_URL_SUFFIX}"
   curl -G ${DELETE_URL}
}

function commitDeletes
{
   curl -G ${COMMIT_URL}
}

function timer()
{
   sTime=$1
   eTime=$2

   dt=`expr $2 - $1`

   ds=$((dt % 60))
   dm=$(((dt / 60) % 60))
   dh=$((dt / 3600))

   elapsedTime=`printf '%d:%02d:%02d' ${dh} ${dm} ${ds}`
   logMessage "Elapsed time: ${elapsedTime} to delete ${3} records."
}

logMessage "Starting process to delete TN's"
startTime=`date '+%s'`

# get *.out files
/usr/bin/scp infa@cffprd03:${REMOTE_DATA_DIR}/${FILE_PATTERN_STR} ${LOCAL_DATA_DIR} 
RET_CODE=$?

if [ ${RET_CODE} -ne 0 ]
then
   logMessage "error while trying to scp *.out files from remote host, return code ${RET_CODE}, exiting."
   exit ${RET_CODE}
else
   logMessage "scp successful." 
fi

recordsProcessed=0

for FILE in `ls ${LOCAL_DATA_DIR}`
do
   if [ -s ${LOCAL_DATA_DIR}/${FILE} ]
   then
      logMessage "found non zero length file - ${FILE}"

      # now read contents, ignore comments
      while read -r line
      do
         # ignore commented out lines and read next line
         [[ ${line} = \#* ]] && continue
         logMessage ${line}

         # send request to delete document 
         deleteDocument ${line}

         recordsProcessed=$((recordsProcessed + 1))
      done < "${LOCAL_DATA_DIR}/${FILE}"
#   else
#     logMessage "found zero length file - ${FILE}"
   fi
done

#commitDeletes

endTime=`date '+%s'`
timer $startTime $endTime $recordsProcessed
logMessage "Completed process to delete TN's"
