package com.level3.km.services.resource;

import javax.ws.rs.core.MediaType;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.level3.km.services.exception.DataServiceError;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.ClientResponse.Status;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.representation.Form;
import com.sun.jersey.test.framework.AppDescriptor;
import com.sun.jersey.test.framework.JerseyTest;
import com.sun.jersey.test.framework.spi.container.TestContainerException;

/**
 * To run these tests against an external deployment, e.g. Tomcat deployed in DEV, TEST or PROD, please 
 * pass the following VM arguments to your test.
 * -Djersey.test.containerFactory=com.sun.jersey.test.framework.spi.container.external.ExternalTestContainerFactory
 * -Djersey.test.port=<port>
 * -Djersey.test.host=<host name>
 * 
 * If you wish to see more detailed logging from Jersey, please pass the following argument
 * -DenableLogging
 * 
 * @author agarwal.nitin
 *
 */
public class TestTrunkGroupUtilizationResource extends JerseyTest
{
    private static final String SERVLET_PATH = "Search/trunkGroupUtilization";
    
    public TestTrunkGroupUtilizationResource() throws TestContainerException
    {
        super();
    }

    @Override
    protected AppDescriptor configure()
    {
        return GenericAppDescriptor.getAppDescriptor();
    }
    
    @Override
    public void setUp() throws Exception
    {
        super.setUp();
    }

    @Override
    public void tearDown() throws Exception
    {
        super.tearDown();
    }

    private String getServletPath()
    {
        return SERVLET_PATH;
    }
    
    @Test
    public void testTrunkGroupUtilization_XML()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "billAccountNumber:*")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
    }

    @Test
    public void testTrunkGroupUtilization_JSON()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "billAccountNumber:*")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    @Test
    public void testTrunkGroupUtilization_JSONPrefered()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "billAccountNumber:*")
                .accept("application/xml;q=0.8, application/json")
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        Assert.assertFalse(MediaType.APPLICATION_XML_TYPE.equals(response.getType()));
    }

    @Test
    public void testTrunkGroupUtilization_XMLPrefered()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "billAccountNumber:*")
                .accept("application/json;q=0.8, application/xml")
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        Assert.assertFalse(MediaType.APPLICATION_JSON_TYPE.equals(response.getType()));
    }

    @Test
    public void testTrunkGroupUtilizationPing()
    {
        String xmlResponseExpected = 
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><level3Response><status>OK</status></level3Response>";
        
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("ping")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        Assert.assertEquals(xmlResponseExpected, response.getEntity(String.class));
    }

    @Test
    public void testTrunkGroupUtilizationPing_JSON()
    {
        String jsonResponseExpected = "{\"status\":\"OK\"}";
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("ping")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        Assert.assertEquals(jsonResponseExpected, response.getEntity(String.class));
    }
    
    @Test
    public void testTrunkGroupUtilizationConfig()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("config")
                .accept(MediaType.APPLICATION_XML)
                .header("Authorization", "Basic a21yZXN0OmttUmUzdA==")
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        Assert.assertTrue(response.getEntity(String.class).contains("SOLR URL"));
    }

    @Test
    public void testTrunkGroupUtilizationConfig_JSON()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("config")
                .accept(MediaType.APPLICATION_JSON)
                .header("Authorization", "Basic a21yZXN0OmttUmUzdA==")
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        Assert.assertTrue(response.getEntity(String.class).contains("SOLR URL"));
    }

    @Test
    public void testTrunkGroupUtilization_UnsupportedMediaType()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "billAccountNumber:*")
                .accept(MediaType.APPLICATION_ATOM_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.NOT_ACCEPTABLE.getStatusCode(), response.getStatus());
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(406, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(406001, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Not Acceptable", details.getExceptionDetails().getMessage());
    }
    
    @Test
    public void testTrunkGroupUtilization_LimitRows()
    {
        String rowCount = "5";
        
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "billAccountNumber:*")
                .queryParam("fl", "customerName")
                .queryParam("rows", rowCount)
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject jsonResponse = jsonObject.getJSONObject("response");
            JSONArray jsonDocs = jsonResponse.getJSONArray("docs");
            
            Assert.assertEquals(Long.parseLong(rowCount), jsonDocs.length());
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail();
        }
    }

    @Test
    public void testTrunkGroupUtilization_LimitTo500Rows()
    {
        String rowCount = "600";
        long rowCountExpected = 500;
        
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "billAccountNumber:*")
                .queryParam("fl", "customerName")
                .queryParam("rows", rowCount)     // asking for 600 rows, but we should get 500 only                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject jsonResponse = jsonObject.getJSONObject("response");
            JSONArray jsonDocs = jsonResponse.getJSONArray("docs");
            
            Assert.assertNotEquals(Long.parseLong(rowCount), jsonDocs.length());
            Assert.assertEquals(rowCountExpected, jsonDocs.length());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response cannot have more than 500 rows " + ex.getClass());
        }
    }

    @Test
    public void testTrunkGroupUtilization_NullQueryParam()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(400, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(400002, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Invalid Query String", details.getExceptionDetails().getMessage());
    }

    @Test
    public void testTrunkGroupUtilizationRaw_Level3Response()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "billAccountNumber:*")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );

            Assert.assertEquals("level3Response", document.getDocumentElement().getTagName());
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testTrunkGroupUtilization_Level3Response()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "billAccountNumber:*")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );

            Assert.assertEquals("level3Response", document.getDocumentElement().getTagName());
            Assert.assertTrue("numFound greater than zero", Long.parseLong(document.getDocumentElement().getAttribute("numFound")) > 0);
            Assert.assertEquals(0, Long.parseLong(document.getDocumentElement().getAttribute("start")));
            
            NodeList nodeList = document.getDocumentElement().getElementsByTagName("trunkGroupUtilization");
            
            Assert.assertNotNull("trunkGroupUtilization elements exist", nodeList);
            Assert.assertTrue("non zero trunkGroupUtilization elements found", nodeList.getLength() > 0);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testTrunkGroupUtilization_JsonResponse()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "*:*")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            
            Assert.assertTrue("numFound greater than zero",  jsonObject.getLong("@numFound") > 0);
            Assert.assertEquals(0, jsonObject.getLong("@start"));
            
            JSONArray jsonResponse = jsonObject.getJSONArray("trunkGroupUtilization");
            Assert.assertNotNull("trunkGroupUtilization elements exist", jsonResponse);
            Assert.assertTrue("non zero trunkGroupUtilization elements found", jsonResponse.length() > 0);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }
    
    @Test
    public void testTrunkGroupUtilization_JsonResponseSingleElementAsArray() 
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "*:*")
                .queryParam("rows", "1")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            
            Assert.assertTrue("numFound greater than zero",  jsonObject.getLong("@numFound") > 0);
            Assert.assertEquals(0, jsonObject.getLong("@start"));
            
            // even for single element an array should be returned
            JSONArray jsonResponse = jsonObject.getJSONArray("trunkGroupUtilization");
            Assert.assertNotNull("trunkGroupUtilization element exist as array", jsonResponse);
            Assert.assertTrue("One trunkGroupUtilization element found", jsonResponse.length() == 1);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }
    
    @Test
    public void testTrunkGroupUtilization_Level3ResponseException()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );

            Assert.assertEquals("level3Response", document.getDocumentElement().getTagName());
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify error response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testTrunkGroupUtilization_startTooHigh()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "customerNumber:1-DYU4P AND trunkGroupUtilizationIntervalStartDate:[NOW/DAY-10DAY TO NOW/DAY-9DAY]")
                .queryParam("start", "200")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );
            
            NodeList nodeList = document.getDocumentElement().getElementsByTagName("trunkGroupUtilization");
            
            Assert.assertTrue("trunkGroupUtilization elements does not exist", nodeList.getLength() == 0);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testTrunkGroupUtilization_facetQueryPOJOException()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "*:*")
                .queryParam("facet.query", "true")
                .queryParam("facet.field", "customerNumber")
                .queryParam("facet.method", "enum")
                .queryParam("rows", "0")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        
        Assert.assertEquals(Status.INTERNAL_SERVER_ERROR.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(500, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(500003, details.getExceptionDetails().getErrorCode());
        Assert.assertTrue(details.getExceptionDetails().getMessage().contains("Results could not be mapped to a bean"));
    }
    
    @Test
    public void testTrunkGroupUtilization_facetQueryPOJOJsonException()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "*:*")
                .queryParam("facet.query", "true")
                .queryParam("facet.field", "customerNumber")
                .queryParam("facet.method", "enum")
                .queryParam("rows", "0")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        
        Assert.assertEquals(Status.INTERNAL_SERVER_ERROR.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(500, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(500003, details.getExceptionDetails().getErrorCode());
        Assert.assertTrue(details.getExceptionDetails().getMessage().contains("Results could not be mapped to a bean"));
    }

    @Test
    public void testTrunkGroupUtilization_WithCredentialsHeader()
    {
        try
        {
            // run a query and get a customer Number
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath())
                    .queryParam("q", "-customerNumber:(20596 OR 9734)")
                    .queryParam("fl", "customerNumber")
                    .queryParam("rows", "1")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONArray jsonResponse = jsonObject.getJSONArray("trunkGroupUtilization");
            
            JSONObject tgutilObject = jsonResponse.optJSONObject(0);
            String sampleCustomerNumber = tgutilObject.optString("customerNumber");

            // run a query with the customer number retrieved above, verify we get more than 0 results
            WebResource webResource2 = resource();
            ClientResponse response2 = 
                    webResource2.path(getServletPath())
                    .queryParam("q", "customerNumber:" + sampleCustomerNumber)
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response2);
            Assert.assertEquals(Status.OK.getStatusCode(), response2.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response2.getType());
            JSONObject jsonObject2 = new JSONObject(response2.getEntity(String.class));
            
            Assert.assertTrue("numFound greater than zero",  jsonObject2.getLong("@numFound") > 0);

            // run the same query now with X-Level3-Credentials header, verify we get 0 results
            WebResource webResource3 = resource();
            ClientResponse response3 = 
                    webResource3.path(getServletPath())
                    .queryParam("q", "customerNumber:" + sampleCustomerNumber)
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response3);
            Assert.assertEquals(Status.OK.getStatusCode(), response3.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response3.getType());
            JSONObject jsonObject3 = new JSONObject(response3.getEntity(String.class));
            
            Assert.assertTrue("numFound equal to zero",  jsonObject3.getLong("@numFound") == 0);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testTrunkGroupUtilization_WithCredentialsHeader_NoFacetMinCount()
    {
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath()).path("raw")
                    .queryParam("q", "customerNumber:*")
                    .queryParam("facet", "true")
                    .queryParam("facet.field", "customerName")
                    .queryParam("rows", "0")
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject responseHeaderJson = jsonObject.getJSONObject("responseHeader");
            JSONObject responseHeaderParamsJson = responseHeaderJson.getJSONObject("params");
            
            Assert.assertNotNull("facet.mincount is set", responseHeaderParamsJson.get("facet.mincount"));
            Assert.assertEquals(1, responseHeaderParamsJson.getInt("facet.mincount"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testTrunkGroupUtilization_WithCredentialsHeader_FacetMinCountAsZero()
    {
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath()).path("raw")
                    .queryParam("q", "customerNumber:*")
                    .queryParam("facet", "true")
                    .queryParam("facet.field", "customerName")
                    .queryParam("facet.mincount", "0")
                    .queryParam("rows", "0")
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject responseHeaderJson = jsonObject.getJSONObject("responseHeader");
            JSONObject responseHeaderParamsJson = responseHeaderJson.getJSONObject("params");
            
            Assert.assertNotNull("facet.mincount is set", responseHeaderParamsJson.get("facet.mincount"));
            Assert.assertEquals(1, responseHeaderParamsJson.getInt("facet.mincount"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testTrunkGroupUtilization_WithCredentialsHeader_FacetMinCountGreaterThanOne()
    {
        String facetMincountValue = "3";
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath()).path("raw")
                    .queryParam("q", "customerNumber:*")
                    .queryParam("facet", "true")
                    .queryParam("facet.field", "customerName")
                    .queryParam("facet.mincount", facetMincountValue)
                    .queryParam("rows", "0")
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject responseHeaderJson = jsonObject.getJSONObject("responseHeader");
            JSONObject responseHeaderParamsJson = responseHeaderJson.getJSONObject("params");
            
            Assert.assertNotNull("facet.mincount is set", responseHeaderParamsJson.get("facet.mincount"));
            Assert.assertEquals(Integer.parseInt(facetMincountValue), responseHeaderParamsJson.getInt("facet.mincount"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testTrunkGroupUtilization_WithCredentialsHeader_FacetAsOn()
    {
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath()).path("raw")
                    .queryParam("q", "customerNumber:*")
                    .queryParam("facet", "on")
                    .queryParam("facet.field", "customerName")
                    .queryParam("rows", "0")
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject responseHeaderJson = jsonObject.getJSONObject("responseHeader");
            JSONObject responseHeaderParamsJson = responseHeaderJson.getJSONObject("params");
            
            Assert.assertNotNull("facet.mincount is set", responseHeaderParamsJson.get("facet.mincount"));
            Assert.assertEquals(1, responseHeaderParamsJson.getInt("facet.mincount"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testTrunkGroupUtilization_WithCredentialsHeader_FacetMinCountForFieldAsZero()
    {
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath()).path("raw")
                    .queryParam("q", "customerNumber:*")
                    .queryParam("facet", "true")
                    .queryParam("facet.field", "customerName")
                    .queryParam("f.customerNumber.facet.mincount", "0")
                    .queryParam("rows", "0")
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject responseHeaderJson = jsonObject.getJSONObject("responseHeader");
            JSONObject responseHeaderParamsJson = responseHeaderJson.getJSONObject("params");
            
            Assert.assertNotNull("facet.mincount is set", responseHeaderParamsJson.get("facet.mincount"));
            Assert.assertEquals(1, responseHeaderParamsJson.getInt("facet.mincount"));
            Assert.assertNotNull("f.customerNumber.facet.mincount is set", responseHeaderParamsJson.get("f.customerNumber.facet.mincount"));
            Assert.assertEquals(1, responseHeaderParamsJson.getInt("f.customerNumber.facet.mincount"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testTrunkGroupUtilization_WithCredentialsHeader_FacetMinCountNotANumber()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .queryParam("facet", "true")
                .queryParam("facet.field", "customerName")
                .queryParam("facet.mincount", "r")
                .queryParam("rows", "0")
                .header("X-Level3-Credentials", "20596, 9734")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

        DataServiceError details = response.getEntity(DataServiceError.class);

        Assert.assertNotNull(details);
        Assert.assertEquals(400, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(400002, details.getExceptionDetails().getErrorCode());
        Assert.assertTrue(details.getExceptionDetails().getMessage().contains("Invalid Query String"));
        Assert.assertTrue(details.getExceptionDetails().getDetail().contains("could not convert facet.mincount value to a number"));
    }

    @Test
    public void testTrunkGroupUtilization_XML_Post()
    {
        WebResource webResource = resource();
        
        Form form = new Form();
        form.add("q", "billAccountNumber:*");

        ClientResponse response = 
                webResource.path(getServletPath())
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_XML)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
    }

    @Test
    public void testTrunkGroupUtilization_JSON_Post()
    {
        WebResource webResource = resource();

        Form form = new Form();
        form.add("q", "billAccountNumber:*");

        ClientResponse response = 
                webResource.path(getServletPath())
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    @Test
    public void testTrunkGroupUtilization_NullQueryParam_Post()
    {
        WebResource webResource = resource();
        Form form = new Form();
        ClientResponse response = 
                webResource.path(getServletPath())
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(400, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(400002, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Invalid Query String", details.getExceptionDetails().getMessage());
    }

    @Test
    public void testTrunkGroupUtilizationRaw_XML_Post()
    {
        WebResource webResource = resource();
        
        Form form = new Form();
        form.add("q", "billAccountNumber:*");

        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_XML)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
    }

    @Test
    public void testTrunkGroupUtilizationRaw_JSON_Post()
    {
        WebResource webResource = resource();

        Form form = new Form();
        form.add("q", "billAccountNumber:*");

        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    @Test
    public void testTrunkGroupUtilizationRaw_NullQueryParam_Post()
    {
        WebResource webResource = resource();
        Form form = new Form();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(400, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(400002, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Invalid Query String", details.getExceptionDetails().getMessage());
    }

    @Test
    public void testTrunkGroupUtilization_LimitDeepPaging()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .queryParam("start", "500000")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.INTERNAL_SERVER_ERROR.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(500, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(500004, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Too many results requested, please filter the query", details.getExceptionDetails().getMessage());
    }

    @Test
    public void testTrunkGroupUtilization_LimitDeepPagingFirstStartParamEval()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .queryParam("start", "500000")
                .queryParam("start", "10")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.INTERNAL_SERVER_ERROR.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(500, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(500004, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Too many results requested, please filter the query", details.getExceptionDetails().getMessage());
    }

}
