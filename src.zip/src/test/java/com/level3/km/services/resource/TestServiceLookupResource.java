package com.level3.km.services.resource;

import javax.ws.rs.core.MediaType;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Assume;
import org.junit.Test;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.level3.km.services.exception.DataServiceError;
import com.level3.km.services.properties.PropertyManager;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.ClientResponse.Status;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.api.representation.Form;
import com.sun.jersey.test.framework.AppDescriptor;
import com.sun.jersey.test.framework.JerseyTest;
import com.sun.jersey.test.framework.spi.container.TestContainerException;

/**
 * To run these tests against an external deployment, e.g. Tomcat deployed in DEV, TEST or PROD, please 
 * pass the following VM arguments to your test.
 * -Djersey.test.containerFactory=com.sun.jersey.test.framework.spi.container.external.ExternalTestContainerFactory
 * -Djersey.test.port=<port>
 * -Djersey.test.host=<host name>
 * 
 * If you wish to see more detailed logging from Jersey, please pass the following argument
 * -DenableLogging
 * 
 * @author agarwal.nitin
 *
 */
public class TestServiceLookupResource extends JerseyTest
{
    private static final String SERVLET_PATH = "Search/serviceLookup";
    
    public TestServiceLookupResource() throws TestContainerException
    {
        super();
    }

    @Override
    protected AppDescriptor configure()
    {
        return GenericAppDescriptor.getAppDescriptor();
    }
    
    @Override
    public void setUp() throws Exception
    {
        super.setUp();
    }

    @Override
    public void tearDown() throws Exception
    {
        super.tearDown();
    }

    private String getServletPath()
    {
        return SERVLET_PATH;
    }
    
    @Test
    public void testServiceLookup_XML()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
    }

    @Test
    public void testServiceLookup_JSON()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    @Test
    public void testServiceLookup_JSONPrefered()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .accept("application/xml;q=0.8, application/json")
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        Assert.assertFalse(MediaType.APPLICATION_XML_TYPE.equals(response.getType()));
    }

    @Test
    public void testServiceLookup_XMLPrefered()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .accept("application/json;q=0.8, application/xml")
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        Assert.assertFalse(MediaType.APPLICATION_JSON_TYPE.equals(response.getType()));
    }

    @Test
    public void testServiceLookupPing()
    {
        String xmlResponseExpected = 
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><level3Response><status>OK</status></level3Response>";
        
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("ping")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        Assert.assertEquals(xmlResponseExpected, response.getEntity(String.class));
    }

    @Test
    public void testServiceLookupPing_JSON()
    {
        String jsonResponseExpected = "{\"status\":\"OK\"}";
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("ping")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        Assert.assertEquals(jsonResponseExpected, response.getEntity(String.class));
    }
    
    @Test
    public void testServiceLookupConfig()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("config")
                .accept(MediaType.APPLICATION_XML)
                .header("Authorization", "Basic a21yZXN0OmttUmUzdA==")
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        Assert.assertTrue(response.getEntity(String.class).contains("SOLR URL"));
    }

    @Test
    public void testServiceLookupConfig_JSON()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("config")
                .accept(MediaType.APPLICATION_JSON)
                .header("Authorization", "Basic a21yZXN0OmttUmUzdA==")
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        Assert.assertTrue(response.getEntity(String.class).contains("SOLR URL"));
    }

    @Test
    public void testServiceLookup_UnsupportedMediaType()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .accept(MediaType.APPLICATION_ATOM_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.NOT_ACCEPTABLE.getStatusCode(), response.getStatus());
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(406, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(406001, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Not Acceptable", details.getExceptionDetails().getMessage());
    }
    
    @Test
    public void testServiceLookup_LimitRows()
    {
        String rowCount = "5";
        
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .queryParam("fl", "customerName")
                .queryParam("rows", rowCount)
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject jsonResponse = jsonObject.getJSONObject("response");
            JSONArray jsonDocs = jsonResponse.getJSONArray("docs");
            
            Assert.assertEquals(Long.parseLong(rowCount), jsonDocs.length());
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Assert.fail();
        }
    }

    @Test
    public void testServiceLookup_LimitTo500Rows()
    {
        String rowCount = "600";
        long rowCountExpected = 500;
        
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .queryParam("fl", "customerName")
                .queryParam("rows", rowCount)     // asking for 600 rows, but we should get 500 only                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject jsonResponse = jsonObject.getJSONObject("response");
            JSONArray jsonDocs = jsonResponse.getJSONArray("docs");
            
            Assert.assertNotEquals(Long.parseLong(rowCount), jsonDocs.length());
            Assert.assertEquals(rowCountExpected, jsonDocs.length());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response cannot have more than 500 rows " + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_NullQueryParam()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(400, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(400002, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Invalid Query String", details.getExceptionDetails().getMessage());
    }

    @Test
    public void testServiceLookupRaw_Level3Response()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );

            Assert.assertEquals("level3Response", document.getDocumentElement().getTagName());
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testServiceLookup_Level3Response()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "customerNumber:*")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );

            Assert.assertEquals("level3Response", document.getDocumentElement().getTagName());
            Assert.assertTrue("numFound greater than zero", Long.parseLong(document.getDocumentElement().getAttribute("numFound")) > 0);
            Assert.assertEquals(0, Long.parseLong(document.getDocumentElement().getAttribute("start")));
            
            NodeList nodeList = document.getDocumentElement().getElementsByTagName("serviceLookup");
            
            Assert.assertNotNull("serviceLookup elements exist", nodeList);
            Assert.assertTrue("non zero serviceLookup elements found", nodeList.getLength() > 0);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testServiceLookup_JsonResponse()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "customerNumber:*")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            
            Assert.assertTrue("numFound greater than zero",  jsonObject.getLong("@numFound") > 0);
            Assert.assertEquals(0, jsonObject.getLong("@start"));
            
            JSONArray jsonResponse = jsonObject.getJSONArray("serviceLookup");
            Assert.assertNotNull("serviceLookup elements exist", jsonResponse);
            Assert.assertTrue("non zero serviceLookup elements found", jsonResponse.length() > 0);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }
    
    @Test
    public void testServiceLookup_JsonResponseSingleElementAsArray() 
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "customerNumber:*")
                .queryParam("rows", "1")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            
            Assert.assertTrue("numFound greater than zero",  jsonObject.getLong("@numFound") > 0);
            Assert.assertEquals(0, jsonObject.getLong("@start"));
            
            // even for single element an array should be returned
            JSONArray jsonResponse = jsonObject.getJSONArray("serviceLookup");
            Assert.assertNotNull("serviceLookup element exist as array", jsonResponse);
            Assert.assertTrue("One serviceLookup element found", jsonResponse.length() == 1);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }
    
    @Test
    public void testServiceLookup_Level3ResponseException()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );

            Assert.assertEquals("level3Response", document.getDocumentElement().getTagName());
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify error response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testServiceLookup_startTooHigh()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "serviceOrderStatusCode:pcns")
                .queryParam("start", "20")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        
        try
        {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse( response.getEntityInputStream() );
            
            NodeList nodeList = document.getDocumentElement().getElementsByTagName("serviceLookup");
            
            Assert.assertTrue("serviceLookup elements does not exist", nodeList.getLength() == 0);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response XML is wrapped in 'level3Response'" + ex.getClass());
        }
    }
    
    @Test
    public void testServiceLookup_facetQueryPOJOException()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "*:*")
                .queryParam("facet.query", "true")
                .queryParam("facet.field", "dwSourceSystemCode")
                .queryParam("facet.method", "enum")
                .queryParam("rows", "0")
                .accept(MediaType.APPLICATION_XML)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.INTERNAL_SERVER_ERROR.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(500, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(500003, details.getExceptionDetails().getErrorCode());
        Assert.assertTrue(details.getExceptionDetails().getMessage().contains("Results could not be mapped to a bean"));
    }
    
    @Test
    public void testServiceLookup_facetQueryPOJOJsonException()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "*:*")
                .queryParam("facet.query", "true")
                .queryParam("facet.field", "dwSourceSystemCode")
                .queryParam("facet.method", "enum")
                .queryParam("rows", "0")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.INTERNAL_SERVER_ERROR.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(500, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(500003, details.getExceptionDetails().getErrorCode());
        Assert.assertTrue(details.getExceptionDetails().getMessage().contains("Results could not be mapped to a bean"));
    }

    @Test
    public void testServiceLookup_WithCredentialsHeader()
    {
        try
        {
            // run a query and get a customer Number
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath())
                    .queryParam("q", "customerNumber:[* TO *] AND -customerNumber:(20596 OR 9734)")   // not null customerNumber and customerNumber not in (20596 OR 9734)
                    .queryParam("fl", "customerNumber")
                    .queryParam("rows", "1")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONArray jsonResponse = jsonObject.getJSONArray("serviceLookup");
            
            JSONObject slvObject = jsonResponse.optJSONObject(0);
            String sampleCustomerNumber = slvObject.optString("customerNumber");

            // run a query with the customer number retrieved above, verify we get more than 0 results
            WebResource webResource2 = resource();
            ClientResponse response2 = 
                    webResource2.path(getServletPath())
                    .queryParam("q", "customerNumber:" + sampleCustomerNumber)
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response2);
            Assert.assertEquals(Status.OK.getStatusCode(), response2.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response2.getType());
            JSONObject jsonObject2 = new JSONObject(response2.getEntity(String.class));
            
            Assert.assertTrue("numFound greater than zero",  jsonObject2.getLong("@numFound") > 0);

            // run the same query now with X-Level3-Credentials header, verify we get 0 results
            WebResource webResource3 = resource();
            ClientResponse response3 = 
                    webResource3.path(getServletPath())
                    .queryParam("q", "customerNumber:" + sampleCustomerNumber)
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response3);
            Assert.assertEquals(Status.OK.getStatusCode(), response3.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response3.getType());
            JSONObject jsonObject3 = new JSONObject(response3.getEntity(String.class));
            
            Assert.assertTrue("numFound equal to zero",  jsonObject3.getLong("@numFound") == 0);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_WithCredentialsHeader_NoFacetMinCount()
    {
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath()).path("raw")
                    .queryParam("q", "customerNumber:*")
                    .queryParam("facet", "true")
                    .queryParam("facet.field", "customerName")
                    .queryParam("rows", "0")
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject responseHeaderJson = jsonObject.getJSONObject("responseHeader");
            JSONObject responseHeaderParamsJson = responseHeaderJson.getJSONObject("params");
            
            Assert.assertNotNull("facet.mincount is set", responseHeaderParamsJson.get("facet.mincount"));
            Assert.assertEquals(1, responseHeaderParamsJson.getInt("facet.mincount"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_WithCredentialsHeader_FacetMinCountAsZero()
    {
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath()).path("raw")
                    .queryParam("q", "customerNumber:*")
                    .queryParam("facet", "true")
                    .queryParam("facet.field", "customerName")
                    .queryParam("facet.mincount", "0")
                    .queryParam("rows", "0")
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject responseHeaderJson = jsonObject.getJSONObject("responseHeader");
            JSONObject responseHeaderParamsJson = responseHeaderJson.getJSONObject("params");
            
            Assert.assertNotNull("facet.mincount is set", responseHeaderParamsJson.get("facet.mincount"));
            Assert.assertEquals(1, responseHeaderParamsJson.getInt("facet.mincount"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_WithCredentialsHeader_FacetMinCountGreaterThanOne()
    {
        String facetMincountValue = "3";
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath()).path("raw")
                    .queryParam("q", "customerNumber:*")
                    .queryParam("facet", "true")
                    .queryParam("facet.field", "customerName")
                    .queryParam("facet.mincount", facetMincountValue)
                    .queryParam("rows", "0")
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject responseHeaderJson = jsonObject.getJSONObject("responseHeader");
            JSONObject responseHeaderParamsJson = responseHeaderJson.getJSONObject("params");
            
            Assert.assertNotNull("facet.mincount is set", responseHeaderParamsJson.get("facet.mincount"));
            Assert.assertEquals(Integer.parseInt(facetMincountValue), responseHeaderParamsJson.getInt("facet.mincount"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_WithCredentialsHeader_FacetAsOn()
    {
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath()).path("raw")
                    .queryParam("q", "customerNumber:*")
                    .queryParam("facet", "on")
                    .queryParam("facet.field", "customerName")
                    .queryParam("rows", "0")
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject responseHeaderJson = jsonObject.getJSONObject("responseHeader");
            JSONObject responseHeaderParamsJson = responseHeaderJson.getJSONObject("params");
            
            Assert.assertNotNull("facet.mincount is set", responseHeaderParamsJson.get("facet.mincount"));
            Assert.assertEquals(1, responseHeaderParamsJson.getInt("facet.mincount"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_WithCredentialsHeader_FacetMinCountForFieldAsZero()
    {
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(getServletPath()).path("raw")
                    .queryParam("q", "customerNumber:*")
                    .queryParam("facet", "true")
                    .queryParam("facet.field", "customerName")
                    .queryParam("f.customerNumber.facet.mincount", "0")
                    .queryParam("rows", "0")
                    .header("X-Level3-Credentials", "20596, 9734")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response);
            Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            JSONObject responseHeaderJson = jsonObject.getJSONObject("responseHeader");
            JSONObject responseHeaderParamsJson = responseHeaderJson.getJSONObject("params");
            
            Assert.assertNotNull("facet.mincount is set", responseHeaderParamsJson.get("facet.mincount"));
            Assert.assertEquals(1, responseHeaderParamsJson.getInt("facet.mincount"));
            Assert.assertNotNull("f.customerNumber.facet.mincount is set", responseHeaderParamsJson.get("f.customerNumber.facet.mincount"));
            Assert.assertEquals(1, responseHeaderParamsJson.getInt("f.customerNumber.facet.mincount"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_WithCredentialsHeader_FacetMinCountNotANumber()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .queryParam("facet", "true")
                .queryParam("facet.field", "customerName")
                .queryParam("facet.mincount", "r")
                .queryParam("rows", "0")
                .header("X-Level3-Credentials", "20596, 9734")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);

        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());

        DataServiceError details = response.getEntity(DataServiceError.class);

        Assert.assertNotNull(details);
        Assert.assertEquals(400, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(400002, details.getExceptionDetails().getErrorCode());
        Assert.assertTrue(details.getExceptionDetails().getMessage().contains("Invalid Query String"));
        Assert.assertTrue(details.getExceptionDetails().getDetail().contains("could not convert facet.mincount value to a number"));
    }

    @Test
    public void testServiceLookup_relatedServiceInstanceIdLevel1Json()
    {
        // 1. Get a service lookup record
        // 2. Update relatedServiceInstanceIdLevel1 attribute
        // 3. Retrieve the updated serviceLocation record and verify relatedServiceInstanceIdLevel1 is returned as an Array.
        
        // This test is executed only against DEV environment, when executing it against External setup, we do not run this test
        Assume.assumeFalse(getTestContainerFactory().getClass().getName().endsWith("ExternalTestContainerFactory"));

        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "dwSourceSystemCode:UKDW_CLARIFY_UK")
                .queryParam("rows", "1")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            
            JSONArray jsonResponse = jsonObject.getJSONArray("serviceLookup");
            
            JSONObject serviceLookupObject = jsonResponse.optJSONObject(0);
            String id = serviceLookupObject.optString("id");
            JSONArray relatedServiceInstanceIdLevel1Array = serviceLookupObject.optJSONArray("relatedServiceInstanceIdLevel1");
            // convert to String, "," delimited
            String relatedServiceInstanceIdLevel1Str = null;
            boolean addSeperator = false;
            if(relatedServiceInstanceIdLevel1Array != null)
            {
                for(int index = 0;index < relatedServiceInstanceIdLevel1Array.length(); ++index)
                {
                    if(addSeperator)
                    {
                        relatedServiceInstanceIdLevel1Str += ", ";
                    }
                    relatedServiceInstanceIdLevel1Str += relatedServiceInstanceIdLevel1Array.optString(index);
                }
            }
            
            // update relatedServiceInstanceIdLevel1 field for this record
            String relatedServiceInstanceIdLevel1 = "SLV_TEST_1" + System.currentTimeMillis();
            String updateDoc =
                    "[{\"id\":\"" + id + "\",\"relatedServiceInstanceIdLevel1\":{\"set\":\"" + relatedServiceInstanceIdLevel1 + "\"}}]";
            
            String baseUrl = PropertyManager.instance().getProperty(PropertyManager.SLV_SOLR_URL_STR);
            
            String url = baseUrl.replace("select", "update/json?commitWithin=5000");
            
            Client client = Client.create();
            client.addFilter(
                new HTTPBasicAuthFilter(
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_USERNAME_STR),
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_PASSWORD_STR)));
            WebResource webResource2 = client.resource(url);
            
            ClientResponse responsePost = 
                    webResource2.accept(MediaType.APPLICATION_JSON_TYPE)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .post(ClientResponse.class, updateDoc);
            
            Assert.assertNotNull(responsePost);
            Assert.assertEquals(Status.OK.getStatusCode(), responsePost.getStatus());
            
            // sleep for 7 seconds, then get the document
            Thread.sleep(7000L);
            
            // verify that relatedServiceInstanceIdLevel1 is set and is returned as an array
            WebResource webResource3 = resource();
            ClientResponse response3 = 
                    webResource3.path(getServletPath())
                    .queryParam("q", "id:\"" + id + "\"")
                    .queryParam("rows", "1")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response3);
            Assert.assertEquals(Status.OK.getStatusCode(), response3.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response3.getType());
            
            JSONObject jsonObject2 = new JSONObject(response3.getEntity(String.class));

            JSONArray jsonResponse2 = jsonObject2.getJSONArray("serviceLookup");
            
            JSONObject relatedServiceInstanceIdLevel1Object2 = jsonResponse2.optJSONObject(0);
            Assert.assertNotNull("Not null relatedServiceInstanceIdLevel1 element", relatedServiceInstanceIdLevel1Object2);
            JSONArray relatedServiceInstanceIdLevel12 = relatedServiceInstanceIdLevel1Object2.getJSONArray("relatedServiceInstanceIdLevel1");
            Assert.assertNotNull("relatedServiceInstanceIdLevel1 is a not null JSONArray", relatedServiceInstanceIdLevel12);
            Assert.assertTrue("relatedServiceInstanceIdLevel1 retrived", relatedServiceInstanceIdLevel1.equals(relatedServiceInstanceIdLevel12.get(0)));
            
            // reset the relatedServiceInstanceIdLevel1
            String updateDoc2 = "[{\"id\":\"" + id + "\",\"relatedServiceInstanceIdLevel1\":{\"set\":" + (relatedServiceInstanceIdLevel1Str != null ? "\"" + relatedServiceInstanceIdLevel1Str + "\"" : null) + "}}]";
            
            ClientResponse responsePost4 = 
                    webResource2.accept(MediaType.APPLICATION_JSON_TYPE)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .post(ClientResponse.class, updateDoc2);
            
            Assert.assertNotNull(responsePost4);
            Assert.assertEquals(Status.OK.getStatusCode(), responsePost4.getStatus());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_relatedServiceInstanceIdLevel2Json()
    {
        // 1. Get a service lookup record
        // 2. Update relatedServiceInstanceIdLevel2 attribute
        // 3. Retrieve the updated serviceLocation record and verify relatedServiceInstanceIdLevel2 is returned as an Array.
        
        // This test is executed only against DEV environment, when executing it against External setup, we do not run this test
        Assume.assumeFalse(getTestContainerFactory().getClass().getName().endsWith("ExternalTestContainerFactory"));

        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "dwSourceSystemCode:UKDW_CLARIFY_UK")
                .queryParam("rows", "1")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            
            JSONArray jsonResponse = jsonObject.getJSONArray("serviceLookup");
            
            JSONObject serviceLookupObject = jsonResponse.optJSONObject(0);
            String id = serviceLookupObject.optString("id");
            JSONArray relatedServiceInstanceIdLevel2Array = serviceLookupObject.optJSONArray("relatedServiceInstanceIdLevel2");
            // convert to String, "," delimited
            String relatedServiceInstanceIdLevel2Str = null;
            boolean addSeperator = false;
            if(relatedServiceInstanceIdLevel2Array != null)
            {
                for(int index = 0;index < relatedServiceInstanceIdLevel2Array.length(); ++index)
                {
                    if(addSeperator)
                    {
                        relatedServiceInstanceIdLevel2Str += ", ";
                    }
                    relatedServiceInstanceIdLevel2Str += relatedServiceInstanceIdLevel2Array.optString(index);
                }
            }
            
            // update relatedServiceInstanceIdLevel2 field for this record
            String relatedServiceInstanceIdLevel2 = "SLV_TEST_1" + System.currentTimeMillis();
            String updateDoc =
                    "[{\"id\":\"" + id + "\",\"relatedServiceInstanceIdLevel2\":{\"set\":\"" + relatedServiceInstanceIdLevel2 + "\"}}]";
            
            String baseUrl = PropertyManager.instance().getProperty(PropertyManager.SLV_SOLR_URL_STR);
            
            String url = baseUrl.replace("select", "update/json?commitWithin=5000");
            
            Client client = Client.create();
            client.addFilter(
                new HTTPBasicAuthFilter(
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_USERNAME_STR),
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_PASSWORD_STR)));
            WebResource webResource2 = client.resource(url);
            
            ClientResponse responsePost = 
                    webResource2.accept(MediaType.APPLICATION_JSON_TYPE)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .post(ClientResponse.class, updateDoc);
            
            Assert.assertNotNull(responsePost);
            Assert.assertEquals(Status.OK.getStatusCode(), responsePost.getStatus());
            
            // sleep for 7 seconds, then get the document
            Thread.sleep(7000L);
            
            // verify that relatedServiceInstanceIdLevel2 is set and is returned as an array
            WebResource webResource3 = resource();
            ClientResponse response3 = 
                    webResource3.path(getServletPath())
                    .queryParam("q", "id:\"" + id + "\"")
                    .queryParam("rows", "1")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response3);
            Assert.assertEquals(Status.OK.getStatusCode(), response3.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response3.getType());
            
            JSONObject jsonObject2 = new JSONObject(response3.getEntity(String.class));

            JSONArray jsonResponse2 = jsonObject2.getJSONArray("serviceLookup");
            
            JSONObject relatedServiceInstanceIdLevel2Object2 = jsonResponse2.optJSONObject(0);
            Assert.assertNotNull("Not null relatedServiceInstanceIdLevel2 element", relatedServiceInstanceIdLevel2Object2);
            JSONArray relatedServiceInstanceIdLevel22 = relatedServiceInstanceIdLevel2Object2.getJSONArray("relatedServiceInstanceIdLevel2");
            Assert.assertNotNull("relatedServiceInstanceIdLevel2 is a not null JSONArray", relatedServiceInstanceIdLevel22);
            Assert.assertTrue("relatedServiceInstanceIdLevel2 retrived", relatedServiceInstanceIdLevel2.equals(relatedServiceInstanceIdLevel22.get(0)));
            
            // reset the relatedServiceInstanceIdLevel2
            String updateDoc2 = "[{\"id\":\"" + id + "\",\"relatedServiceInstanceIdLevel2\":{\"set\":" + (relatedServiceInstanceIdLevel2Str != null ? "\"" + relatedServiceInstanceIdLevel2Str + "\"" : null) + "}}]";
            
            ClientResponse responsePost4 = 
                    webResource2.accept(MediaType.APPLICATION_JSON_TYPE)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .post(ClientResponse.class, updateDoc2);
            
            Assert.assertNotNull(responsePost4);
            Assert.assertEquals(Status.OK.getStatusCode(), responsePost4.getStatus());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_relatedServiceInstanceIdLevel3Json()
    {
        // 1. Get a service lookup record
        // 2. Update relatedServiceInstanceIdLevel3 attribute
        // 3. Retrieve the updated serviceLocation record and verify relatedServiceInstanceIdLevel3 is returned as an Array.
        
        // This test is executed only against DEV environment, when executing it against External setup, we do not run this test
        Assume.assumeFalse(getTestContainerFactory().getClass().getName().endsWith("ExternalTestContainerFactory"));

        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "dwSourceSystemCode:UKDW_CLARIFY_UK")
                .queryParam("rows", "1")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            
            JSONArray jsonResponse = jsonObject.getJSONArray("serviceLookup");
            
            JSONObject serviceLookupObject = jsonResponse.optJSONObject(0);
            String id = serviceLookupObject.optString("id");
            JSONArray relatedServiceInstanceIdLevel3Array = serviceLookupObject.optJSONArray("relatedServiceInstanceIdLevel3");
            // convert to String, "," delimited
            String relatedServiceInstanceIdLevel3Str = null;
            boolean addSeperator = false;
            if(relatedServiceInstanceIdLevel3Array != null)
            {
                for(int index = 0;index < relatedServiceInstanceIdLevel3Array.length(); ++index)
                {
                    if(addSeperator)
                    {
                        relatedServiceInstanceIdLevel3Str += ", ";
                    }
                    relatedServiceInstanceIdLevel3Str += relatedServiceInstanceIdLevel3Array.optString(index);
                }
            }
            
            // update relatedServiceInstanceIdLevel3 field for this record
            String relatedServiceInstanceIdLevel3 = "SLV_TEST_1" + System.currentTimeMillis();
            String updateDoc =
                    "[{\"id\":\"" + id + "\",\"relatedServiceInstanceIdLevel3\":{\"set\":\"" + relatedServiceInstanceIdLevel3 + "\"}}]";
            
            String baseUrl = PropertyManager.instance().getProperty(PropertyManager.SLV_SOLR_URL_STR);
            
            String url = baseUrl.replace("select", "update/json?commitWithin=5000");
            
            Client client = Client.create();
            client.addFilter(
                new HTTPBasicAuthFilter(
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_USERNAME_STR),
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_PASSWORD_STR)));
            WebResource webResource2 = client.resource(url);
            
            ClientResponse responsePost = 
                    webResource2.accept(MediaType.APPLICATION_JSON_TYPE)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .post(ClientResponse.class, updateDoc);
            
            Assert.assertNotNull(responsePost);
            Assert.assertEquals(Status.OK.getStatusCode(), responsePost.getStatus());
            
            // sleep for 7 seconds, then get the document
            Thread.sleep(7000L);
            
            // verify that relatedServiceInstanceIdLevel3 is set and is returned as an array
            WebResource webResource3 = resource();
            ClientResponse response3 = 
                    webResource3.path(getServletPath())
                    .queryParam("q", "id:\"" + id + "\"")
                    .queryParam("rows", "1")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response3);
            Assert.assertEquals(Status.OK.getStatusCode(), response3.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response3.getType());
            
            JSONObject jsonObject2 = new JSONObject(response3.getEntity(String.class));

            JSONArray jsonResponse2 = jsonObject2.getJSONArray("serviceLookup");
            
            JSONObject relatedServiceInstanceIdLevel3Object2 = jsonResponse2.optJSONObject(0);
            Assert.assertNotNull("Not null relatedServiceInstanceIdLevel3 element", relatedServiceInstanceIdLevel3Object2);
            JSONArray relatedServiceInstanceIdLevel32 = relatedServiceInstanceIdLevel3Object2.getJSONArray("relatedServiceInstanceIdLevel3");
            Assert.assertNotNull("relatedServiceInstanceIdLevel3 is a not null JSONArray", relatedServiceInstanceIdLevel32);
            Assert.assertTrue("relatedServiceInstanceIdLevel3 retrived", relatedServiceInstanceIdLevel3.equals(relatedServiceInstanceIdLevel32.get(0)));
            
            // reset the relatedServiceInstanceIdLevel3
            String updateDoc2 = "[{\"id\":\"" + id + "\",\"relatedServiceInstanceIdLevel3\":{\"set\":" + (relatedServiceInstanceIdLevel3Str != null ? "\"" + relatedServiceInstanceIdLevel3Str + "\"" : null) + "}}]";
            
            ClientResponse responsePost4 = 
                    webResource2.accept(MediaType.APPLICATION_JSON_TYPE)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .post(ClientResponse.class, updateDoc2);
            
            Assert.assertNotNull(responsePost4);
            Assert.assertEquals(Status.OK.getStatusCode(), responsePost4.getStatus());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_relatedServiceInstanceIdLevel4Json()
    {
        // 1. Get a service lookup record
        // 2. Update relatedServiceInstanceIdLevel4 attribute
        // 3. Retrieve the updated serviceLocation record and verify relatedServiceInstanceIdLevel4 is returned as an Array.
        
        // This test is executed only against DEV environment, when executing it against External setup, we do not run this test
        Assume.assumeFalse(getTestContainerFactory().getClass().getName().endsWith("ExternalTestContainerFactory"));

        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "dwSourceSystemCode:UKDW_CLARIFY_UK")
                .queryParam("rows", "1")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            
            JSONArray jsonResponse = jsonObject.getJSONArray("serviceLookup");
            
            JSONObject serviceLookupObject = jsonResponse.optJSONObject(0);
            String id = serviceLookupObject.optString("id");
            JSONArray relatedServiceInstanceIdLevel4Array = serviceLookupObject.optJSONArray("relatedServiceInstanceIdLevel4");
            // convert to String, "," delimited
            String relatedServiceInstanceIdLevel4Str = null;
            boolean addSeperator = false;
            if(relatedServiceInstanceIdLevel4Array != null)
            {
                for(int index = 0;index < relatedServiceInstanceIdLevel4Array.length(); ++index)
                {
                    if(addSeperator)
                    {
                        relatedServiceInstanceIdLevel4Str += ", ";
                    }
                    relatedServiceInstanceIdLevel4Str += relatedServiceInstanceIdLevel4Array.optString(index);
                }
            }
            
            // update relatedServiceInstanceIdLevel4 field for this record
            String relatedServiceInstanceIdLevel4 = "SLV_TEST_1" + System.currentTimeMillis();
            String updateDoc =
                    "[{\"id\":\"" + id + "\",\"relatedServiceInstanceIdLevel4\":{\"set\":\"" + relatedServiceInstanceIdLevel4 + "\"}}]";
            
            String baseUrl = PropertyManager.instance().getProperty(PropertyManager.SLV_SOLR_URL_STR);
            
            String url = baseUrl.replace("select", "update/json?commitWithin=5000");
            
            Client client = Client.create();
            client.addFilter(
                new HTTPBasicAuthFilter(
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_USERNAME_STR),
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_PASSWORD_STR)));
            WebResource webResource2 = client.resource(url);
            
            ClientResponse responsePost = 
                    webResource2.accept(MediaType.APPLICATION_JSON_TYPE)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .post(ClientResponse.class, updateDoc);
            
            Assert.assertNotNull(responsePost);
            Assert.assertEquals(Status.OK.getStatusCode(), responsePost.getStatus());
            
            // sleep for 7 seconds, then get the document
            Thread.sleep(7000L);
            
            // verify that relatedServiceInstanceIdLevel4 is set and is returned as an array
            WebResource webResource3 = resource();
            ClientResponse response3 = 
                    webResource3.path(getServletPath())
                    .queryParam("q", "id:\"" + id + "\"")
                    .queryParam("rows", "1")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response3);
            Assert.assertEquals(Status.OK.getStatusCode(), response3.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response3.getType());
            
            JSONObject jsonObject2 = new JSONObject(response3.getEntity(String.class));

            JSONArray jsonResponse2 = jsonObject2.getJSONArray("serviceLookup");
            
            JSONObject relatedServiceInstanceIdLevel4Object2 = jsonResponse2.optJSONObject(0);
            Assert.assertNotNull("Not null relatedServiceInstanceIdLevel4 element", relatedServiceInstanceIdLevel4Object2);
            JSONArray relatedServiceInstanceIdLevel42 = relatedServiceInstanceIdLevel4Object2.getJSONArray("relatedServiceInstanceIdLevel4");
            Assert.assertNotNull("relatedServiceInstanceIdLevel4 is a not null JSONArray", relatedServiceInstanceIdLevel42);
            Assert.assertTrue("relatedServiceInstanceIdLevel4 retrived", relatedServiceInstanceIdLevel4.equals(relatedServiceInstanceIdLevel42.get(0)));
            
            // reset the relatedServiceInstanceIdLevel4
            String updateDoc2 = "[{\"id\":\"" + id + "\",\"relatedServiceInstanceIdLevel4\":{\"set\":" + (relatedServiceInstanceIdLevel4Str != null ? "\"" + relatedServiceInstanceIdLevel4Str + "\"" : null) + "}}]";
            
            ClientResponse responsePost4 = 
                    webResource2.accept(MediaType.APPLICATION_JSON_TYPE)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .post(ClientResponse.class, updateDoc2);
            
            Assert.assertNotNull(responsePost4);
            Assert.assertEquals(Status.OK.getStatusCode(), responsePost4.getStatus());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_relatedServiceInstanceIdLevel5Json()
    {
        // 1. Get a service lookup record
        // 2. Update relatedServiceInstanceIdLevel5 attribute
        // 3. Retrieve the updated serviceLocation record and verify relatedServiceInstanceIdLevel5 is returned as an Array.
        
        // This test is executed only against DEV environment, when executing it against External setup, we do not run this test
        Assume.assumeFalse(getTestContainerFactory().getClass().getName().endsWith("ExternalTestContainerFactory"));

        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath())
                .queryParam("q", "dwSourceSystemCode:UKDW_CLARIFY_UK")
                .queryParam("rows", "1")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
        try
        {
            JSONObject jsonObject = new JSONObject(response.getEntity(String.class));
            
            JSONArray jsonResponse = jsonObject.getJSONArray("serviceLookup");
            
            JSONObject serviceLookupObject = jsonResponse.optJSONObject(0);
            String id = serviceLookupObject.optString("id");
            JSONArray relatedServiceInstanceIdLevel5Array = serviceLookupObject.optJSONArray("relatedServiceInstanceIdLevel5");
            // convert to String, "," delimited
            String relatedServiceInstanceIdLevel5Str = null;
            boolean addSeperator = false;
            if(relatedServiceInstanceIdLevel5Array != null)
            {
                for(int index = 0;index < relatedServiceInstanceIdLevel5Array.length(); ++index)
                {
                    if(addSeperator)
                    {
                        relatedServiceInstanceIdLevel5Str += ", ";
                    }
                    relatedServiceInstanceIdLevel5Str += relatedServiceInstanceIdLevel5Array.optString(index);
                }
            }
            
            // update relatedServiceInstanceIdLevel5 field for this record
            String relatedServiceInstanceIdLevel5 = "SLV_TEST_1" + System.currentTimeMillis();
            String updateDoc =
                    "[{\"id\":\"" + id + "\",\"relatedServiceInstanceIdLevel5\":{\"set\":\"" + relatedServiceInstanceIdLevel5 + "\"}}]";
            
            String baseUrl = PropertyManager.instance().getProperty(PropertyManager.SLV_SOLR_URL_STR);
            
            String url = baseUrl.replace("select", "update/json?commitWithin=5000");
            
            Client client = Client.create();
            client.addFilter(
                new HTTPBasicAuthFilter(
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_USERNAME_STR),
                   PropertyManager.instance().getProperty(PropertyManager.SOLR_CLOUD_PASSWORD_STR)));
            WebResource webResource2 = client.resource(url);
            
            ClientResponse responsePost = 
                    webResource2.accept(MediaType.APPLICATION_JSON_TYPE)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .post(ClientResponse.class, updateDoc);
            
            Assert.assertNotNull(responsePost);
            Assert.assertEquals(Status.OK.getStatusCode(), responsePost.getStatus());
            
            // sleep for 7 seconds, then get the document
            Thread.sleep(7000L);
            
            // verify that relatedServiceInstanceIdLevel5 is set and is returned as an array
            WebResource webResource3 = resource();
            ClientResponse response3 = 
                    webResource3.path(getServletPath())
                    .queryParam("q", "id:\"" + id + "\"")
                    .queryParam("rows", "1")
                    .accept(MediaType.APPLICATION_JSON)
                    .get(ClientResponse.class);

            Assert.assertNotNull(response3);
            Assert.assertEquals(Status.OK.getStatusCode(), response3.getStatus());
            Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response3.getType());
            
            JSONObject jsonObject2 = new JSONObject(response3.getEntity(String.class));

            JSONArray jsonResponse2 = jsonObject2.getJSONArray("serviceLookup");
            
            JSONObject relatedServiceInstanceIdLevel5Object2 = jsonResponse2.optJSONObject(0);
            Assert.assertNotNull("Not null relatedServiceInstanceIdLevel5 element", relatedServiceInstanceIdLevel5Object2);
            JSONArray relatedServiceInstanceIdLevel52 = relatedServiceInstanceIdLevel5Object2.getJSONArray("relatedServiceInstanceIdLevel5");
            Assert.assertNotNull("relatedServiceInstanceIdLevel5 is a not null JSONArray", relatedServiceInstanceIdLevel52);
            Assert.assertTrue("relatedServiceInstanceIdLevel5 retrived", relatedServiceInstanceIdLevel5.equals(relatedServiceInstanceIdLevel52.get(0)));
            
            // reset the relatedServiceInstanceIdLevel5
            String updateDoc2 = "[{\"id\":\"" + id + "\",\"relatedServiceInstanceIdLevel5\":{\"set\":" + (relatedServiceInstanceIdLevel5Str != null ? "\"" + relatedServiceInstanceIdLevel5Str + "\"" : null) + "}}]";
            
            ClientResponse responsePost4 = 
                    webResource2.accept(MediaType.APPLICATION_JSON_TYPE)
                    .type(MediaType.APPLICATION_JSON_TYPE)
                    .post(ClientResponse.class, updateDoc2);
            
            Assert.assertNotNull(responsePost4);
            Assert.assertEquals(Status.OK.getStatusCode(), responsePost4.getStatus());
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            Assert.fail("failed to verify response JSON structure" + ex.getClass());
        }
    }

    @Test
    public void testServiceLookup_XML_Post()
    {
        WebResource webResource = resource();
        
        Form form = new Form();
        form.add("q", "customerNumber:*");

        ClientResponse response = 
                webResource.path(getServletPath())
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_XML)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
    }

    @Test
    public void testServiceLookup_JSON_Post()
    {
        WebResource webResource = resource();

        Form form = new Form();
        form.add("q", "customerNumber:*");

        ClientResponse response = 
                webResource.path(getServletPath())
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    @Test
    public void testServiceLookup_NullQueryParam_Post()
    {
        WebResource webResource = resource();
        Form form = new Form();
        ClientResponse response = 
                webResource.path(getServletPath())
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(400, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(400002, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Invalid Query String", details.getExceptionDetails().getMessage());
    }

    @Test
    public void testServiceLookupRaw_XML_Post()
    {
        WebResource webResource = resource();
        
        Form form = new Form();
        form.add("q", "customerNumber:*");

        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_XML)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_XML_TYPE, response.getType());
    }

    @Test
    public void testServiceLookupRaw_JSON_Post()
    {
        WebResource webResource = resource();

        Form form = new Form();
        form.add("q", "customerNumber:*");

        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    @Test
    public void testServiceLookupRaw_NullQueryParam_Post()
    {
        WebResource webResource = resource();
        Form form = new Form();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .type(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class, form);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.BAD_REQUEST.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(400, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(400002, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Invalid Query String", details.getExceptionDetails().getMessage());
    }

    @Test
    public void testServiceLookup_LimitDeepPaging()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .queryParam("start", "500000")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.INTERNAL_SERVER_ERROR.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(500, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(500004, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Too many results requested, please filter the query", details.getExceptionDetails().getMessage());
    }

    @Test
    public void testServiceLookup_LimitDeepPagingFirstStartParamEval()
    {
        WebResource webResource = resource();
        ClientResponse response = 
                webResource.path(getServletPath()).path("raw")
                .queryParam("q", "customerNumber:*")
                .queryParam("start", "500000")
                .queryParam("start", "10")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        
        Assert.assertNotNull(response);
        Assert.assertEquals(Status.INTERNAL_SERVER_ERROR.getStatusCode(), response.getStatus());
        
        DataServiceError details = response.getEntity(DataServiceError.class);
        Assert.assertNotNull(details);
        Assert.assertEquals(500, details.getExceptionDetails().getHttpStatusCode());
        Assert.assertEquals(500004, details.getExceptionDetails().getErrorCode());
        Assert.assertEquals("Too many results requested, please filter the query", details.getExceptionDetails().getMessage());
    }

}
