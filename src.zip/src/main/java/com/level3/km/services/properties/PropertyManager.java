package com.level3.km.services.properties;

import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyManager
{
    private static Logger log = LoggerFactory.getLogger(PropertyManager.class);
    private static PropertyManager instance = null;
    private static Object mutex = new int[ 1 ];
    
    private Properties properties = null;
    
    public static final String BANCUST_SOLR_URL_STR = "BANCUST_SOLR_URL";
    public static final String CCPUTIL_SOLR_URL_STR = "CCPUTIL_SOLR_URL";
    public static final String CONTACT_SOLR_URL_STR = "CONTACT_SOLR_URL";
    public static final String CUSTOMERCONTRACTTERM_URL_STR = "CUSTOMERCONTRACTTERM_SOLR_URL";
    public static final String COUNTRY_SOLR_URL_STR = "COUNTRY_SOLR_URL";
    public static final String EXCHANGERATE_SOLR_URL_STR = "EXCHANGERATE_SOLR_URL";
    public static final String LOCATION_SOLR_URL_STR = "LOCATION_SOLR_URL";
    public static final String LOOPQUALIFICATION_SOLR_URL_STR = "LOOPQUALIFICATION_SOLR_URL";
    public static final String ORDER_SOLR_URL_STR = "ORDER_SOLR_URL";
    public static final String SLV_SOLR_URL_STR = "SLV_SOLR_URL";
    public static final String TASKORDER_SOLR_URL_STR = "TASKORDER_SOLR_URL";
    public static final String TASK_SOLR_URL_STR = "TASK_SOLR_URL";
    public static final String TGUTIL_SOLR_URL_STR = "TGUTIL_SOLR_URL";
    public static final String TGCALLVOLUME_SOLR_URL_STR = "TGCALLVOLUME_SOLR_URL";
    public static final String TNLOOKUP_SOLR_URL_STR = "TNLOOKUP_SOLR_URL";
    public static final String BILL_SOLR_URL_STR = "BILL_SOLR_URL";
    public static final String BILLREVENUEMETRICS_SOLR_URL_STR = "BILLREVENUEMETRICS_SOLR_URL";

    public static final String ENVIRONMENT_STR = "ENVIRONMENT";
    public static final String SOLR_CLOUD_USERNAME_STR = "SOLR_CLOUD_USERNAME";
    public static final String SOLR_CLOUD_PASSWORD_STR = "SOLR_CLOUD_PASSWD";
    public static final String CERT_STORE_PASSWORD_STR = "SOLR_CLOUD_CERT_STORE_PASSWD";
    public static final String SOLR_CLOUD_PREFIX = "SOLR_CLOUD";
    
    private PropertyManager()
    {
        try
        {
            URL url = this.getClass().getResource("/ResourceLocator.properties");

            properties = new Properties();
            properties.load(url.openStream());

            URL url2 = this.getClass().getResource("/EnvironmentSelector.properties");

            properties.load(url2.openStream());
        }
        catch(IOException ioe)
        {
            log.error("caught exception while trying to read properties file.", ioe);
        }
    }
    
    public static PropertyManager instance()
    {
        PropertyManager tempInstance = null;
        
        if(instance == null)
        {
            synchronized (mutex)
            {
                if(instance == null)
                {
                    tempInstance = new PropertyManager();
                    instance = tempInstance;
                }
            }
        }
        
        return instance;
    }
    
    private String getTestEnvironment()
    {
        return properties.getProperty(ENVIRONMENT_STR);
    }
    
    public String getProperty(String attribute)
    {
        if(attribute.startsWith(SOLR_CLOUD_PREFIX))
        {
            return properties.getProperty(attribute);
        }
        else
        {
            return properties.getProperty(getTestEnvironment() + "." + attribute);
        }
    }
    
    public static void main(String[] args)
    {
        try
        {
            log.info(PropertyManager.instance().getProperty(TNLOOKUP_SOLR_URL_STR));
            log.info(PropertyManager.instance().getProperty(SLV_SOLR_URL_STR));
            log.info(PropertyManager.instance().getProperty(TASKORDER_SOLR_URL_STR));
        }
        catch(Exception ex)
        {
            log.error("caught exception", ex);
        }
    }
}
