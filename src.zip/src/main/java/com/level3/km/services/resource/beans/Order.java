package com.level3.km.services.resource.beans;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.solr.client.solrj.beans.Field;

@XmlRootElement(name="order")
@XmlAccessorType(XmlAccessType.FIELD)
public class Order
{
    @Field("id")
    private String id;

    @Field("aCityName")
    private String aCityName;

    @Field("aEndClliCode")
    private String aEndClliCode;

    @Field("aLine1Address")
    private String aLine1Address;

    @Field("aLocationName")
    private String aLocationName;

    @Field("aPostalCode")
    private String aPostalCode;

    @Field("aStateCode")
    private String aStateCode;

    @Field("aCountryName")
    private String aCountryName;

    @Field("revenueRegionCode")
    private String revenueRegionCode;

    @Field("bandwidthCode")
    private String bandwidthCode;

    @Field("bandwidthGroup")
    private String bandwidthGroup;

    @Field("billAccountName")
    private String billAccountName;

    @Field("billAccountNumber")
    private String billAccountNumber;

    @Field("billStartDate")
    private Date billStartDate;

    @Field("billStopDate")
    private Date billStopDate;

    @Field("completionDate")
    private Date completionDate;

    @Field("contractTerm")
    private String contractTerm;

    @Field("customBandwidthIndicator")
    private Boolean customBandwidthIndicator;

    @Field("customerAcceptDate")
    private Date customerAcceptDate;

    @Field("customerCommitDate")
    private Date customerCommitDate;

    @Field("customerDisconnectReceivedDate")
    private Date customerDisconnectReceivedDate;

    @Field("customerExpediteIndicator")
    private Boolean customerExpediteIndicator;

    @Field("customerName")
    private String customerName;

    @Field("customerNumber")
    private String customerNumber;

    @Field("customerOrderNumber")
    private String customerOrderNumber;

    @Field("customerOrderStatus")
    private String customerOrderStatus;

    @Field("customerPurchaseOrderNumber")
    private String customerPurchaseOrderNumber;

    @Field("customerRequestDate")
    private Date customerRequestDate;

    @Field("customerRevisedCommitDate")
    private Date customerRevisedCommitDate;

    @Field("customerSignDate")
    private Date customerSignDate;

    @Field("darkFiberIndicator")
    private Boolean darkFiberIndicator;

    @Field("dwSourceSystemCode")
    private String dwSourceSystemCode;

    @Field("firstCpmAcceptDate")
    private Date firstCpmAcceptDate;

    @Field("firstCustomerCommitDate")
    private Date firstCustomerCommitDate;

    @Field("firstCustomerRequestDate")
    private Date firstCustomerRequestDate;

    @Field("focDate")
    private Date focDate;

    @Deprecated
    @Field("glProductName")
    private String glProductName;

    @Deprecated
    @Field("glSegmentProductCode")
    private String glSegmentProductCode;

    @Field("hotCutIndicator")
    private Boolean hotCutIndicator;

    @Field("hybridOrderIndicator")
    private Boolean hybridOrderIndicator;

    @Field("installDate")
    private Date installDate;

    @Field("internalOrderIndicator")
    private Boolean internalOrderIndicator;

    @Field("ipVersionCode")
    private String ipVersionCode;

    @Field("isCapacityJeopIndicator")
    private Boolean isCapacityJeopIndicator;

    @Field("multiVendorIndicator")
    private Boolean multiVendorIndicator;

    @Field("opportunityCreateDate")
    private Date opportunityCreateDate;

    @Field("opportunityNumber")
    private String opportunityNumber;

    @Field("orderCreateDate")
    private Date orderCreateDate;

    @Field("ospBuildIndicator")
    private Boolean ospBuildIndicator;

    @Field("portalOrderCreateDate")
    private Date portalOrderCreateDate;

    @Field("portalOrderStatus")
    private String portalOrderStatus;

    @Field("privateLineHubIndicator")
    private Boolean privateLineHubIndicator;

    @Field("productInstanceId")
    private String productInstanceId;

    @Field("productType")
    private String productType;

    @Field("provisionAcceptDate")
    private Date provisionAcceptDate;

    @Field("provisionerName")
    private String provisionerName;

    @Field("quoteNumber")
    private String quoteNumber;

    @Field("regionCode")
    private String regionCode;

    @Deprecated
    @Field("saReceivedDate")
    private Date saReceivedDate;

    @Field("serviceOrderActionType")
    private String serviceOrderActionType;

    @Field("serviceOrderNumber")
    private String serviceOrderNumber;

    @Field("serviceOrderStatus")
    private String serviceOrderStatus;

    @Field("serviceOrderSuppSequenceNumber")
    private String serviceOrderSuppSequenceNumber;

    @Field("serviceOrderType")
    private String serviceOrderType;

    @Field("serviceOrderTypeReasonCode")
    private String serviceOrderTypeReasonCode;

    @Field("tspCode")
    private String tspCode;

    @Field("usdMrcAmount")
    private Double usdMrcAmount;

    @Field("usdNrcAmount")
    private Double usdNrcAmount;

    @Field("vendorQuantity")
    private String vendorQuantity;

    @Field("welcomeLetterSentDate")
    private Date welcomeLetterSentDate;

    @Field("zCityName")
    private String zCityName;

    @Field("zEndClliCode")
    private String zEndClliCode;

    @Field("zLine1Address")
    private String zLine1Address;

    @Field("zPostalCode")
    private String zPostalCode;

    @Field("zStateCode")
    private String zStateCode;

    @Field("zCountryName")
    private String zCountryName;

    @Field("aEndGlProfitCenterCode")
    private String aEndGlProfitCenterCode;

    @Field("aEndGlProfitCenterMarketCode")
    private String aEndGlProfitCenterMarketCode;

    @Field("aEndGlProfitCenterGmCode")
    private String aEndGlProfitCenterGmCode;

    @Field("aEndGlRegionCode")
    private String aEndGlRegionCode;

    @Field("aEndGlProfitCenterSubRegionCode")
    private String aEndGlProfitCenterSubRegionCode;

    @Field("aEndGlProfitCenterTerritoryCode")
    private String aEndGlProfitCenterTerritoryCode;

    @Field("zEndGlProfitCenterCode")
    private String zEndGlProfitCenterCode;

    @Field("zEndGlProfitCenterMarketCode")
    private String zEndGlProfitCenterMarketCode;

    @Field("zEndGlProfitCenterGmCode")
    private String zEndGlProfitCenterGmCode;

    @Field("zEndGlRegionCode")
    private String zEndGlRegionCode;

    @Field("zEndGlProfitCenterSubRegionCode")
    private String zEndGlProfitCenterSubRegionCode;

    @Field("zEndGlProfitCenterTerritoryCode")
    private String zEndGlProfitCenterTerritoryCode;

    @Field("employeeProfitCenterCode")
    private String employeeProfitCenterCode;

    @Field("employeeGlMarketCode")
    private String employeeGlMarketCode;

    @Field("employeeGlGmCode")
    private String employeeGlGmCode;

    @Field("employeeGlRegionCode")
    private String employeeGlRegionCode;

    @Field("employeeGlProfitCenterSubRegionCode")
    private String employeeGlProfitCenterSubRegionCode;

    @Field("employeeGlProfitCenterTerritoryCode")
    private String employeeGlProfitCenterTerritoryCode;

    @Field("customerProfitCenterCode")
    private String customerProfitCenterCode;

    @Field("customerGlMarketCode")
    private String customerGlMarketCode;

    @Field("customerGlGmCode")
    private String customerGlGmCode;

    @Field("customerGlRegionCode")
    private String customerGlRegionCode;

    @Field("customerGlProfitCenterSubRegionCode")
    private String customerGlProfitCenterSubRegionCode;

    @Field("customerGlProfitCenterTerritoryCode")
    private String customerGlProfitCenterTerritoryCode;

    @Field("associatedOrderNumber")
    private String associatedOrderNumber;

    @Field("privateLineHubType")
    private String privateLineHubType;

    @Field("customerServiceId")
    private String customerServiceId;

    @Field("onnetIndicator")
    private Boolean onnetIndicator;

    @Field("submittedByUser")
    private String submittedByUser;

    @Field("cpmAcceptDate")
    private Date cpmAcceptDate;

    @Field("deploymentCommitDate")
    private Date deploymentCommitDate;

    @Field("usdYrcAmount")
    private Double usdYrcAmount;

    @Field("managementProductHierarchyTier1Description")
    private String managementProductHierarchyTier1Description;

    @Field("managementProductHierarchyTier0Description")
    private String managementProductHierarchyTier0Description;

    @Field("managementProductHierarchyTier3Description")
    private String managementProductHierarchyTier3Description;

    @Field("managementProductHierarchyTier4Description")
    private String managementProductHierarchyTier4Description;

    @Field("glManagementProductCode")
    private String glManagementProductCode;

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getACityName()
    {
        return aCityName;
    }

    public void setACityName(String aCityName)
    {
        this.aCityName = aCityName;
    }

    public String getAEndClliCode()
    {
        return aEndClliCode;
    }

    public void setAEndClliCode(String aEndClliCode)
    {
        this.aEndClliCode = aEndClliCode;
    }

    public String getALine1Address()
    {
        return aLine1Address;
    }

    public void setALine1Address(String aLine1Address)
    {
        this.aLine1Address = aLine1Address;
    }

    public String getALocationName()
    {
        return aLocationName;
    }

    public void setALocationName(String aLocationName)
    {
        this.aLocationName = aLocationName;
    }

    public String getAPostalCode()
    {
        return aPostalCode;
    }

    public void setAPostalCode(String aPostalCode)
    {
        this.aPostalCode = aPostalCode;
    }

    public String getAStateCode()
    {
        return aStateCode;
    }

    public void setAStateCode(String aStateCode)
    {
        this.aStateCode = aStateCode;
    }

    public String getaCountryName()
    {
        return aCountryName;
    }

    public void setaCountryName(String aCountryName)
    {
        this.aCountryName = aCountryName;
    }

    public String getRevenueRegionCode()
    {
        return revenueRegionCode;
    }

    public void setRevenueRegionCode(String revRegion)
    {
        this.revenueRegionCode = revRegion;
    }

    public String getBandwidthCode()
    {
        return bandwidthCode;
    }

    public void setBandwidthCode(String bandwidthCode)
    {
        this.bandwidthCode = bandwidthCode;
    }

    public String getBandwidthGroup()
    {
        return bandwidthGroup;
    }

    public void setBandwidthGroup(String bandwidthGroup)
    {
        this.bandwidthGroup = bandwidthGroup;
    }

    public String getBillAccountName()
    {
        return billAccountName;
    }

    public void setBillAccountName(String billAccountName)
    {
        this.billAccountName = billAccountName;
    }

    public String getBillAccountNumber()
    {
        return billAccountNumber;
    }

    public void setBillAccountNumber(String billAccountNumber)
    {
        this.billAccountNumber = billAccountNumber;
    }

    public Date getBillStartDate()
    {
        return billStartDate;
    }

    public void setBillStartDate(Date billStartDate)
    {
        this.billStartDate = billStartDate;
    }

    public Date getBillStopDate()
    {
        return billStopDate;
    }

    public void setBillStopDate(Date billStopDate)
    {
        this.billStopDate = billStopDate;
    }

    public Date getCompletionDate()
    {
        return completionDate;
    }

    public void setCompletionDate(Date completionDate)
    {
        this.completionDate = completionDate;
    }

    public String getContractTerm()
    {
        return contractTerm;
    }

    public void setContractTerm(String contractTerm)
    {
        this.contractTerm = contractTerm;
    }

    public Boolean getCustomBandwidthIndicator()
    {
        return customBandwidthIndicator;
    }

    public void setCustomBandwidthIndicator(Boolean customBandwidthIndicator)
    {
        this.customBandwidthIndicator = customBandwidthIndicator;
    }

    public Date getCustomerAcceptDate()
    {
        return customerAcceptDate;
    }

    public void setCustomerAcceptDate(Date customerAcceptDate)
    {
        this.customerAcceptDate = customerAcceptDate;
    }

    public Date getCustomerCommitDate()
    {
        return customerCommitDate;
    }

    public void setCustomerCommitDate(Date customerCommitDate)
    {
        this.customerCommitDate = customerCommitDate;
    }

    public Date getCustomerDisconnectReceivedDate()
    {
        return customerDisconnectReceivedDate;
    }

    public void setCustomerDisconnectReceivedDate(
            Date customerDisconnectReceivedDate)
    {
        this.customerDisconnectReceivedDate = customerDisconnectReceivedDate;
    }

    public Boolean getCustomerExpediteIndicator()
    {
        return customerExpediteIndicator;
    }

    public void setCustomerExpediteIndicator(Boolean customerExpediteIndicator)
    {
        this.customerExpediteIndicator = customerExpediteIndicator;
    }

    public String getCustomerName()
    {
        return customerName;
    }

    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }

    public String getCustomerNumber()
    {
        return customerNumber;
    }

    public void setCustomerNumber(String customerNumber)
    {
        this.customerNumber = customerNumber;
    }

    public String getCustomerOrderNumber()
    {
        return customerOrderNumber;
    }

    public void setCustomerOrderNumber(String customerOrderNumber)
    {
        this.customerOrderNumber = customerOrderNumber;
    }

    public String getCustomerOrderStatus()
    {
        return customerOrderStatus;
    }

    public void setCustomerOrderStatus(String customerOrderStatus)
    {
        this.customerOrderStatus = customerOrderStatus;
    }

    public String getCustomerPurchaseOrderNumber()
    {
        return customerPurchaseOrderNumber;
    }

    public void setCustomerPurchaseOrderNumber(String customerPurchaseOrderNumber)
    {
        this.customerPurchaseOrderNumber = customerPurchaseOrderNumber;
    }

    public Date getCustomerRequestDate()
    {
        return customerRequestDate;
    }

    public void setCustomerRequestDate(Date customerRequestDate)
    {
        this.customerRequestDate = customerRequestDate;
    }

    public Date getCustomerRevisedCommitDate()
    {
        return customerRevisedCommitDate;
    }

    public void setCustomerRevisedCommitDate(Date customerRevisedCommitDate)
    {
        this.customerRevisedCommitDate = customerRevisedCommitDate;
    }

    public Date getCustomerSignDate()
    {
        return customerSignDate;
    }

    public void setCustomerSignDate(Date customerSignDate)
    {
        this.customerSignDate = customerSignDate;
    }

    public Boolean getDarkFiberIndicator()
    {
        return darkFiberIndicator;
    }

    public void setDarkFiberIndicator(Boolean darkFiberIndicator)
    {
        this.darkFiberIndicator = darkFiberIndicator;
    }

    public String getDwSourceSystemCode()
    {
        return dwSourceSystemCode;
    }

    public void setDwSourceSystemCode(String dwSourceSystemCode)
    {
        this.dwSourceSystemCode = dwSourceSystemCode;
    }

    public Date getFirstCpmAcceptDate()
    {
        return firstCpmAcceptDate;
    }

    public void setFirstCpmAcceptDate(Date firstCpmAcceptDate)
    {
        this.firstCpmAcceptDate = firstCpmAcceptDate;
    }

    public Date getFirstCustomerCommitDate()
    {
        return firstCustomerCommitDate;
    }

    public void setFirstCustomerCommitDate(Date firstCustomerCommitDate)
    {
        this.firstCustomerCommitDate = firstCustomerCommitDate;
    }

    public Date getFirstCustomerRequestDate()
    {
        return firstCustomerRequestDate;
    }

    public void setFirstCustomerRequestDate(Date firstCustomerRequestDate)
    {
        this.firstCustomerRequestDate = firstCustomerRequestDate;
    }

    public Date getFocDate()
    {
        return focDate;
    }

    public void setFocDate(Date focDate)
    {
        this.focDate = focDate;
    }

    public String getGlProductName()
    {
        return glProductName;
    }

    public void setGlProductName(String glProductName)
    {
        this.glProductName = glProductName;
    }

    public String getGlSegmentProductCode()
    {
        return glSegmentProductCode;
    }

    public void setGlSegmentProductCode(String glSegmentProductCode)
    {
        this.glSegmentProductCode = glSegmentProductCode;
    }

    public Boolean getHotCutIndicator()
    {
        return hotCutIndicator;
    }

    public void setHotCutIndicator(Boolean hotCutIndicator)
    {
        this.hotCutIndicator = hotCutIndicator;
    }

    public Boolean getHybridOrderIndicator()
    {
        return hybridOrderIndicator;
    }

    public void setHybridOrderIndicator(Boolean hybridOrderIndicator)
    {
        this.hybridOrderIndicator = hybridOrderIndicator;
    }

    public Date getInstallDate()
    {
        return installDate;
    }

    public void setInstallDate(Date installDate)
    {
        this.installDate = installDate;
    }

    public Boolean getInternalOrderIndicator()
    {
        return internalOrderIndicator;
    }

    public void setInternalOrderIndicator(Boolean internalOrderIndicator)
    {
        this.internalOrderIndicator = internalOrderIndicator;
    }

    public String getIpVersionCode()
    {
        return ipVersionCode;
    }

    public void setIpVersionCode(String ipVersionCode)
    {
        this.ipVersionCode = ipVersionCode;
    }

    public Boolean getIsCapacityJeopIndicator()
    {
        return isCapacityJeopIndicator;
    }

    public void setIsCapacityJeopIndicator(Boolean isCapacityJeopIndicator)
    {
        this.isCapacityJeopIndicator = isCapacityJeopIndicator;
    }

    public Boolean getMultiVendorIndicator()
    {
        return multiVendorIndicator;
    }

    public void setMultiVendorIndicator(Boolean multiVendorIndicator)
    {
        this.multiVendorIndicator = multiVendorIndicator;
    }

    public Date getOpportunityCreateDate()
    {
        return opportunityCreateDate;
    }

    public void setOpportunityCreateDate(Date opportunityCreateDate)
    {
        this.opportunityCreateDate = opportunityCreateDate;
    }

    public String getOpportunityNumber()
    {
        return opportunityNumber;
    }

    public void setOpportunityNumber(String opportunityNumber)
    {
        this.opportunityNumber = opportunityNumber;
    }

    public Date getOrderCreateDate()
    {
        return orderCreateDate;
    }

    public void setOrderCreateDate(Date orderCreateDate)
    {
        this.orderCreateDate = orderCreateDate;
    }

    public Boolean getOspBuildIndicator()
    {
        return ospBuildIndicator;
    }

    public void setOspBuildIndicator(Boolean ospBuildIndicator)
    {
        this.ospBuildIndicator = ospBuildIndicator;
    }

    public Date getPortalOrderCreateDate()
    {
        return portalOrderCreateDate;
    }

    public void setPortalOrderCreateDate(Date portalOrderCreateDate)
    {
        this.portalOrderCreateDate = portalOrderCreateDate;
    }

    public String getPortalOrderStatus()
    {
        return portalOrderStatus;
    }

    public void setPortalOrderStatus(String portalOrderStatus)
    {
        this.portalOrderStatus = portalOrderStatus;
    }

    public Boolean getPrivateLineHubIndicator()
    {
        return privateLineHubIndicator;
    }

    public void setPrivateLineHubIndicator(Boolean privateLineHubIndicator)
    {
        this.privateLineHubIndicator = privateLineHubIndicator;
    }

    public String getProductInstanceId()
    {
        return productInstanceId;
    }

    public void setProductInstanceId(String productInstanceId)
    {
        this.productInstanceId = productInstanceId;
    }

    public String getProductType()
    {
        return productType;
    }

    public void setProductType(String productType)
    {
        this.productType = productType;
    }

    public Date getProvisionAcceptDate()
    {
        return provisionAcceptDate;
    }

    public void setProvisionAcceptDate(Date provisionAcceptDate)
    {
        this.provisionAcceptDate = provisionAcceptDate;
    }

    public String getProvisionerName()
    {
        return provisionerName;
    }

    public void setProvisionerName(String provisionerName)
    {
        this.provisionerName = provisionerName;
    }

    public String getQuoteNumber()
    {
        return quoteNumber;
    }

    public void setQuoteNumber(String quoteNumber)
    {
        this.quoteNumber = quoteNumber;
    }

    public String getRegionCode()
    {
        return regionCode;
    }

    public void setRegionCode(String regionCode)
    {
        this.regionCode = regionCode;
    }

    @Deprecated
    public Date getSaReceivedDate()
    {
        return saReceivedDate;
    }

    @Deprecated
    public void setSaReceivedDate(Date saReceivedDate)
    {
        this.saReceivedDate = saReceivedDate;
    }

    public String getServiceOrderActionType()
    {
        return serviceOrderActionType;
    }

    public void setServiceOrderActionType(String serviceOrderActionType)
    {
        this.serviceOrderActionType = serviceOrderActionType;
    }

    public String getServiceOrderNumber()
    {
        return serviceOrderNumber;
    }

    public void setServiceOrderNumber(String serviceOrderNumber)
    {
        this.serviceOrderNumber = serviceOrderNumber;
    }

    public String getServiceOrderStatus()
    {
        return serviceOrderStatus;
    }

    public void setServiceOrderStatus(String serviceOrderStatus)
    {
        this.serviceOrderStatus = serviceOrderStatus;
    }

    public String getServiceOrderSuppSequenceNumber()
    {
        return serviceOrderSuppSequenceNumber;
    }

    public void setServiceOrderSuppSequenceNumber(
            String serviceOrderSuppSequenceNumber)
    {
        this.serviceOrderSuppSequenceNumber = serviceOrderSuppSequenceNumber;
    }

    public String getServiceOrderType()
    {
        return serviceOrderType;
    }

    public void setServiceOrderType(String serviceOrderType)
    {
        this.serviceOrderType = serviceOrderType;
    }

    public String getServiceOrderTypeReasonCode()
    {
        return serviceOrderTypeReasonCode;
    }

    public void setServiceOrderTypeReasonCode(String serviceOrderTypeReasonCode)
    {
        this.serviceOrderTypeReasonCode = serviceOrderTypeReasonCode;
    }

    public String getTspCode()
    {
        return tspCode;
    }

    public void setTspCode(String tspCode)
    {
        this.tspCode = tspCode;
    }

    public Double getUsdMrcAmount()
    {
        return usdMrcAmount;
    }

    public void setUsdMrcAmount(Double usdMrcAmount)
    {
        this.usdMrcAmount = usdMrcAmount;
    }

    public Double getUsdNrcAmount()
    {
        return usdNrcAmount;
    }

    public void setUsdNrcAmount(Double usdNrcAmount)
    {
        this.usdNrcAmount = usdNrcAmount;
    }

    public String getVendorQuantity()
    {
        return vendorQuantity;
    }

    public void setVendorQuantity(String vendorQuantity)
    {
        this.vendorQuantity = vendorQuantity;
    }

    public Date getWelcomeLetterSentDate()
    {
        return welcomeLetterSentDate;
    }

    public void setWelcomeLetterSentDate(Date welcomeLetterSentDate)
    {
        this.welcomeLetterSentDate = welcomeLetterSentDate;
    }

    public String getZCityName()
    {
        return zCityName;
    }

    public void setZCityName(String zCityName)
    {
        this.zCityName = zCityName;
    }

    public String getZEndClliCode()
    {
        return zEndClliCode;
    }

    public void setZEndClliCode(String zEndClliCode)
    {
        this.zEndClliCode = zEndClliCode;
    }

    public String getZLine1Address()
    {
        return zLine1Address;
    }

    public void setZLine1Address(String zLine1Address)
    {
        this.zLine1Address = zLine1Address;
    }

    public String getZPostalCode()
    {
        return zPostalCode;
    }

    public void setZPostalCode(String zPostalCode)
    {
        this.zPostalCode = zPostalCode;
    }

    public String getZStateCode()
    {
        return zStateCode;
    }

    public void setZStateCode(String zStateCode)
    {
        this.zStateCode = zStateCode;
    }

    public String getzCountryName()
    {
        return zCountryName;
    }

    public void setzCountryName(String zCountryName)
    {
        this.zCountryName = zCountryName;
    }

    public String getAEndGlProfitCenterCode()
    {
        return aEndGlProfitCenterCode;
    }

    public void setAEndGlProfitCenterCode(String aEndGlProfitCenterCode)
    {
        this.aEndGlProfitCenterCode = aEndGlProfitCenterCode;
    }

    public String getAEndGlProfitCenterMarketCode()
    {
        return aEndGlProfitCenterMarketCode;
    }

    public void setAEndGlProfitCenterMarketCode(String aEndGlProfitCenterMarketCode)
    {
        this.aEndGlProfitCenterMarketCode = aEndGlProfitCenterMarketCode;
    }

    public String getAEndGlProfitCenterGmCode()
    {
        return aEndGlProfitCenterGmCode;
    }

    public void setAEndGlProfitCenterGmCode(String aEndGlProfitCenterGmCode)
    {
        this.aEndGlProfitCenterGmCode = aEndGlProfitCenterGmCode;
    }

    public String getAEndGlRegionCode()
    {
        return aEndGlRegionCode;
    }

    public void setAEndGlRegionCode(String aEndGlRegionCode)
    {
        this.aEndGlRegionCode = aEndGlRegionCode;
    }

    public String getAEndGlProfitCenterSubRegionCode()
    {
        return aEndGlProfitCenterSubRegionCode;
    }

    public void setAEndGlProfitCenterSubRegionCode(
            String aEndGlProfitCenterSubRegionCode)
    {
        this.aEndGlProfitCenterSubRegionCode = aEndGlProfitCenterSubRegionCode;
    }

    public String getAEndGlProfitCenterTerritoryCode()
    {
        return aEndGlProfitCenterTerritoryCode;
    }

    public void setAEndGlProfitCenterTerritoryCode(
            String aEndGlProfitCenterTerritoryCode)
    {
        this.aEndGlProfitCenterTerritoryCode = aEndGlProfitCenterTerritoryCode;
    }

    public String getZEndGlProfitCenterCode()
    {
        return zEndGlProfitCenterCode;
    }

    public void setZEndGlProfitCenterCode(String zEndGlProfitCenterCode)
    {
        this.zEndGlProfitCenterCode = zEndGlProfitCenterCode;
    }

    public String getZEndGlProfitCenterMarketCode()
    {
        return zEndGlProfitCenterMarketCode;
    }

    public void setZEndGlProfitCenterMarketCode(String zEndGlProfitCenterMarketCode)
    {
        this.zEndGlProfitCenterMarketCode = zEndGlProfitCenterMarketCode;
    }

    public String getZEndGlProfitCenterGmCode()
    {
        return zEndGlProfitCenterGmCode;
    }

    public void setZEndGlProfitCenterGmCode(String zEndGlProfitCenterGmCode)
    {
        this.zEndGlProfitCenterGmCode = zEndGlProfitCenterGmCode;
    }

    public String getZEndGlRegionCode()
    {
        return zEndGlRegionCode;
    }

    public void setZEndGlRegionCode(String zEndGlRegionCode)
    {
        this.zEndGlRegionCode = zEndGlRegionCode;
    }

    public String getZEndGlProfitCenterSubRegionCode()
    {
        return zEndGlProfitCenterSubRegionCode;
    }

    public void setZEndGlProfitCenterSubRegionCode(
            String zEndGlProfitCenterSubRegionCode)
    {
        this.zEndGlProfitCenterSubRegionCode = zEndGlProfitCenterSubRegionCode;
    }

    public String getZEndGlProfitCenterTerritoryCode()
    {
        return zEndGlProfitCenterTerritoryCode;
    }

    public void setZEndGlProfitCenterTerritoryCode(
            String zEndGlProfitCenterTerritoryCode)
    {
        this.zEndGlProfitCenterTerritoryCode = zEndGlProfitCenterTerritoryCode;
    }

    public String getEmployeeProfitCenterCode()
    {
        return employeeProfitCenterCode;
    }

    public void setEmployeeProfitCenterCode(String employeeProfitCenterCode)
    {
        this.employeeProfitCenterCode = employeeProfitCenterCode;
    }

    public String getEmployeeGlMarketCode()
    {
        return employeeGlMarketCode;
    }

    public void setEmployeeGlMarketCode(String employeeGlMarketCode)
    {
        this.employeeGlMarketCode = employeeGlMarketCode;
    }

    public String getEmployeeGlGmCode()
    {
        return employeeGlGmCode;
    }

    public void setEmployeeGlGmCode(String employeeGlGmCode)
    {
        this.employeeGlGmCode = employeeGlGmCode;
    }

    public String getEmployeeGlRegionCode()
    {
        return employeeGlRegionCode;
    }

    public void setEmployeeGlRegionCode(String employeeGlRegionCode)
    {
        this.employeeGlRegionCode = employeeGlRegionCode;
    }

    public String getEmployeeGlProfitCenterSubRegionCode()
    {
        return employeeGlProfitCenterSubRegionCode;
    }

    public void setEmployeeGlProfitCenterSubRegionCode(
            String employeeGlProfitCenterSubRegionCode)
    {
        this.employeeGlProfitCenterSubRegionCode = employeeGlProfitCenterSubRegionCode;
    }

    public String getEmployeeGlProfitCenterTerritoryCode()
    {
        return employeeGlProfitCenterTerritoryCode;
    }

    public void setEmployeeGlProfitCenterTerritoryCode(
            String employeeGlProfitCenterTerritoryCode)
    {
        this.employeeGlProfitCenterTerritoryCode = employeeGlProfitCenterTerritoryCode;
    }

    public String getCustomerProfitCenterCode()
    {
        return customerProfitCenterCode;
    }

    public void setCustomerProfitCenterCode(String customerProfitCenterCode)
    {
        this.customerProfitCenterCode = customerProfitCenterCode;
    }

    public String getCustomerGlMarketCode()
    {
        return customerGlMarketCode;
    }

    public void setCustomerGlMarketCode(String customerGlMarketCode)
    {
        this.customerGlMarketCode = customerGlMarketCode;
    }

    public String getCustomerGlGmCode()
    {
        return customerGlGmCode;
    }

    public void setCustomerGlGmCode(String customerGlGmCode)
    {
        this.customerGlGmCode = customerGlGmCode;
    }

    public String getCustomerGlRegionCode()
    {
        return customerGlRegionCode;
    }

    public void setCustomerGlRegionCode(String customerGlRegionCode)
    {
        this.customerGlRegionCode = customerGlRegionCode;
    }

    public String getCustomerGlProfitCenterSubRegionCode()
    {
        return customerGlProfitCenterSubRegionCode;
    }

    public void setCustomerGlProfitCenterSubRegionCode(
            String customerGlProfitCenterSubRegionCode)
    {
        this.customerGlProfitCenterSubRegionCode = customerGlProfitCenterSubRegionCode;
    }

    public String getCustomerGlProfitCenterTerritoryCode()
    {
        return customerGlProfitCenterTerritoryCode;
    }

    public void setCustomerGlProfitCenterTerritoryCode(
            String customerGlProfitCenterTerritoryCode)
    {
        this.customerGlProfitCenterTerritoryCode = customerGlProfitCenterTerritoryCode;
    }

    public String getAssociatedOrderNumber()
    {
        return associatedOrderNumber;
    }

    public void setAssociatedOrderNumber(String associatedOrderNumber)
    {
        this.associatedOrderNumber = associatedOrderNumber;
    }

    public String getPrivateLineHubType()
    {
        return privateLineHubType;
    }

    public void setPrivateLineHubType(String privateLineHubType)
    {
        this.privateLineHubType = privateLineHubType;
    }

    public String getCustomerServiceId()
    {
        return customerServiceId;
    }

    public void setCustomerServiceId(String customerServiceId)
    {
        this.customerServiceId = customerServiceId;
    }

    public Boolean getOnnetIndicator()
    {
        return onnetIndicator;
    }

    public void setOnnetIndicator(Boolean onnetIndicator)
    {
        this.onnetIndicator = onnetIndicator;
    }

    public String getSubmittedByUser()
    {
        return submittedByUser;
    }

    public void setSubmittedByUser(String submittedByUser)
    {
        this.submittedByUser = submittedByUser;
    }

    public Date getCpmAcceptDate()
    {
        return cpmAcceptDate;
    }

    public void setCpmAcceptDate(Date cpmAcceptDate)
    {
        this.cpmAcceptDate = cpmAcceptDate;
    }

    public Date getDeploymentCommitDate()
    {
        return deploymentCommitDate;
    }

    public void setDeploymentCommitDate(Date deploymentCommitDate)
    {
        this.deploymentCommitDate = deploymentCommitDate;
    }

    public Double getUsdYrcAmount()
    {
        return usdYrcAmount;
    }

    public void setUsdYrcAmount(Double usdYrcAmount)
    {
        this.usdYrcAmount = usdYrcAmount;
    }

    public String getManagementProductHierarchyTier1Description() {
		return managementProductHierarchyTier1Description;
	}

	public void setManagementProductHierarchyTier1Description(String managementProductHierarchyTier1Description) {
		this.managementProductHierarchyTier1Description = managementProductHierarchyTier1Description;
	}

	public String getManagementProductHierarchyTier0Description() {
		return managementProductHierarchyTier0Description;
	}

	public void setManagementProductHierarchyTier0Description(String managementProductHierarchyTier0Description) {
		this.managementProductHierarchyTier0Description = managementProductHierarchyTier0Description;
	}

	public String getManagementProductHierarchyTier3Description() {
		return managementProductHierarchyTier3Description;
	}

	public void setManagementProductHierarchyTier3Description(String managementProductHierarchyTier3Description) {
		this.managementProductHierarchyTier3Description = managementProductHierarchyTier3Description;
	}

	public String getManagementProductHierarchyTier4Description() {
		return managementProductHierarchyTier4Description;
	}

	public void setManagementProductHierarchyTier4Description(String managementProductHierarchyTier4Description) {
		this.managementProductHierarchyTier4Description = managementProductHierarchyTier4Description;
	}

	public String getGlManagementProductCode() {
		return glManagementProductCode;
	}

	public void setGlManagementProductCode(String glManagementProductCode) {
		this.glManagementProductCode = glManagementProductCode;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Order [id=");
		builder.append(id);
		builder.append(", aCityName=");
		builder.append(aCityName);
		builder.append(", aEndClliCode=");
		builder.append(aEndClliCode);
		builder.append(", aLine1Address=");
		builder.append(aLine1Address);
		builder.append(", aLocationName=");
		builder.append(aLocationName);
		builder.append(", aPostalCode=");
		builder.append(aPostalCode);
		builder.append(", aStateCode=");
		builder.append(aStateCode);
		builder.append(", aCountryName=");
		builder.append(aCountryName);
		builder.append(", revenueRegionCode=");
		builder.append(revenueRegionCode);
		builder.append(", bandwidthCode=");
		builder.append(bandwidthCode);
		builder.append(", bandwidthGroup=");
		builder.append(bandwidthGroup);
		builder.append(", billAccountName=");
		builder.append(billAccountName);
		builder.append(", billAccountNumber=");
		builder.append(billAccountNumber);
		builder.append(", billStartDate=");
		builder.append(billStartDate);
		builder.append(", billStopDate=");
		builder.append(billStopDate);
		builder.append(", completionDate=");
		builder.append(completionDate);
		builder.append(", contractTerm=");
		builder.append(contractTerm);
		builder.append(", customBandwidthIndicator=");
		builder.append(customBandwidthIndicator);
		builder.append(", customerAcceptDate=");
		builder.append(customerAcceptDate);
		builder.append(", customerCommitDate=");
		builder.append(customerCommitDate);
		builder.append(", customerDisconnectReceivedDate=");
		builder.append(customerDisconnectReceivedDate);
		builder.append(", customerExpediteIndicator=");
		builder.append(customerExpediteIndicator);
		builder.append(", customerName=");
		builder.append(customerName);
		builder.append(", customerNumber=");
		builder.append(customerNumber);
		builder.append(", customerOrderNumber=");
		builder.append(customerOrderNumber);
		builder.append(", customerOrderStatus=");
		builder.append(customerOrderStatus);
		builder.append(", customerPurchaseOrderNumber=");
		builder.append(customerPurchaseOrderNumber);
		builder.append(", customerRequestDate=");
		builder.append(customerRequestDate);
		builder.append(", customerRevisedCommitDate=");
		builder.append(customerRevisedCommitDate);
		builder.append(", customerSignDate=");
		builder.append(customerSignDate);
		builder.append(", darkFiberIndicator=");
		builder.append(darkFiberIndicator);
		builder.append(", dwSourceSystemCode=");
		builder.append(dwSourceSystemCode);
		builder.append(", firstCpmAcceptDate=");
		builder.append(firstCpmAcceptDate);
		builder.append(", firstCustomerCommitDate=");
		builder.append(firstCustomerCommitDate);
		builder.append(", firstCustomerRequestDate=");
		builder.append(firstCustomerRequestDate);
		builder.append(", focDate=");
		builder.append(focDate);
		builder.append(", hotCutIndicator=");
		builder.append(hotCutIndicator);
		builder.append(", hybridOrderIndicator=");
		builder.append(hybridOrderIndicator);
		builder.append(", installDate=");
		builder.append(installDate);
		builder.append(", internalOrderIndicator=");
		builder.append(internalOrderIndicator);
		builder.append(", ipVersionCode=");
		builder.append(ipVersionCode);
		builder.append(", isCapacityJeopIndicator=");
		builder.append(isCapacityJeopIndicator);
		builder.append(", multiVendorIndicator=");
		builder.append(multiVendorIndicator);
		builder.append(", opportunityCreateDate=");
		builder.append(opportunityCreateDate);
		builder.append(", opportunityNumber=");
		builder.append(opportunityNumber);
		builder.append(", orderCreateDate=");
		builder.append(orderCreateDate);
		builder.append(", ospBuildIndicator=");
		builder.append(ospBuildIndicator);
		builder.append(", portalOrderCreateDate=");
		builder.append(portalOrderCreateDate);
		builder.append(", portalOrderStatus=");
		builder.append(portalOrderStatus);
		builder.append(", privateLineHubIndicator=");
		builder.append(privateLineHubIndicator);
		builder.append(", productInstanceId=");
		builder.append(productInstanceId);
		builder.append(", productType=");
		builder.append(productType);
		builder.append(", provisionAcceptDate=");
		builder.append(provisionAcceptDate);
		builder.append(", provisionerName=");
		builder.append(provisionerName);
		builder.append(", quoteNumber=");
		builder.append(quoteNumber);
		builder.append(", regionCode=");
		builder.append(regionCode);
		builder.append(", serviceOrderActionType=");
		builder.append(serviceOrderActionType);
		builder.append(", serviceOrderNumber=");
		builder.append(serviceOrderNumber);
		builder.append(", serviceOrderStatus=");
		builder.append(serviceOrderStatus);
		builder.append(", serviceOrderSuppSequenceNumber=");
		builder.append(serviceOrderSuppSequenceNumber);
		builder.append(", serviceOrderType=");
		builder.append(serviceOrderType);
		builder.append(", serviceOrderTypeReasonCode=");
		builder.append(serviceOrderTypeReasonCode);
		builder.append(", tspCode=");
		builder.append(tspCode);
		builder.append(", usdMrcAmount=");
		builder.append(usdMrcAmount);
		builder.append(", usdNrcAmount=");
		builder.append(usdNrcAmount);
		builder.append(", vendorQuantity=");
		builder.append(vendorQuantity);
		builder.append(", welcomeLetterSentDate=");
		builder.append(welcomeLetterSentDate);
		builder.append(", zCityName=");
		builder.append(zCityName);
		builder.append(", zEndClliCode=");
		builder.append(zEndClliCode);
		builder.append(", zLine1Address=");
		builder.append(zLine1Address);
		builder.append(", zPostalCode=");
		builder.append(zPostalCode);
		builder.append(", zStateCode=");
		builder.append(zStateCode);
		builder.append(", zCountryName=");
		builder.append(zCountryName);
		builder.append(", aEndGlProfitCenterCode=");
		builder.append(aEndGlProfitCenterCode);
		builder.append(", aEndGlProfitCenterMarketCode=");
		builder.append(aEndGlProfitCenterMarketCode);
		builder.append(", aEndGlProfitCenterGmCode=");
		builder.append(aEndGlProfitCenterGmCode);
		builder.append(", aEndGlRegionCode=");
		builder.append(aEndGlRegionCode);
		builder.append(", aEndGlProfitCenterSubRegionCode=");
		builder.append(aEndGlProfitCenterSubRegionCode);
		builder.append(", aEndGlProfitCenterTerritoryCode=");
		builder.append(aEndGlProfitCenterTerritoryCode);
		builder.append(", zEndGlProfitCenterCode=");
		builder.append(zEndGlProfitCenterCode);
		builder.append(", zEndGlProfitCenterMarketCode=");
		builder.append(zEndGlProfitCenterMarketCode);
		builder.append(", zEndGlProfitCenterGmCode=");
		builder.append(zEndGlProfitCenterGmCode);
		builder.append(", zEndGlRegionCode=");
		builder.append(zEndGlRegionCode);
		builder.append(", zEndGlProfitCenterSubRegionCode=");
		builder.append(zEndGlProfitCenterSubRegionCode);
		builder.append(", zEndGlProfitCenterTerritoryCode=");
		builder.append(zEndGlProfitCenterTerritoryCode);
		builder.append(", employeeProfitCenterCode=");
		builder.append(employeeProfitCenterCode);
		builder.append(", employeeGlMarketCode=");
		builder.append(employeeGlMarketCode);
		builder.append(", employeeGlGmCode=");
		builder.append(employeeGlGmCode);
		builder.append(", employeeGlRegionCode=");
		builder.append(employeeGlRegionCode);
		builder.append(", employeeGlProfitCenterSubRegionCode=");
		builder.append(employeeGlProfitCenterSubRegionCode);
		builder.append(", employeeGlProfitCenterTerritoryCode=");
		builder.append(employeeGlProfitCenterTerritoryCode);
		builder.append(", customerProfitCenterCode=");
		builder.append(customerProfitCenterCode);
		builder.append(", customerGlMarketCode=");
		builder.append(customerGlMarketCode);
		builder.append(", customerGlGmCode=");
		builder.append(customerGlGmCode);
		builder.append(", customerGlRegionCode=");
		builder.append(customerGlRegionCode);
		builder.append(", customerGlProfitCenterSubRegionCode=");
		builder.append(customerGlProfitCenterSubRegionCode);
		builder.append(", customerGlProfitCenterTerritoryCode=");
		builder.append(customerGlProfitCenterTerritoryCode);
		builder.append(", associatedOrderNumber=");
		builder.append(associatedOrderNumber);
		builder.append(", privateLineHubType=");
		builder.append(privateLineHubType);
		builder.append(", customerServiceId=");
		builder.append(customerServiceId);
		builder.append(", onnetIndicator=");
		builder.append(onnetIndicator);
		builder.append(", submittedByUser=");
		builder.append(submittedByUser);
		builder.append(", cpmAcceptDate=");
		builder.append(cpmAcceptDate);
		builder.append(", deploymentCommitDate=");
		builder.append(deploymentCommitDate);
		builder.append(", usdYrcAmount=");
		builder.append(usdYrcAmount);
		builder.append(", managementProductHierarchyTier1Description=");
		builder.append(managementProductHierarchyTier1Description);
		builder.append(", managementProductHierarchyTier0Description=");
		builder.append(managementProductHierarchyTier0Description);
		builder.append(", managementProductHierarchyTier3Description=");
		builder.append(managementProductHierarchyTier3Description);
		builder.append(", managementProductHierarchyTier4Description=");
		builder.append(managementProductHierarchyTier4Description);
		builder.append(", glManagementProductCode=");
		builder.append(glManagementProductCode);
		builder.append("]");
		return builder.toString();
	}
}
