package com.level3.km.services.resource.beans;

import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.JAXBContext;

import com.sun.jersey.api.json.JSONConfiguration;
import com.sun.jersey.api.json.JSONJAXBContext;

/**
 * New resource should be added to the arrays() below.
 * Any attribute of type List should be added to the arrays() below.
 * If you do not add it, then by default for JSON response Jersey will present for single item in a list
 * as Object, and not as an array.
 * @author agarwal.nitin
 *
 */
@Provider
public class JAXBContextResolver implements ContextResolver<JAXBContext>
{
    private JAXBContext context;

    @SuppressWarnings("rawtypes")
    private Class[] types =
    {
        Level3Response.class
    };

    public JAXBContextResolver() throws Exception
    {
        this.context =
                new JSONJAXBContext(JSONConfiguration.mapped()
                        // resources
                        .arrays("contact")
                        .arrays("concurrentCallPathUtilization")
                        .arrays("country")
                        .arrays("customerBillAccountNumber")
                        .arrays("customerContractTerm")
                        .arrays("exchangeRate")
                        .arrays("location")
                        .arrays("loopQualification")
                        .arrays("bill")
                        .arrays("billrevenuemetrics")
                        .arrays("order")
                        .arrays("serviceLookup")
                        .arrays("task")
                        .arrays("trunkGroupCallVolume")
                        .arrays("trunkGroupUtilization")
                        .arrays("tn")
                        // attributes of type List
                        .arrays("featurePacks")
                        .arrays("routePlans")
                        .arrays("legacySourceSystemCodes")
                        .arrays("locationNumbers")
                        .arrays("relatedServiceInstanceIdLevel1")
                        .arrays("relatedServiceInstanceIdLevel2")
                        .arrays("relatedServiceInstanceIdLevel3")
                        .arrays("relatedServiceInstanceIdLevel4")
                        .arrays("relatedServiceInstanceIdLevel5")
                        .build(), types);
    }

    @SuppressWarnings("rawtypes")
    public JAXBContext getContext(Class objectType)
    {
        for (Class type : types)
        {
            if (type == objectType)
            {
                return context;
            }
        }
        return null;
    }
}