package com.level3.km.services.exception;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Provider
public class CatchAllExceptionMapper implements ExceptionMapper<Throwable>
{
    @Context 
    UriInfo uriInfo;
    
    private static final Logger log = LoggerFactory.getLogger(CatchAllExceptionMapper.class);

    public Response toResponse(Throwable throwable)
    {
        ErrorCodeMapping errorCodeMapping = null;
        String detail = null;

        // order of if stmts is important.
        if (throwable instanceof DataServiceBaseException)
        {
            DataServiceBaseException dse = (DataServiceBaseException) throwable;
            log.warn("DataServiceBaseException in DataService: {} response={} status={}",
                     dse.getErrorCodeMapping().getErrorMessage(),
                     dse.getErrorCodeMapping().getErrorCode(),
                     dse.getErrorCodeMapping().getHttpStatusCode(),
                     throwable);
            errorCodeMapping = dse.getErrorCodeMapping();
            detail = dse.getErrorDetail();
        }
        else if (throwable instanceof WebApplicationException)
        {
            WebApplicationException webApplicationException = (WebApplicationException) throwable;
            Object entity = webApplicationException.getResponse().getEntity();
            int status = webApplicationException.getResponse().getStatus();
            log.warn("WebApplicationException in DataService: {} entity={} response={} status={}",
                     throwable.getMessage(),
                     entity,
                     webApplicationException.getResponse(),
                     webApplicationException.getResponse().getStatus(),
                     throwable);
            errorCodeMapping = DataServiceError.getErrorCodeMapping(status);
            
            // TODO - how do I map this to what the container threw?
            if(errorCodeMapping == null)
            {
                errorCodeMapping = ErrorCodeMapping.InternalServerError;
            }
            
            if(throwable.getMessage() == null)
            {
                detail = errorCodeMapping.getErrorDetail();
            }
            else
            {
                detail = throwable.getMessage() + " " + entity;
            }
        }
        else
        {
            // Unknown exception type. Could be an NPE or anything else.
            log.error("Unhandled exception in DataService: {}", throwable.getMessage(), throwable);
            errorCodeMapping = ErrorCodeMapping.InternalServerError;
            detail = throwable.getMessage();
        }
        
        DataServiceError errorResponse = new DataServiceError(errorCodeMapping);
        errorResponse.getExceptionDetails().setDetail(detail);
        
        log.info("Request received from client: {}####Error response sent to client: {}",
                 uriInfo.getRequestUri().toString(),
                 errorResponse.toString());
        Response result = Response.status(errorCodeMapping.getHttpStatusCode()).entity(errorResponse).build();

        return result;
    }
}
