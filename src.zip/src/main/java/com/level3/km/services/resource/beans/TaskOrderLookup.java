package com.level3.km.services.resource.beans;

import java.util.Date;

import org.apache.solr.client.solrj.beans.Field;

//@XmlRootElement(name="taskOrderLookup")
//@XmlAccessorType(XmlAccessType.FIELD)
@javax.xml.bind.annotation.XmlTransient
public class TaskOrderLookup
{
    @Field("taskId")
    private Integer taskId;
    
    @Field("taskName")
    private String taskName;
    
    @Field("taskStatus")
    private String taskStatus;
    
    @Field("performerName")
    private String performerName;
    
    @Field("taskCreateDate")
    private Date taskCreateDate;
    
    @Field("taskEndDate")
    private Date taskEndDate;
    
    @Field("performerGroupName")
    private String performerGroupName;
    
    @Field("productInstanceId")
    private String productInstanceId;
    
    @Field("serviceOrderNumber")
    private String serviceOrderNumber;
    
    @Field("serviceOrderVersionNumber")
    private Integer serviceOrderVersionNumber;
    
    @Field("serviceOrderActionType")
    private String serviceOrderActionType;
    
    @Field("serviceOrderStatus")
    private String serviceOrderStatus;
    
    @Field("customerFirstCommitDate")
    private Date customerFirstCommitDate;
    
    @Field("customerCommitDate")
    private Date customerCommitDate;
    
    @Field("customerRequestDate")
    private Date customerRequestDate;
    
    @Field("customerExpediteIndicator")
    private Boolean customerExpediteIndicator;
    
    @Field("customerOrderNumber")
    private String customerOrderNumber;
    
    @Field("customerOrderVersionNumber")
    private String customerOrderVersionNumber;
    
    @Field("billAccountNumber")
    private String billAccountNumber;
    
    @Field("billAccountName")
    private String billAccountName;
    
    @Field("usdTotalMrcAmount")
    private Double usdTotalMrcAmount;
    
    @Field("customerRevisedCommitDate")
    private Date customerRevisedCommitDate;
    
    @Field("usdTotalNrcAmount")
    private Double usdTotalNrcAmount;
    
    @Field("dwSourceSystemCode")
    private String dwSourceSystemCode;
    
    @Field("dispatchingGatewayClli")
    private String dispatchingGatewayClli;
    
    @Field("serviceComponentId")
    private String serviceComponentId;

    @Field("processId")
    private String processId;

    public Integer getTaskId()
    {
        return taskId;
    }

    public void setTaskId(Integer taskId)
    {
        this.taskId = taskId;
    }

    public String getTaskName()
    {
        return taskName;
    }

    public void setTaskName(String taskName)
    {
        this.taskName = taskName;
    }

    public String getTaskStatus()
    {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus)
    {
        this.taskStatus = taskStatus;
    }

    public String getPerformerName()
    {
        return performerName;
    }

    public void setPerformerName(String performerName)
    {
        this.performerName = performerName;
    }

    public Date getTaskCreateDate()
    {
        return taskCreateDate;
    }

    public void setTaskCreateDate(Date taskCreateDate)
    {
        this.taskCreateDate = taskCreateDate;
    }

    public Date getTaskEndDate()
    {
        return taskEndDate;
    }

    public void setTaskEndDate(Date taskEndDate)
    {
        this.taskEndDate = taskEndDate;
    }

    public String getPerformerGroupName()
    {
        return performerGroupName;
    }

    public void setPerformerGroupName(String performerGroupName)
    {
        this.performerGroupName = performerGroupName;
    }

    public String getProductInstanceId()
    {
        return productInstanceId;
    }

    public void setProductInstanceId(String productInstanceId)
    {
        this.productInstanceId = productInstanceId;
    }

    public String getServiceOrderNumber()
    {
        return serviceOrderNumber;
    }

    public void setServiceOrderNumber(String serviceOrderNumber)
    {
        this.serviceOrderNumber = serviceOrderNumber;
    }

    public Integer getServiceOrderVersionNumber()
    {
        return serviceOrderVersionNumber;
    }

    public void setServiceOrderVersionNumber(Integer serviceOrderVersionNumber)
    {
        this.serviceOrderVersionNumber = serviceOrderVersionNumber;
    }

    public String getServiceOrderActionType()
    {
        return serviceOrderActionType;
    }

    public void setServiceOrderActionType(String serviceOrderActionType)
    {
        this.serviceOrderActionType = serviceOrderActionType;
    }

    public String getServiceOrderStatus()
    {
        return serviceOrderStatus;
    }

    public void setServiceOrderStatus(String serviceOrderStatus)
    {
        this.serviceOrderStatus = serviceOrderStatus;
    }

    public Date getCustomerFirstCommitDate()
    {
        return customerFirstCommitDate;
    }

    public void setCustomerFirstCommitDate(Date customerFirstCommitDate)
    {
        this.customerFirstCommitDate = customerFirstCommitDate;
    }

    public Date getCustomerCommitDate()
    {
        return customerCommitDate;
    }

    public void setCustomerCommitDate(Date customerCommitDate)
    {
        this.customerCommitDate = customerCommitDate;
    }

    public Date getCustomerRequestDate()
    {
        return customerRequestDate;
    }

    public void setCustomerRequestDate(Date customerRequestDate)
    {
        this.customerRequestDate = customerRequestDate;
    }

    public Boolean getCustomerExpediteIndicator()
    {
        return customerExpediteIndicator;
    }

    public void setCustomerExpediteIndicator(Boolean customerExpediteIndicator)
    {
        this.customerExpediteIndicator = customerExpediteIndicator;
    }

    public String getCustomerOrderNumber()
    {
        return customerOrderNumber;
    }

    public void setCustomerOrderNumber(String customerOrderNumber)
    {
        this.customerOrderNumber = customerOrderNumber;
    }

    public String getCustomerOrderVersionNumber()
    {
        return customerOrderVersionNumber;
    }

    public void setCustomerOrderVersionNumber(String customerOrderVersionNumber)
    {
        this.customerOrderVersionNumber = customerOrderVersionNumber;
    }

    public String getBillAccountNumber()
    {
        return billAccountNumber;
    }

    public void setBillAccountNumber(String billAccountNumber)
    {
        this.billAccountNumber = billAccountNumber;
    }

    public String getBillAccountName()
    {
        return billAccountName;
    }

    public void setBillAccountName(String billAccountName)
    {
        this.billAccountName = billAccountName;
    }

    public Double getUsdTotalMrcAmount()
    {
        return usdTotalMrcAmount;
    }

    public void setUsdTotalMrcAmount(Double usdTotalMrcAmount)
    {
        this.usdTotalMrcAmount = usdTotalMrcAmount;
    }

    public Date getCustomerRevisedCommitDate()
    {
        return customerRevisedCommitDate;
    }

    public void setCustomerRevisedCommitDate(Date customerRevisedCommitDate)
    {
        this.customerRevisedCommitDate = customerRevisedCommitDate;
    }

    public Double getUsdTotalNrcAmount()
    {
        return usdTotalNrcAmount;
    }

    public void setUsdTotalNrcAmount(Double usdTotalNrcAmount)
    {
        this.usdTotalNrcAmount = usdTotalNrcAmount;
    }

    public String getDwSourceSystemCode()
    {
        return dwSourceSystemCode;
    }

    public void setDwSourceSystemCode(String dwSourceSystemCode)
    {
        this.dwSourceSystemCode = dwSourceSystemCode;
    }

    public String getDispatchingGatewayClli()
    {
        return dispatchingGatewayClli;
    }

    public void setDispatchingGatewayClli(String dispatchingGatewayClli)
    {
        this.dispatchingGatewayClli = dispatchingGatewayClli;
    }

    public String getServiceComponentId()
    {
        return serviceComponentId;
    }

    public void setServiceComponentId(String serviceComponentId)
    {
        this.serviceComponentId = serviceComponentId;
    }

    public String getProcessId()
    {
        return processId;
    }

    public void setProcessId(String processId)
    {
        this.processId = processId;
    }

    @Override
    public String toString()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("TaskOrderLookup [taskId=");
        builder.append(taskId);
        builder.append(", taskName=");
        builder.append(taskName);
        builder.append(", taskStatus=");
        builder.append(taskStatus);
        builder.append(", performerName=");
        builder.append(performerName);
        builder.append(", taskCreateDate=");
        builder.append(taskCreateDate);
        builder.append(", taskEndDate=");
        builder.append(taskEndDate);
        builder.append(", performerGroupName=");
        builder.append(performerGroupName);
        builder.append(", productInstanceId=");
        builder.append(productInstanceId);
        builder.append(", serviceOrderNumber=");
        builder.append(serviceOrderNumber);
        builder.append(", serviceOrderVersionNumber=");
        builder.append(serviceOrderVersionNumber);
        builder.append(", serviceOrderActionType=");
        builder.append(serviceOrderActionType);
        builder.append(", serviceOrderStatus=");
        builder.append(serviceOrderStatus);
        builder.append(", customerFirstCommitDate=");
        builder.append(customerFirstCommitDate);
        builder.append(", customerCommitDate=");
        builder.append(customerCommitDate);
        builder.append(", customerRequestDate=");
        builder.append(customerRequestDate);
        builder.append(", customerExpediteIndicator=");
        builder.append(customerExpediteIndicator);
        builder.append(", customerOrderNumber=");
        builder.append(customerOrderNumber);
        builder.append(", customerOrderVersionNumber=");
        builder.append(customerOrderVersionNumber);
        builder.append(", billAccountNumber=");
        builder.append(billAccountNumber);
        builder.append(", billAccountName=");
        builder.append(billAccountName);
        builder.append(", usdTotalMrcAmount=");
        builder.append(usdTotalMrcAmount);
        builder.append(", customerRevisedCommitDate=");
        builder.append(customerRevisedCommitDate);
        builder.append(", usdTotalNrcAmount=");
        builder.append(usdTotalNrcAmount);
        builder.append(", dwSourceSystemCode=");
        builder.append(dwSourceSystemCode);
        builder.append(", dispatchingGatewayClli=");
        builder.append(dispatchingGatewayClli);
        builder.append(", serviceComponentId=");
        builder.append(serviceComponentId);
        builder.append(", processId=");
        builder.append(processId);
        builder.append("]");
        return builder.toString();
    }
}
