package com.level3.km.services.perftest;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.level3.km.services.resource.GenericAppDescriptor;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import com.sun.jersey.test.framework.AppDescriptor;
import com.sun.jersey.test.framework.JerseyTest;
import com.sun.jersey.test.framework.spi.container.TestContainerException;

/**
 * This is a test to compare SOLR performance for SOLR 4.x vs Solr 5.x. There is no SOLR specific code in here.
 * Solr query performance can be compared in Splunk, looking at the km rest services logs for appkey APPKEY1234567890.
 * To run this test against IDC TEST, please compile and issue the following stmt
 * $ mvn test -Dtest=com.level3.km.services.perftest.TestSolrQueryPerformance \
 *   -Djersey.test.containerFactory=com.sun.jersey.test.framework.spi.container.external.ExternalTestContainerFactory \
 *   -Djersey.test.port=80 \
 *   -Djersey.test.host=kmservices-test.l3.com
 * @author agarwal.nitin
 *
 */
public class TestSolrQueryPerformance extends JerseyTest
{
    // read input file
    // for each line check if it matches pattern
    // If no, process next line
    // If yes, parse contents of line
    // call KM REST service for the appropriate resource
    
    private static Pattern inputQueryLinePattern = Pattern.compile(".*?MI(NS)?-.*?( - APPKEY(\\d+|NotSet) ).*?((/?\\w+){2,3})(-\\w+)?: \\d+ \\w+\\s\\{(.*?])\\}$");
    
//    private static Pattern queryParamPattern = Pattern.compile("(\\S+)=[(.*?)],?");
    private static Pattern queryParamPattern = Pattern.compile("(\\S+)=\\[(.*?\\]?)\\],?");

    private static Logger log = LoggerFactory.getLogger(TestSolrQueryPerformance.class); 
    
    public TestSolrQueryPerformance() throws TestContainerException
    {
        super();
    }

    @Override
    protected AppDescriptor configure()
    {
        return GenericAppDescriptor.getAppDescriptor();
    }
    
    @Override
    public void setUp() throws Exception
    {
        super.setUp();
    }

    @Override
    public void tearDown() throws Exception
    {
        super.tearDown();
    }

    @Test
    public void getTestData()
    {
        Matcher inputQueryLineMatch = inputQueryLinePattern.matcher("");
        Matcher queryParamMatch = queryParamPattern.matcher("");

		URL u1 = TestSolrQueryPerformance.class.getResource("/dataservice.2015-11-09.log");
		File f1 = FileUtils.toFile(u1);;
		List<String> lines = null;
		String serviceCall = null;
		String queryParamsStr = null;
		MultivaluedMap<String, String> paramMap = null;

		try
        {
            lines = FileUtils.readLines(f1, "UTF-8");
            
            for(String line: lines)
            {
                if(inputQueryLineMatch.reset(line).lookingAt())
                {
                    log.info(line);

                    serviceCall = inputQueryLineMatch.group(4);
                    queryParamsStr = inputQueryLineMatch.group(7);
                    
                    log.info(serviceCall);
                    log.info(queryParamsStr);

                    queryParamMatch.reset(queryParamsStr);
                    
                    paramMap = new MultivaluedMapImpl();
                    while(queryParamMatch.find())
                    {
                        paramMap.add(queryParamMatch.group(1), queryParamMatch.group(2));
//                        log.info("Param Name: {}\nParamValue: {}", queryParamMatch.group(1), queryParamMatch.group(2));
                    }
                    
                    testSolrPerformance(serviceCall, paramMap);
                }
                
            }
        }
        catch (IOException e)
        {
            log.error("caught exception while trying to match the lines", e);
        }
    }

    private void testSolrPerformance(String service, MultivaluedMap<String, String>paramMap)
    {
        try
        {
            WebResource webResource = resource();
            ClientResponse response = 
                    webResource.path(service)
                    .queryParams(paramMap)
                    .accept(MediaType.APPLICATION_JSON)
                    .header("X-Level3-Application-Key", "APPKEY1234567890")
                    .get(ClientResponse.class);
        }
        catch(Throwable t)
        {
            log.error("caught exception continuing ...", t);
        }
        
//        Assert.assertNotNull(response);
//        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
//        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }
}
