package com.level3.km.services.perftest;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.SignatureException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ecyrd.speed4j.StopWatch;
import com.ecyrd.speed4j.StopWatchFactory;
import com.level3.km.services.resource.GenericAppDescriptor;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.Base64;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import com.sun.jersey.test.framework.AppDescriptor;
import com.sun.jersey.test.framework.JerseyTest;
import com.sun.jersey.test.framework.spi.container.TestContainerException;

public class TestExchangeRatePerf extends JerseyTest
{
    private static Pattern queryRowPattern = Pattern.compile(".*?raw\\?(.*)$");
    private static Pattern queryParamPattern = Pattern.compile("(.*?)=(.*?)&");

    private static Logger log = LoggerFactory.getLogger(TestExchangeRatePerf.class); 
    
    private static String appKey = "APPKEY100562488694302";
    private static String appSecret = "AppKeyInformation100562488694303";

//    private static final String BASE_URL = "http://kmservices-dev.level3.com/DataServices/v1/Search/";
    private static final String BASE_URL = "http://mediation-env4.level3.com/DataServices/v1/Search/";

    private String digestTime = null;
    private String digest = null;
    private Client client = null;
    
    public TestExchangeRatePerf() throws TestContainerException
    {
        super();
    }

    @Override
    protected AppDescriptor configure()
    {
        return GenericAppDescriptor.getAppDescriptor();
    }
    
    @Override
    public void setUp() throws Exception
    {
        super.setUp();

        digestTime = String.valueOf(System.currentTimeMillis());
        digest = createDigest(digestTime, appSecret);
        client = Client.create();
    }

    @Override
    public void tearDown() throws Exception
    {
        super.tearDown();
    }

    @Test
    public void getTestData()
    {
        Matcher queryRowMatch = queryRowPattern.matcher("");
        Matcher queryParamMatch = queryParamPattern.matcher("");

		URL u1 = TestExchangeRatePerf.class.getResource("/2015-11-11-Solr currency queries-01.txt");
		File f1 = FileUtils.toFile(u1);;
		List<String> lines = null;
		String queryParamsStr = null;
		MultivaluedMap<String, String> paramMap = null;

		try
        {
            lines = FileUtils.readLines(f1, "UTF-8");
            
            for(String line: lines)
            {
                if(queryRowMatch.reset(line).lookingAt())
                {
                    queryParamsStr = queryRowMatch.group(1);

                    queryParamMatch.reset(queryParamsStr);
                    
                    paramMap = new MultivaluedMapImpl();
                    while(queryParamMatch.find())
                    {
                        paramMap.add(queryParamMatch.group(1), queryParamMatch.group(2));
//                        log.info("Param Name: {}\nParamValue: {}", queryParamMatch.group(1), queryParamMatch.group(2));
                    }
                    
                    paramMap.add("fl", "exchangeRateValue");
                    
                    testSolrPerformance(paramMap, queryParamsStr);
                }
                
            }
        }
        catch (IOException e)
        {
            log.error("caught exception while trying to match the lines", e);
        }
    }

    private void testSolrPerformance(MultivaluedMap<String, String>paramMap, String queryParamsStr)
    {
        StopWatchFactory speed4jStopWatchFactory = StopWatchFactory.getInstance("loggingFactory");

//        WebResource webResource = resource();

        WebResource webResource = 
                client.resource(BASE_URL + "exchangeRate/raw");

        StopWatch stopWatch = speed4jStopWatchFactory.getStopWatch();
        ClientResponse response = 
                webResource.path("Service/exchangeRate/raw")
                .queryParams(paramMap)
                .accept(MediaType.APPLICATION_JSON)
                .header("X-Level3-Application-Key", appKey)
                .header("X-Level3-Digest", digest)
                .header("X-Level3-Digest-Time", digestTime)
                .get(ClientResponse.class);
        stopWatch.stop(BASE_URL + "exchangeRate/raw?" + queryParamsStr);
        
        Assert.assertNotNull(response);
//        Assert.assertEquals(Status.OK.getStatusCode(), response.getStatus());
//        Assert.assertEquals(MediaType.APPLICATION_JSON_TYPE, response.getType());
    }

    static String createDigest(String digestTime, String digestSecret)
            throws java.security.SignatureException
    {
        String result;

        try
        {
            // get an hmac_sha1 key from the raw key bytes
            SecretKeySpec signingKey = new SecretKeySpec(
                    digestSecret.getBytes(), "macSHA256");
            // get an hmac_sha2 Mac instance and initialize with the signing key
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(signingKey);
            // compute the hmac on input data bytes
            byte[] rawHmac = mac.doFinal(digestTime.getBytes());
            // base64-encode the hmac
            result = new String(Base64.encode(rawHmac));
        }
        catch (Exception e)
        {
            throw new SignatureException("Failed to generate HMAC : " + e.getMessage());
        }
        return result;
    }
}

// /2015-11-11-Solr currency queries-01.txt