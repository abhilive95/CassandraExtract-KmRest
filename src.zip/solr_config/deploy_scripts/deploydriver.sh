#!/bin/bash
################################################################################
#                                                                              #
# This script is used for deploying the lucene services to the lucene box      #
#                                                                              #
# Arguments:                                                                   #
#  $1 - The environment to deploy to                                           #
#  $2 - password                                                               #
#                                                                              #
# Author: Jonathan Roof 06/09/2014                                             #
#                                                                              #
################################################################################

# --------------------------------------------------------------
# functions
# --------------------------------------------------------------

function join_domain_args() {
  JOINED=
  PINDEX=1

  # arguments 3..N are service names
  for p in "$@"; do
    if [ ${PINDEX} -ge 3 ]; then
      JOINED="${JOINED}${p}";
    fi
    PINDEX=`expr ${PINDEX} + 1`
  done
  RESULT=${JOINED}
  echo "INFO: EXTRA PARAMS: ${RESULT}"
}

if [ $# -lt 2 ]; then
  echo "usage $0 environment application"
  exit 1
fi

ENV_INDEX=$1
ENVIRONMENT=`echo $ENV_INDEX | awk '{split($0,a,"_"); print a[1]}'`
INDEX=`echo $ENV_INDEX | awk '{split($0,a,"_"); print a[2]}'`
PASSWD=$2
PANDA_DIR=${PWD}
SCRIPTSDIR=${PWD}/deploy_scripts
HOSTNAME=`hostname`

IDC=`host $HOSTNAME |  awk '{print $1}' | grep idc`

if [ -z $IDC ]; then
  echo "The servers are in the ADC!!!"
  DC="adc"
else
  echo "The servers are in the IDC!!!"
  DC="idc"
fi

echo "INFO: Environment is ${ENVIRONMENT}..."
echo "INFO: PANDA_DIR is ${PANDA_DIR}..."
echo "INFO: HOSTNAME is ${HOSTNAME}"
echo "INFO: Data Center is ${DC}"

## CREATE THE LIST OF EXTRA PARAMS
if [ $# -ge 3 ]; then
  join_domain_args "$@"
fi

## CHECK THE CONTENTS OF THE LIST
if [ -z ${RESULT} ]; then
  EXTRAPARAMS=${INDEX}_${ENVIRONMENT}
else
  EXTRAPARAMS=${INDEX}_${RESULT}
fi

echo "INFO: Extra Parameter(s) is ${EXTRAPARAMS}"

# Create std error file and change perms so any user can write to it
if [ -f /tmp/pandaErr.log ]; then
  rm /tmp/pandaErr.log
fi
touch /tmp/pandaErr.log
chmod 666 /tmp/pandaErr.log

#check to see if there is a spcific properties file, if not use default
if [ ! -f "${PWD}/env_config/${EXTRAPARAMS}_${DC}_deploydriver.properties" ]; then
  echo "INFO: No ENV spcific deploydriver.properties file found in env_config dir, using \"default_deploydriver.properties\""
  DEPLOY_PROPERTIES="${PWD}/default_deploydriver.properties"
else
  echo "INFO: ENV specific deploydriver.properties file found, using deploy_scripts/\"${EXTRAPARAMS}_${DC}_deploydriver.properties\""
  DEPLOY_PROPERTIES="${PWD}/env_config/${EXTRAPARAMS}_${DC}_deploydriver.properties"
fi

echo "INFO: Preforming dos2unix on properties files..."

for file in `find ./env_config  -type f`; do
  dos2unix $file $file 1>>/tmp/pandaErr.log 2>&1
done

echo "INFO: Preforming dos2unix on deploy script files..."

for file in `find ./deploy_scripts -type f`; do
  dos2unix $file $file 1>>/tmp/pandaErr.log 2>&1
done

echo "INFO: Preforming dos2unix on index config files..."

for file in `find ./dist -type f`; do
  dos2unix $file $file 1>>/tmp/pandaErr.log 2>&1
done

# Sourcing deployment.properties file
. ${DEPLOY_PROPERTIES}

# check for environment properties
if [ ! -f "${PWD}/env_config/${EXTRAPARAMS}_${DC}_environment.properties" ]; then
  echo "INFO: No ENV spcific environment.properties file found in env_config dir, using \"default_environment.properties\""
  ENVIRONMENT_PROPERTIES="${PWD}/default_environment.properties"
else
  echo "INFO: ENV specific environment.properties file found, using env_config/\"${EXTRAPARAMS}_${DC}_environment.properties\""
  ENVIRONMENT_PROPERTIES="${PWD}/env_config/${EXTRAPARAMS}_${DC}_environment.properties"
fi

. ${ENVIRONMENT_PROPERTIES}


echo "After environment properties sourcing"
echo "db_server is: ${db_server}"
echo "db_port is: ${db_port}"
echo "db_sid is: ${db_sid}"
echo "db_login is: ${db_login}"


#Going to check that the db-data-config.xml file does exist in the deployment
if [ -f ./dist/db-data-config.xml ]; then
  #If the db-data-config.xml does exist we need to do some find and replace on the file.  Once done we are ready to deploy.
  echo "Start property replacement"
  sed -i "s/@@db_server@@/${db_server}/g" ./dist/db-data-config.xml
  sed -i "s/@@db_port@@/${db_port}/g" ./dist/db-data-config.xml
  sed -i "s/@@db_login@@/${db_login}/g" ./dist/db-data-config.xml
  sed -i "s/@@db_sid@@/${db_sid}/g" ./dist/db-data-config.xml
  sed -i "s/@@ENV@@/${ENVIRONMENT}/g"  ./dist/db-data-config.xml

  if [ "$INDEX" == "contact" ]; then
    sed -i "s/@@db_server2@@/${db_server2}/g" ./dist/db-data-config.xml
    sed -i "s/@@db_port2@@/${db_port2}/g" ./dist/db-data-config.xml
    sed -i "s/@@db_login2@@/${db_login2}/g" ./dist/db-data-config.xml
    sed -i "s/@@db_sid2@@/${db_sid2}/g" ./dist/db-data-config.xml
    sed -i "s/@@solr_id_table@@/${solr_id_table}/g" ./dist/db-data-config.xml
    sed -i "s/@@solr_function@@/${solr_function}/g" ./dist/db-data-config.xml

    PASSWD1=`echo $PASSWD | awk '{split($0,a,"?"); print a[1]}'`
    PASSWD2=`echo $PASSWD | awk '{split($0,a,"?"); print a[2]}'`

    sed -i "s/@@db_password@@/${PASSWD1}/g"  ./dist/db-data-config.xml
    sed -i "s/@@db_password2@@/${PASSWD2}/g"  ./dist/db-data-config.xml
  elif [ "$INDEX" == "loopqualification" ]; then
    PASSWD1=`echo $PASSWD | awk '{split($0,a,"?"); print a[1]}'`
    PASSWD2=`echo $PASSWD | awk '{split($0,a,"?"); print a[2]}'`

    sed -i "s/@@db_password@@/${PASSWD1}/g"  ./dist/db-data-config.xml
    sed -i "s/@@keystorepwd@@/${PASSWD2}/g"  ./dist/db-data-config.xml
  else
    sed -i "s/@@db_password@@/${PASSWD}/g"  ./dist/db-data-config.xml
  fi

echo "End property replacement"
fi

# Changing Permissions so $UNIX_USER can access
chmod -R +r ${PWD}
chmod +x ${SCRIPTSDIR}/deploy.sh

# Check for pre,deploy,and post scripts
if [ ! -f ${SCRIPTSDIR}/deploy.sh ]; then
  echo "ERROR: ${SCRIPTSDIR}/deploy.sh does not exist. Exiting..."
fi

#Start the deployment Tasks
export ENVIRONMENT PASSWD DEPLOY_PROPERTIES
if ! /usr/bin/sudo su - ${UNIX_USER} -c "${SCRIPTSDIR}/deploy.sh ${ENVIRONMENT} ${PASSWD} ${DEPLOY_PROPERTIES} ${PANDA_DIR} ${INDEX}"; then
  echo "ERROR: deploydriver.sh: deploy.sh script failed to complete successfully"
  exit 1
fi

